# PFIM 7.1

### User-visible changes

- S7 object model (`Evaluation`, `Optimization`, `Model`, `Fim`, covariates, library).
  Requires **R >= 4.2.0**.
- Population, individual, and Bayesian FIM; categorical covariates and IOV
  (`CategoricalCovariate`, `CategoricalCovariateWithIOV`, `gamma` on parameters).
- `covariateTest()` / `tost()` for covariate effect tests.
- Five optimizers: Multiplicative, Fedorov-Wynn, PSO, PGBO, Simplex (C++ kernels).
- Joint discrete optimization over multiple arms in one design.
- `Report()`, vignettes (`Example01`, `Example02`, `LibraryOfModels`).
- Session options: `pfim_get_option()`, `pfim_set_option()`, `pfim_reset_session()`.
- `numberOfOccasions` on `Evaluation` and `Optimization` (`NA` infers; explicit
  values are checked against `inferNumberOfOccasions()`).

### Performance

- FIM cache (`fim.cache`), batch rebuild during constraint grids (`eval.batch`).
- ODE caches: `perf.adminCache`, `perf.fdCache`, `perf.odeTimesCache` (sim-time grid in C++).
- Population covariate/IOV FIM blocks: `computePopFimCombo_Rcpp` + `computeMFVar_Rcpp`.
- PSO: one R fitness callback per swarm iteration (`eval_fitness_batch`).
- Covariate/IOV arms: model, gradient, and variance on one combination × occasion pass.

### Bug fixes

- Population covariate/IOV FIM: C++ kernels (`computePopFimCombo_Rcpp`, `computeMFVar_Rcpp`) with R cross-tests; `chol_inv` / `safe_solve` pure Armadillo (match R `chol2inv`/`chol` and `solve`+jitter); `src/init.c` auto-generated from Rcpp exports; IOV block accumulation fix.
- Fedorov-Wynn C++: stray text removed from `FedorovWynnAlgorithm.cpp` (Windows build).
- Fedorov-Wynn: `fisher` buffers sized to FIM dimension (`ndimFim`).

### Packaging / CRAN

- `stats` added to `Imports` (aligned with `NAMESPACE`).
- `stats::setNames()` everywhere (R CMD check NOTE).
- `tost` documented as alias of `covariateTest()`.
- Version floors: `ggplot2 (>= 3.5.0)` (`facet_wrap(..., space = "free_x")`),
  `S7 (>= 0.1.1)`, `testthat (>= 3.2.3)` in `DESCRIPTION`.
- `@examples` on `run()`, `Design`, `Arm` (see `inst/examples/evaluation-minimal.R`).
- FD grid skips `fixedMu` / `mu == 0` parameters; population FIM excludes `omega^2`
  when `fixedMu` (FO consistency).
- `mfvar_mixed`: rank-1 omega/gamma columns use \eqn{(v^\top V^{-1} w)^2} instead of
  dense \eqn{p \times p} outer products; wired in `computePopFimCombo_Rcpp` and the
  simple population path. R reference `.computePopFimCombo_R` aligned.
- `constraints.maxTasks` documented (`?pfim_set_option`); subsampling on large
  constraint grids is deterministic (equispaced per dose), not RNG-based.
- Default ODE tolerances when `odeSolverParameters = list()`; optional `perf.fdLinearOnly`.
- `optimizerParameters` validated at `Optimization()` construction; dead config
  properties removed from `*Algorithm` S7 classes (settings live on `Optimization` only).
- Optional `fim.cache.maxEntries` FIFO cap on FIM caches.
- Population FIM variance block uses `adjustGradient()` per distribution
  (Normal: no μ scaling; LogNormal: chain rule on η). Residual variance
  `(σ_inter + σ_slope·f^c)^2` with `cError`; `Constant` / `Proportional`
  constructors reject mixed σ parameters.

### Maintenance

- FIM cache scopes: `pfim#N` on `cacheScope` (`pfim-fim-cache.R`).
- C++ pop FIM / linalg kernels; `src/init.c` routine registration.
- Maintainer change: France Mentré is the new package maintainer starting with this version.

## History

PFIM 7.1 is the S7-based release documented in the package
vignettes and `?PFIM-package`.
