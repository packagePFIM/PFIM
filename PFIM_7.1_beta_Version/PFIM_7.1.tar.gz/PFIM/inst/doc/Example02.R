## ----global_options, echo = FALSE, include = FALSE----------------------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_knit$set(tangle = FALSE)
backup_options = options()
library(PFIM)
set.seed(42)
options(width = 200)
paths <- list(
  data    = file.path(getwd(), "data"),
  figures = file.path(getwd(), "results", "figures"),
  reports = file.path(getwd(), "results"),
  outputs = file.path(getwd(), "results", "outputs")
)
for (d in paths) dir.create(d, recursive = TRUE, showWarnings = FALSE)
plotOptions <- list(unitTime = c("hour"), unitOutcomes = c("mcg/mL"))
knitr::opts_chunk$set(purl = FALSE, collapse = TRUE,
                      comment = "#>", echo = FALSE, warning = FALSE, message = FALSE,
                      cache = FALSE, tidy = FALSE, size = "small",
                      fig.align = "center", out.width = "62%", dpi = 110,
                      fig.width = 5, fig.height = 4, dev = "png")

