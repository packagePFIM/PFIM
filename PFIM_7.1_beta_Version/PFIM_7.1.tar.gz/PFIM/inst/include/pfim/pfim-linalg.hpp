// PFIM linear-algebra kernels shared by FIM assembly and discrete optimizers.
//
// Header-only Armadillo helpers: Cholesky inverse, safe solve, and the
// variance-parameter FIM blocks mfvar / mfvar_mixed (see R .computeMFVar).
#pragma once
#include <RcppArmadillo.h>
#include <cmath>
#include <limits>
#include <vector>

namespace pfim {

namespace {

// Invert A via solve(A, I); return empty matrix on failure or poor residual.
inline arma::mat solve_invert( const arma::mat& A ) {
  arma::mat out;
  const arma::mat I = arma::eye( A.n_rows, A.n_cols );
  if ( !arma::solve( out, A, I ) )
    return arma::mat();
  // Relative residual: ||A A^{-1} - I||_inf / (||A||_inf * ||A^{-1}||_inf + eps).
  const double abs_res = arma::norm( A * out - I, "inf" );
  const double scale =
      arma::norm( A, "inf" ) * arma::norm( out, "inf" ) +
      std::numeric_limits<double>::epsilon();
  if ( abs_res > 1e-8 * scale )
    return arma::mat();
  return out;
}

}  // namespace

// Outer product v * v^T (rank-1 contribution to dV).
inline arma::mat outer_col( const arma::vec& v ) {
  return v * v.t();
}

// SPD inverse and log-det via one Cholesky factorization (non-throwing).
inline bool try_chol_inv_logdet( const arma::mat& M,
                                 arma::mat& inv_out,
                                 double& log_det_out ) {
  arma::mat L;
  if ( !arma::chol( L, M, "lower" ) )
    return false;

  const arma::vec d = arma::diagvec( L );
  if ( arma::any( d <= 0.0 ) )
    return false;

  log_det_out = 2.0 * arma::as_scalar( arma::sum( arma::log( d ) ) );
  if ( !R_finite( log_det_out ) )
    return false;

  // inv = (L^{-T}) (L^{-1}) from the upper-triangular factor.
  const arma::mat Ui = arma::inv( arma::trimatu( L.t() ) );
  inv_out            = Ui * Ui.t();
  return true;
}

// chol2inv(chol(M)); empty matrix when M is not SPD (non-throwing).
inline arma::mat try_chol_inv( const arma::mat& M ) {
  arma::mat inv;
  double log_det = 0.0;
  if ( !try_chol_inv_logdet( M, inv, log_det ) )
    return arma::mat();
  return inv;
}

// chol2inv(chol(V)); stops when Cholesky fails (.safeCholInv).
// An all-zero matrix is an error (no silent eps·I inverse).
inline arma::mat chol_inv( const arma::mat& V ) {
  arma::mat out = try_chol_inv( V );
  if ( out.n_elem > 0 )
    return out;

  const double scale = arma::as_scalar( arma::max( arma::abs( arma::diagvec( V ) ) ) );
  if ( !( scale > 0.0 ) )
    Rcpp::stop( "chol_inv: Cholesky failed (matrix is zero / not positive definite)." );

  Rcpp::stop( "chol_inv: Cholesky failed (matrix is not positive definite)." );
}

// solve(M); fails when M is singular (.safeSolve).
inline arma::mat safe_solve( const arma::mat& M, bool* regularized = nullptr ) {
  if ( M.n_rows != M.n_cols )
    Rcpp::stop( "safe_solve: matrix must be square." );

  const arma::mat out = solve_invert( M );
  if ( out.n_elem == 0 )
    Rcpp::stop( "safe_solve: inversion failed (matrix is singular or ill-conditioned)." );
  if ( regularized )
    *regularized = false;
  return out;
}

// 1/2 Tr(V^{-1} dV_i V^{-1} dV_j) (.computeMFVar) — full dV list path.
inline arma::mat mfvar( const arma::mat& V_inv, const Rcpp::List& dV_list ) {
  const int n = dV_list.size();
  if ( n == 0 )
    return arma::mat( 0, 0 );

  const arma::uword p = V_inv.n_rows;
  std::vector<arma::mat> dV( static_cast<size_t>( n ) );
  std::vector<arma::mat> T( static_cast<size_t>( n ) );

  // Precompute T_k = V^{-1} dV_k V^{-1} for the Hadamard / Frobenius products.
  for ( int k = 0; k < n; ++k ) {
    dV[ static_cast<size_t>( k ) ] = Rcpp::as<arma::mat>( dV_list[ k ] );
    if ( dV[ static_cast<size_t>( k ) ].n_rows != p || dV[ static_cast<size_t>( k ) ].n_cols != p )
      Rcpp::stop( "mfvar: dV_list[[%d]] is not %dx%d.", k + 1, p, p );
    T[ static_cast<size_t>( k ) ] = V_inv * dV[ static_cast<size_t>( k ) ] * V_inv;
  }

  arma::mat out( n, n, arma::fill::zeros );
  for ( int i = 0; i < n; ++i ) {
    for ( int j = i; j < n; ++j ) {
      const double val = 0.5 * arma::accu( T[ static_cast<size_t>( i ) ] % dV[ static_cast<size_t>( j ) ] );
      out( i, j ) = val;
      if ( j != i )
        out( j, i ) = val;
    }
  }
  return out;
}

// Rank-1 columns W (dV_k = w_k w_k^T) plus optional full p x p derivatives (IOV blocks, sigma).
// Tr(V^{-1} w_i w_i^T V^{-1} w_j w_j^T) = (w_i^T V^{-1} w_j)^2.
inline arma::mat mfvar_mixed( const arma::mat& V_inv,
                              const arma::mat& W,
                              const Rcpp::List& dV_full ) {
  const int n1 = static_cast<int>( W.n_cols );
  const int n2 = dV_full.size();
  const int n  = n1 + n2;
  if ( n == 0 )
    return arma::mat( 0, 0 );

  const arma::uword p = V_inv.n_rows;
  if ( W.n_rows != p )
    Rcpp::stop( "mfvar_mixed: W has %d rows, expected %d.", W.n_rows, p );

  arma::mat out( n, n, arma::fill::zeros );
  arma::mat VinW;
  // Rank-1 block: out_ij = 1/2 (w_i^T V^{-1} w_j)^2.
  if ( n1 > 0 ) {
    VinW = V_inv * W;
    const arma::mat A = W.t() * VinW;
    for ( int i = 0; i < n1; ++i ) {
      for ( int j = i; j < n1; ++j ) {
        const double val = 0.5 * A( i, j ) * A( i, j );
        out( i, j ) = val;
        if ( j != i )
          out( j, i ) = val;
      }
    }
  }

  if ( n2 == 0 )
    return out;

  // Full-matrix block among dV_full entries (same formula as mfvar).
  std::vector<arma::mat> dV( static_cast<size_t>( n2 ) );
  std::vector<arma::mat> T( static_cast<size_t>( n2 ) );
  for ( int k = 0; k < n2; ++k ) {
    dV[ static_cast<size_t>( k ) ] = Rcpp::as<arma::mat>( dV_full[ k ] );
    if ( dV[ static_cast<size_t>( k ) ].n_rows != p || dV[ static_cast<size_t>( k ) ].n_cols != p )
      Rcpp::stop( "mfvar_mixed: dV_full[[%d]] is not %dx%d.", k + 1, p, p );
    T[ static_cast<size_t>( k ) ] = V_inv * dV[ static_cast<size_t>( k ) ] * V_inv;
  }

  for ( int i = 0; i < n2; ++i ) {
    for ( int j = i; j < n2; ++j ) {
      const double val = 0.5 * arma::accu( T[ static_cast<size_t>( i ) ] % dV[ static_cast<size_t>( j ) ] );
      out( n1 + i, n1 + j ) = val;
      if ( j != i )
        out( n1 + j, n1 + i ) = val;
    }
  }

  // Cross terms between rank-1 columns and full dV blocks.
  if ( n1 > 0 ) {
    for ( int i = 0; i < n1; ++i ) {
      const arma::vec wi = VinW.col( static_cast<arma::uword>( i ) );
      for ( int j = 0; j < n2; ++j ) {
        const double val = 0.5 * arma::as_scalar( wi.t() * dV[ static_cast<size_t>( j ) ] * wi );
        out( i, n1 + j ) = val;
        out( n1 + j, i ) = val;
      }
    }
  }

  return out;
}

}  // namespace pfim
