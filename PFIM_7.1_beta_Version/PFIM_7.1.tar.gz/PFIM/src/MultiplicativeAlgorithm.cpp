// [[Rcpp::depends(RcppArmadillo)]]
#include <pfim/pfim-linalg.hpp>
#include <RcppArmadillo.h>
#include <cmath>
#include <vector>

using pfim::try_chol_inv_logdet;

// Multiplicative algorithm for D-optimal weights on a fixed candidate set
// (Pukelsheim / classical continuous design theory).
//
// Iteration:
//   F(w)  = sum_i w_i F_i
//   D     = det(F)^{1/p} = exp(log_det / p)   // D-criterion scale (stable)
//   phi'  = (D/p) F^{-1}
//   m_i   = tr( phi' F_i )
//   w     <- w * m^lambda / ||.||_1
// Stop when max(m) < (1+delta) * sum(w_i m_i)  (equivalently near optimality).
//
// Note: uses exp(log_det/p), not raw det, both for the formula and to avoid Inf.

// [[Rcpp::export]]
Rcpp::List MultiplicativeAlgorithm_Rcpp(
    Rcpp::List fisherMatrices,
    int        n_fim,
    arma::vec  weights,
    int        p,
    double     lambda,
    double     delta,
    int        iteration_init,
    bool       show_process = false )
{
  if ( n_fim <= 0 || p <= 0 || iteration_init < 0 )
    Rcpp::stop( "MultiplicativeAlgorithm: non-positive dimensions." );
  if ( static_cast<int>( fisherMatrices.size() ) < n_fim )
    Rcpp::stop( "MultiplicativeAlgorithm: fisherMatrices length mismatch." );
  if ( static_cast<int>( weights.n_elem ) != n_fim )
    Rcpp::stop( "MultiplicativeAlgorithm: weights length mismatch." );

  std::vector<arma::mat> fim_mats( static_cast<size_t>( n_fim ) );
  for ( int i = 0; i < n_fim; ++i ) {
    fim_mats[ static_cast<size_t>( i ) ] = Rcpp::as<arma::mat>( fisherMatrices[i] );
    const arma::mat& M = fim_mats[ static_cast<size_t>( i ) ];
    if ( M.n_rows != static_cast<arma::uword>( p ) || M.n_cols != static_cast<arma::uword>( p ) )
      Rcpp::stop( "MultiplicativeAlgorithm: FIM %d is not %dx%d.", i + 1, p, p );
  }

  if ( show_process )
    Rcpp::Rcout << "Multiplicative algorithm (up to " << iteration_init << " iterations)\n";

  arma::mat sum_weighted_fims( p, p, arma::fill::zeros );
  arma::mat derivative_phi( p, p );
  arma::mat matmult( p, p );
  arma::vec vector_of_multiplier( n_fim );

  int iter = 0;
  bool converged = false;
  bool singular_fim = false;
  for ( ; iter < iteration_init; ++iter ) {
    Rcpp::checkUserInterrupt();

    // F(w) = sum_i w_i F_i
    sum_weighted_fims.zeros();
    for ( int i = 0; i < n_fim; ++i )
      sum_weighted_fims += fim_mats[ static_cast<size_t>( i ) ] * weights[i];

    arma::mat inv_fim;
    double log_det = 0.0;
    if ( !try_chol_inv_logdet( sum_weighted_fims, inv_fim, log_det ) ) {
      singular_fim = true;
      break;
    }

    // D = exp(log_det / p); phi' = (D/p) F^{-1}; m_i = tr(phi' F_i)
    const double Dcrit = std::exp( log_det / static_cast<double>( p ) );
    derivative_phi     = Dcrit * inv_fim / static_cast<double>( p );

    for ( int i = 0; i < n_fim; ++i ) {
      matmult                 = derivative_phi * fim_mats[ static_cast<size_t>( i ) ];
      vector_of_multiplier[i] = arma::sum( matmult.diag() );
    }

    // Multiplicative update: w <- w * m^lambda / ||.||_1
    arma::vec wm = weights % arma::pow( vector_of_multiplier, lambda );
    const double wm_sum = arma::sum( wm );
    if ( wm_sum <= 0.0 || !R_finite( wm_sum ) ) {
      singular_fim = true;
      break;
    }
    weights = wm / wm_sum;

    // Near-optimality: max(m) < (1+delta) * sum(w_i m_i)
    if ( vector_of_multiplier.max() <
         ( 1.0 + delta ) * arma::dot( weights, vector_of_multiplier ) ) {
      converged = true;
      break;
    }
  }

  if ( show_process )
    Rcpp::Rcout << "Multiplicative algorithm: " << iter
                << " iteration(s), converged = " << ( converged ? "yes" : "no" ) << "\n";

  return Rcpp::List::create(
    Rcpp::Named( "weights" )      = weights,
    Rcpp::Named( "iterationEnd" ) = iter,
    Rcpp::Named( "iterations" )   = iter,
    Rcpp::Named( "converged" )    = converged,
    Rcpp::Named( "singularFim" )  = singular_fim
  );
}
