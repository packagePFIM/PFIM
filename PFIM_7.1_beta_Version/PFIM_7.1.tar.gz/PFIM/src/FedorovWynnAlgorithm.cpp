// Fedorov-Wynn exchange for D-optimal weights on discrete protocols (Fedorov 1972).
//
// Outer loop: add the best improving candidate (Fedorov), then optimise weights
// on the current support (Wynn projected-gradient / exchange + line search).
// Directional gain for candidate i is Tr(F^{-1} F_i); optimality when max gain = p.
//
// Initial support comes from R (zeprot / zefreq): one grid index + weight per
// elementaryProtocols seed — each seed must match a full sampling-grid row.
//
// [[Rcpp::depends(RcppArmadillo)]]
#include <pfim/pfim-linalg.hpp>
#include <RcppArmadillo.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <optional>
#include <utility>
#include <vector>

using namespace Rcpp;

namespace fw {

constexpr double k_ftol              = 1e-6;
constexpr double k_weight_floor      = 1e-8;
constexpr double k_line_search_floor = 1e-4;
constexpr double k_singular_det      = 1e30;
constexpr double k_cold_start_det    = -1e10;
constexpr int    k_max_wynn_iters    = 500;
constexpr int    k_max_outer_iters   = 100;
constexpr int    k_max_add_attempts  = 100;

enum class SolveStatus {
  success,
  support_overflow,
  augmentation_failed,
  weight_optimization_failed,
  singular_fim
};

enum class WynnStatus {
  converged,
  iteration_limit,
  singular_fim
};

enum class LineSearchStatus {
  improved,
  tolerance_reached,
  rejected
};

// Upper triangle of a symmetric matrix in column-major packed order.
class PackedFim {
public:
  explicit PackedFim( int param_dim = 0 )
    : param_dim_( param_dim ),
      values_( static_cast<arma::uword>( packed_size( param_dim ) ), arma::fill::zeros ) {}

  static int packed_size( int param_dim ) {
    return param_dim * ( param_dim + 1 ) / 2;
  }

  int param_dim() const { return param_dim_; }
  const arma::vec& values() const { return values_; }
  arma::vec& values() { return values_; }
  void fill_zero() { values_.zeros(); }

  static arma::mat expand( const arma::vec& packed, int param_dim ) {
    arma::mat dense( param_dim, param_dim, arma::fill::zeros );
    arma::uword k = 0;
    for ( int row = 0; row < param_dim; ++row )
      for ( int col = 0; col <= row; ++col )
        dense( row, col ) = dense( col, row ) = packed( k++ );
    return dense;
  }

  static arma::vec compress( const arma::mat& dense, int param_dim ) {
    arma::vec packed( packed_size( param_dim ), arma::fill::zeros );
    for ( int row = 0; row < param_dim; ++row )
      for ( int col = 0; col <= row; ++col )
        packed( static_cast<arma::uword>( row * ( row + 1 ) / 2 + col ) ) = dense( row, col );
    return packed;
  }

  static double trace_with_inverse( const arma::vec& fim,
                                    const arma::vec& inv_fim,
                                    int param_dim ) {
    double trace = 0.0;
    for ( int row = 0; row < param_dim; ++row ) {
      for ( int col = 0; col < row; ++col ) {
        const arma::uword k = static_cast<arma::uword>( row * ( row + 1 ) / 2 + col );
        trace += 2.0 * fim( k ) * inv_fim( k );
      }
      const arma::uword k = static_cast<arma::uword>( row * ( row + 3 ) / 2 );
      trace += fim( k ) * inv_fim( k );
    }
    return trace;
  }

private:
  int param_dim_;
  arma::vec values_;
};

struct CandidateProtocol {
  std::vector<double> sample_times;
  PackedFim information;
};

class ProtocolGrid {
public:
  static ProtocolGrid from_matrices( const NumericMatrix& sample_times,
                                     const NumericMatrix& information_rows,
                                     int param_dim,
                                     int n_sample_times,
                                     double information_scale ) {
    const int n_candidates = sample_times.nrow();
    if ( information_rows.nrow() != n_candidates ||
         information_rows.ncol() != PackedFim::packed_size( param_dim ) )
      stop( "Fedorov-Wynn: information matrix shape does not match candidates." );
    if ( sample_times.ncol() != n_sample_times )
      stop( "Fedorov-Wynn: sample time columns mismatch." );

    ProtocolGrid grid;
    grid.candidates_.resize( static_cast<size_t>( n_candidates ) );
    for ( int row = 0; row < n_candidates; ++row ) {
      CandidateProtocol& candidate = grid.candidates_[ static_cast<size_t>( row ) ];
      candidate.information = PackedFim( param_dim );
      candidate.sample_times.assign( n_sample_times, 0.0 );
      for ( int t = 0; t < n_sample_times; ++t )
        candidate.sample_times[ static_cast<size_t>( t ) ] = sample_times( row, t );
      for ( int k = 0; k < PackedFim::packed_size( param_dim ); ++k )
        candidate.information.values()( k ) = information_rows( row, k ) * information_scale;
    }
    return grid;
  }

  int count() const { return static_cast<int>( candidates_.size() ); }
  const CandidateProtocol& candidate( int index ) const {
    return candidates_.at( static_cast<size_t>( index ) );
  }

  double directional_gain( int candidate_index, const arma::vec& inv_information ) const {
    const CandidateProtocol& item = candidate( candidate_index );
    return PackedFim::trace_with_inverse(
      item.information.values(), inv_information, item.information.param_dim()
    );
  }

private:
  std::vector<CandidateProtocol> candidates_;
};

struct ActiveProtocol {
  int candidate_index = 0;
  double weight = 0.0;
  std::vector<double> sample_times;
  PackedFim information;
};

struct ProjectedGradient {
  std::vector<double> components;
  std::optional<int> descent_index;
  double max_abs_component = 0.0;
};

struct WynnStep {
  std::vector<double> direction;
  double step_length = 0.0;
  int entering_index = 0;
  int leaving_index  = 0;
};

struct WynnOutcome {
  WynnStatus status = WynnStatus::converged;
  int inactive_weight_count = 0;
};

class WeightedDesign {
public:
  WeightedDesign( int param_dim, int max_support )
    : param_dim_( param_dim ),
      max_support_( max_support ),
      active_size_( 0 ),
      mixture_fim_( param_dim ),
      inv_mixture_fim_( param_dim ),
      determinant_( 1.0 ),
      fim_ready_( false ),
      singular_fim_( false ),
      active_( static_cast<size_t>( max_support ) ),
      scratch_weights_( static_cast<size_t>( max_support ), 0.0 ) {}

  int param_dim() const { return param_dim_; }
  int active_size() const { return active_size_; }
  bool is_singular() const { return singular_fim_; }
  const arma::vec& mixture_fim() const { return mixture_fim_.values(); }

  const ActiveProtocol& active_protocol( int index ) const {
    return active_.at( static_cast<size_t>( index ) );
  }

  bool append( int candidate_index, double weight, const CandidateProtocol& source ) {
    if ( active_size_ >= max_support_ )
      return false;
    ActiveProtocol& slot = active_.at( static_cast<size_t>( active_size_ ) );
    slot.candidate_index = candidate_index;
    slot.weight          = weight;
    slot.sample_times    = source.sample_times;
    slot.information     = source.information;
    ++active_size_;
    touch_fim();
    return true;
  }

  bool includes( int candidate_index ) const {
    for ( int i = 0; i < active_size_; ++i )
      if ( active_.at( static_cast<size_t>( i ) ).candidate_index == candidate_index )
        return true;
    return false;
  }

  int count_inactive_weights() const {
    int inactive = 0;
    for ( int i = 0; i < active_size_; ++i )
      if ( weight( i ) < k_weight_floor )
        ++inactive;
    return inactive;
  }

  void prune_inactive_support() {
    // Compact active_ by dropping protocols with weight below k_weight_floor.
    int skipped = 0;
    int kept = active_size_;
    for ( int i = 0; i < active_size_; ++i ) {
      if ( weight( i ) < k_weight_floor ) {
        ++skipped;
        --kept;
      } else if ( skipped > 0 ) {
        active_.at( static_cast<size_t>( i - skipped ) ) = active_.at( static_cast<size_t>( i ) );
      }
    }
    active_size_ = kept;
    touch_fim();
  }

  double update_information() {
    if ( fim_ready_ )
      return determinant_;

    mixture_fim_.fill_zero();
    for ( int i = 0; i < active_size_; ++i )
      mixture_fim_.values() += weight( i ) * active_.at( static_cast<size_t>( i ) ).information.values();

    const arma::mat dense = PackedFim::expand( mixture_fim_.values(), param_dim_ );
    arma::mat inverse;
    double log_det = 0.0;
    if ( !pfim::try_chol_inv_logdet( dense, inverse, log_det ) ) {
      singular_fim_ = true;
      determinant_  = 0.0;
      inv_mixture_fim_.fill_zero();
      fim_ready_      = true;
      return determinant_;
    }

    singular_fim_             = false;
    // Stored as det(F) for line-search comparisons (monotonic in D^{1/p}).
    // For very large FIMs, exp(log_det) may overflow to Inf; Multiplicative
    // instead uses exp(log_det/p). Comparisons remain valid when finite.
    determinant_              = std::exp( log_det );
    inv_mixture_fim_.values() = PackedFim::compress( inverse, param_dim_ );
    fim_ready_                = true;
    return determinant_;
  }

  bool try_add_best_candidate( const ProtocolGrid& grid ) {
    update_information();
    if ( is_singular() )
      return false;

    const double target = static_cast<double>( param_dim_ );
    double best_gain = target;
    std::optional<int> best_candidate;

    for ( int candidate = 0; candidate < grid.count(); ++candidate ) {
      if ( includes( candidate ) )
        continue;
      const double gain = grid.directional_gain( candidate, inv_mixture_fim_.values() );
      if ( gain >= best_gain ) {
        best_gain = gain;
        best_candidate = candidate;
      }
    }

    if ( !best_candidate.has_value() ||
         std::abs( best_gain - target ) <= std::numeric_limits<double>::epsilon() )
      return false;

    // eq. (2.3) in Fedorov (1972): initial weight share for the entering protocol.
    if ( std::abs( best_gain - 1.0 ) < 1e-12 )
      return false;
    const double share = ( best_gain - target ) / ( target * ( best_gain - 1.0 ) );
    if ( !R_finite( share ) || share <= 0.0 || share >= 1.0 )
      return false;
    if ( !append( *best_candidate, share, grid.candidate( *best_candidate ) ) )
      return false;
    for ( int i = 0; i < active_size_ - 1; ++i )
      active_.at( static_cast<size_t>( i ) ).weight *= ( 1.0 - share );
    touch_fim();
    update_information();
    return true;
  }

  WynnOutcome optimize_weights( const ProtocolGrid& grid ) {
    int inactive_weights = 0;
    std::optional<int> pinned_index;
    double criterion = update_information();
    if ( is_singular() )
      return WynnOutcome{ WynnStatus::singular_fim, inactive_weights };

    // Wynn exchange: projected gradient on the simplex, line search, occasional support prune.
    for ( int iteration = 0; iteration < k_max_wynn_iters; ++iteration ) {
      Rcpp::checkUserInterrupt();
      save_weights( scratch_weights_ );
      const double previous_criterion = criterion;

      if ( !pinned_index.has_value() )
        inactive_weights = count_inactive_weights();

      ProjectedGradient gradient = compute_projected_gradient(
        grid, pinned_index, inactive_weights
      );
      if ( !gradient.descent_index.has_value() )
        return WynnOutcome{ WynnStatus::converged, inactive_weights };
      if ( gradient.components[ static_cast<size_t>( *gradient.descent_index ) ] == 0.0 )
        return WynnOutcome{ WynnStatus::converged, inactive_weights };
      if ( pinned_index.has_value() &&
           gradient.components[ static_cast<size_t>( *pinned_index ) ] <= 0.0 )
        return WynnOutcome{ WynnStatus::converged, inactive_weights };

      pinned_index.reset();
      const WynnStep step = build_exchange_step( gradient );
      apply_exchange_step( step );
      const double trial_criterion = update_information();

      if ( trial_criterion > criterion ) {
        save_weights( scratch_weights_ );
        criterion = trial_criterion;
        inactive_weights = count_inactive_weights();
      } else {
        restore_weights( scratch_weights_ );
        const LineSearchStatus search = line_search_along_step(
          step, scratch_weights_, criterion, previous_criterion, gradient.max_abs_component
        );
        if ( search == LineSearchStatus::rejected ) {
          pinned_index = find_removable_support( grid, inactive_weights );
          if ( !pinned_index.has_value() )
            return WynnOutcome{ WynnStatus::converged, inactive_weights };
        }
      }
    }
    return WynnOutcome{ WynnStatus::iteration_limit, inactive_weights };
  }

private:
  double weight( int index ) const {
    return active_.at( static_cast<size_t>( index ) ).weight;
  }

  ActiveProtocol& mutable_protocol( int index ) {
    return active_.at( static_cast<size_t>( index ) );
  }

  void touch_fim() { fim_ready_ = false; singular_fim_ = false; }

  void save_weights( std::vector<double>& buffer ) const {
    buffer.assign( static_cast<size_t>( active_size_ ), 0.0 );
    for ( int i = 0; i < active_size_; ++i )
      buffer[ static_cast<size_t>( i ) ] = weight( i );
  }

  void restore_weights( const std::vector<double>& buffer ) {
    for ( int i = 0; i < active_size_; ++i )
      mutable_protocol( i ).weight = buffer[ static_cast<size_t>( i ) ];
    touch_fim();
  }

  bool is_active_weight( int index, std::optional<int> pinned_index ) const {
    return weight( index ) >= k_weight_floor ||
      ( pinned_index.has_value() && *pinned_index == index );
  }

  ProjectedGradient compute_projected_gradient( const ProtocolGrid& grid,
                                                std::optional<int> pinned_index,
                                                int inactive_weights ) {
    update_information();
    ProjectedGradient result;
    result.components.assign( static_cast<size_t>( active_size_ ), 0.0 );

    double sum = 0.0;
    for ( int i = 0; i < active_size_; ++i ) {
      if ( !is_active_weight( i, pinned_index ) )
        continue;
      result.components[ static_cast<size_t>( i ) ] = grid.directional_gain(
        active_.at( static_cast<size_t>( i ) ).candidate_index,
        inv_mixture_fim_.values()
      );
      sum += result.components[ static_cast<size_t>( i ) ];
    }

    const int free_weights = active_size_ - inactive_weights;
    if ( free_weights <= 0 )
      return result;

    const double center = sum / static_cast<double>( free_weights );
    for ( int i = 0; i < active_size_; ++i ) {
      if ( !is_active_weight( i, pinned_index ) )
        continue;
      result.components[ static_cast<size_t>( i ) ] -= center;
      const double value = result.components[ static_cast<size_t>( i ) ];
      result.max_abs_component = std::max( result.max_abs_component, std::abs( value ) );
      if ( value < 0.0 &&
           ( !result.descent_index.has_value() ||
             value < result.components[ static_cast<size_t>( *result.descent_index ) ] ) )
        result.descent_index = i;
    }
    return result;
  }

  WynnStep build_exchange_step( const ProjectedGradient& gradient ) const {
    const int entering = *gradient.descent_index;
    WynnStep step;
    step.direction     = gradient.components;
    step.entering_index = entering;
    step.leaving_index  = entering;
    step.step_length    = -weight( entering ) / step.direction[ static_cast<size_t>( entering ) ];

    for ( int i = 0; i < active_size_; ++i ) {
      if ( step.direction[ static_cast<size_t>( i ) ] >= 0.0 )
        continue;
      const double bound = -weight( i ) / step.direction[ static_cast<size_t>( i ) ];
      if ( bound < step.step_length ) {
        step.step_length   = bound;
        step.leaving_index = i;
      }
    }
    return step;
  }

  void apply_exchange_step( const WynnStep& step ) {
    for ( int i = 0; i < active_size_; ++i )
      mutable_protocol( i ).weight += step.step_length * step.direction[ static_cast<size_t>( i ) ];
    mutable_protocol( step.leaving_index ).weight = 0.0;
    touch_fim();
  }

  LineSearchStatus line_search_along_step( const WynnStep& step,
                                           std::vector<double>& saved_weights,
                                           double& criterion,
                                           double previous_criterion,
                                           double max_direction ) {
    double shrink = 1.0;
    do {
      shrink *= 0.5;
      for ( int i = 0; i < active_size_; ++i )
        mutable_protocol( i ).weight =
          saved_weights[ static_cast<size_t>( i ) ] +
          shrink * step.step_length * step.direction[ static_cast<size_t>( i ) ];
      touch_fim();
      const double trial = update_information();
      if ( trial <= criterion )
        continue;

      save_weights( saved_weights );
      criterion = trial;
      if ( !R_finite( previous_criterion ) || previous_criterion <= 0.0 )
        return LineSearchStatus::rejected;
      return std::abs( ( previous_criterion - criterion ) / previous_criterion ) > k_ftol
        ? LineSearchStatus::improved
        : LineSearchStatus::tolerance_reached;
    } while ( step.step_length * shrink * max_direction > k_line_search_floor );

    restore_weights( saved_weights );
    return LineSearchStatus::rejected;
  }

  std::optional<int> find_removable_support( const ProtocolGrid& grid,
                                             int& inactive_weights ) {
    update_information();
    for ( int i = 0; i < active_size_; ++i ) {
      if ( weight( i ) > k_weight_floor )
        continue;
      const double gain = grid.directional_gain(
        active_.at( static_cast<size_t>( i ) ).candidate_index,
        inv_mixture_fim_.values()
      );
      if ( gain > static_cast<double>( param_dim_ ) ) {
        inactive_weights -= 1;
        return i;
      }
    }
    return std::nullopt;
  }

  int param_dim_;
  int max_support_;
  int active_size_;
  PackedFim mixture_fim_;
  PackedFim inv_mixture_fim_;
  double determinant_;
  bool fim_ready_;
  bool singular_fim_;
  std::vector<ActiveProtocol> active_;
  std::vector<double> scratch_weights_;
};

class FedorovWynnSolver {
public:
  FedorovWynnSolver( ProtocolGrid grid, WeightedDesign design, bool log_progress )
    : grid_( std::move( grid ) ),
      design_( std::move( design ) ),
      log_progress_( log_progress ) {}

  SolveStatus solve() {
    double determinant = design_.update_information();
    if ( design_.is_singular() )
      return SolveStatus::singular_fim;

    // Outer loop: Fedorov augmentation (add improving protocols) then Wynn
    // weight exchange on the current support. Breaks early when augmentation
    // finds no improving candidate (augmentation_complete_).
    // If the cycle budget is exhausted first, status is still "success":
    // weights may be usable but not fully converged — R only rejects non-success.
    for ( int cycle = 0; cycle < k_max_outer_iters; ++cycle ) {
      Rcpp::checkUserInterrupt();
      if ( !augment_until_stationary( determinant ) )
        return design_.is_singular() ? SolveStatus::singular_fim : SolveStatus::augmentation_failed;
      if ( augmentation_complete_ )
        break;

      const WynnOutcome wynn = design_.optimize_weights( grid_ );
      if ( wynn.status == WynnStatus::singular_fim )
        return SolveStatus::singular_fim;
      if ( wynn.status == WynnStatus::iteration_limit )
        return SolveStatus::weight_optimization_failed;

      design_.prune_inactive_support();
      if ( design_.active_size() > PackedFim::packed_size( design_.param_dim() ) )
        return SolveStatus::support_overflow;

      determinant = design_.update_information();
      if ( design_.is_singular() )
        return SolveStatus::singular_fim;
      if ( log_progress_ )
        Rcout << "Fedorov-Wynn cycle " << ( cycle + 1 ) << ": det = " << determinant << "\n";
    }
    return design_.is_singular() ? SolveStatus::singular_fim : SolveStatus::success;
  }

  const WeightedDesign& design() const { return design_; }

private:
  bool augment_until_stationary( double& determinant ) {
    int attempts = 0;
    augmentation_complete_ = false;
    do {
      // try_add_best_candidate returns false when no improving protocol remains
      // (or singular / invalid share) → augmentation_complete_ = true.
      augmentation_complete_ = !design_.try_add_best_candidate( grid_ );
      ++attempts;
      if ( !augmentation_complete_ )
        determinant = design_.update_information();
      // k_cold_start_det (-1e10) is a legacy log-det sentinel: with det>=0 it
      // never triggers; only singular_fim_ drives cold-start retries.
    } while ( ( determinant < k_cold_start_det || design_.is_singular() ) &&
              attempts < k_max_add_attempts );

    return !( attempts >= k_max_add_attempts &&
              ( determinant < k_cold_start_det || design_.is_singular() ) );
  }

  ProtocolGrid grid_;
  WeightedDesign design_;
  bool log_progress_;
  bool augmentation_complete_ = false;
};

WeightedDesign initial_design( const ProtocolGrid& grid,
                               const IntegerVector& initial_indices,
                               const NumericVector& initial_weights ) {
  if ( initial_indices.size() < 2 )
    stop( "Fedorov-Wynn: initial protocol indices are incomplete." );

  const int start_size = initial_indices[0];
  const int param_dim  = grid.count() > 0 ? grid.candidate( 0 ).information.param_dim() : 0;
  const int max_support = PackedFim::packed_size( param_dim ) + 1;

  if ( start_size <= 0 || param_dim <= 0 )
    stop( "Fedorov-Wynn: invalid initial support size." );
  if ( initial_indices.size() < start_size + 1 )
    stop( "Fedorov-Wynn: initial protocol indices do not match support size." );

  WeightedDesign design( param_dim, max_support );
  for ( int slot = 0; slot < start_size; ++slot ) {
    const int candidate = initial_indices[ slot + 1 ] - 1;
    if ( candidate < 0 || candidate >= grid.count() )
      stop( "Fedorov-Wynn: candidate index out of range." );
    if ( !design.append( candidate, initial_weights[ slot ], grid.candidate( candidate ) ) )
      stop( "Fedorov-Wynn: initial support exceeds capacity." );
  }
  return design;
}

}  // namespace fw

// [[Rcpp::export]]
Rcpp::List FedorovWynnAlgorithm_Rcpp(
    Rcpp::List    protocols,
    IntegerVector ndimen,
    IntegerVector nbprot,
    IntegerVector numprot,
    NumericVector freq,
    IntegerVector nbdata,
    NumericVector vectps,
    NumericVector fisher,
    IntegerVector error,
    IntegerVector protdep,
    NumericVector freqdep,
    bool          show_process = false )
{
  (void) nbprot;
  (void) error;

  if ( protocols.size() < 6 )
    stop( "Fedorov-Wynn: protocols list is incomplete." );

  const IntegerVector n_candidates      = as<IntegerVector>( protocols[0] );
  const IntegerVector n_times_vec       = as<IntegerVector>( protocols[1] );
  const IntegerVector param_dimensions  = as<IntegerVector>( protocols[2] );
  const IntegerVector total_cost        = as<IntegerVector>( ndimen );
  const NumericMatrix sample_times      = as<NumericMatrix>( protocols[4] );
  const NumericMatrix information_rows  = as<NumericMatrix>( protocols[5] );

  const int candidate_count = n_candidates[0];
  const int param_dim       = param_dimensions[0];
  const int n_times         = n_times_vec[0];
  const int total_subjects  = total_cost[2];

  if ( candidate_count <= 0 || param_dim <= 0 || n_times <= 0 || total_subjects <= 0 )
    stop( "Fedorov-Wynn: non-positive problem dimensions." );

  const double information_scale =
    static_cast<double>( total_subjects ) / static_cast<double>( n_times );

  // FIM rows were computed at n=1 per protocol; scale to total sample size.
  fw::ProtocolGrid grid = fw::ProtocolGrid::from_matrices(
    sample_times, information_rows, param_dim, n_times, information_scale
  );
  fw::WeightedDesign design = fw::initial_design( grid, protdep, freqdep );

  fw::FedorovWynnSolver solver(
    std::move( grid ), std::move( design ), show_process
  );
  const fw::SolveStatus status = solver.solve();

  const char* status_label = "success";
  switch ( status ) {
    case fw::SolveStatus::success:
      status_label = "success";
      break;
    case fw::SolveStatus::support_overflow:
      status_label = "support_overflow";
      break;
    case fw::SolveStatus::augmentation_failed:
      status_label = "augmentation_failed";
      break;
    case fw::SolveStatus::weight_optimization_failed:
      status_label = "weight_optimization_failed";
      break;
    case fw::SolveStatus::singular_fim:
      status_label = "singular_fim";
      break;
  }

  NumericMatrix optimal_sampling_times( candidate_count, n_times );

  if ( status == fw::SolveStatus::success ) {
    const fw::WeightedDesign& result = solver.design();
    double weight_sum = 0.0;

    for ( int i = 0; i < result.active_size(); ++i ) {
      const fw::ActiveProtocol& item = result.active_protocol( i );
      numprot[ i ] = item.candidate_index + 1;
      nbdata[ i ]  = static_cast<int>( item.sample_times.size() );
      freq[ i ]    = item.weight * information_scale;
      weight_sum  += freq[ i ];
      freqdep[ i ] = item.weight;
    }

    for ( int i = 0; i < result.active_size(); ++i ) {
      freq[ i ] /= weight_sum;
      const fw::ActiveProtocol& item = result.active_protocol( i );
      for ( int j = 0; j < static_cast<int>( item.sample_times.size() ); ++j ) {
        vectps[ j ] = item.sample_times[ static_cast<size_t>( j ) ];
        optimal_sampling_times( i, j ) = item.sample_times[ static_cast<size_t>( j ) ];
      }
    }

    for ( int k = 0; k < fw::PackedFim::packed_size( param_dim ); ++k )
      fisher[ k ] = result.mixture_fim()( k );
  }

  return List::create(
    Named( "freq" )                   = freq,
    Named( "optimal_sampling_times" ) = optimal_sampling_times,
    Named( "fisher" )                 = fisher,
    Named( "numprot" )                = numprot,
    Named( "status" )                 = status_label
  );
}
