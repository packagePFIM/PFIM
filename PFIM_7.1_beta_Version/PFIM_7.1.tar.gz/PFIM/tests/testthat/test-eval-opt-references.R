# Evaluation_tests / Optimisation_tests: D-criterion and FIM vs baked references.

for ( case in eval_opt_reference_cases() ) {
  local( {
    c <- case
    test_that( paste0( "eval-opt reference: ", c$id ), {
      if ( isTRUE( c$slow ) ) skip_on_cran()

      stats <- c$summarize( c$run() )
      expect_fim_summary_matches_reference( stats, c$reference, c$tol, label = c$id )

      M <- stats$fisherMatrix
      expect_true( is.matrix( M ) && isSymmetric( M, tol = 1e-8 ) )
      expect_gt( det( M ), 0 )
      expect_equal( nrow( M ), ncol( M ) )

      if ( !is.null( c$ref_html ) && !is.na( c$ref_html ) && file.exists( c$ref_html ) ) {
        html_parts <- Filter( Negate( is.null ), parse_report_fim_summaries( c$ref_html ) )
        idx <- c$html_index %||% 1L
        if ( length( html_parts ) >= idx ) {
          expect_equal(
            stats$d, html_parts[[ idx ]]$d,
            tolerance = ( c$tol$d %||% 1e-3 ) + 1e-6,
            info = paste0( c$id, ": D vs ", basename( c$ref_html ) )
          )
        }
      }
    } )
  } )
}

test_that( "parse_report_fim_summaries reads mult opt popFIM.html", {
  ref_root <- eval_opt_reference_root()
  skip_if( is.na( ref_root ), "tests_PFIM/resultats_de_references introuvable" )
  html <- file.path(
    ref_root,
    "Optimisation_tests/discrete/MultiplicativeAlgorithm",
    "multiplicative_Algorithm_PK_ode_dose_not_in_eqs_results/popFIM.html"
  )
  skip_if_not( file.exists( html ), "HTML de référence mult opt absent" )

  parts <- Filter( Negate( is.null ), parse_report_fim_summaries( html ) )
  expect_gte( length( parts ), 2L )
  expect_equal( parts[[ 1L ]]$d, 6810.422, tolerance = 1e-3 )
} )
