for ( case in cov_iov_evaluation_cases() ) {
  local( {
    c <- case
    test_that( paste0( "cov/IOV: ", c$id ), {
      evaluation <- run( build_cov_iov_evaluation( c ) )
      fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
      M   <- prop( fim, "fisherMatrix" )
      expect_true( is.matrix( M ) )
      expect_equal( ncol( M ), c$ncol )
      expect_gt( det( M ), 0 )

      if ( isTRUE( c$cov_test ) ) {
        ct <- covariateTest( evaluation, target_power = 0.90, alpha = 0.05 )
        expect_s3_class( ct, "PFIM::CovariateTest" )
        expect_gt( nrow( prop( ct, "covariate" ) ), 0L )
      }
    } )
  } )
}

test_that( "cas2 IOV without covariates matches population FIM reference", {
  cas <- Filter( function( x ) x$id == "cas2_noCov_withIOV", cov_iov_evaluation_cases() )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  M   <- prop( fim, "fisherMatrix" )

  expect_equal( as.numeric( Dcriterion( fim ) ), 2048.3263557128, tolerance = 1e-6 )
  expect_equal( M[ 1L, 1L ], 342.236485, tolerance = 1e-4 )
  expect_equal( M[ 8L, 8L ], 19961.4704, tolerance = 1e-3 )
  expect_equal( M[ 10L, 10L ], 36491.07585, tolerance = 1e-4 )
} )

test_that( "cas1 population FIM matches reference", {
  cas <- Filter( function( x ) x$id == "cas1_noCov_noIOV", cov_iov_evaluation_cases() )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  expect_equal( as.numeric( Dcriterion( fim ) ), 731.067615428391, tolerance = 1e-6 )
} )

test_that( "cas3 population FIM matches Monolix reference", {
  cas <- Filter( function( x ) x$id == "cas3_withCov_noIOV", cov_iov_evaluation_cases() )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  M   <- prop( fim, "fisherMatrix" )

  expect_equal( as.numeric( Dcriterion( fim ) ), 576.120006672508, tolerance = 1e-6 )
  expect_equal( M[ 1L, 1L ], 345.593647, tolerance = 1e-4 )
  expect_equal( M[ 5L, 5L ], 1493.4589259, tolerance = 1e-4 )
  expect_equal( M[ 8L, 8L ], 17000.86746, tolerance = 1e-4 )
} )

test_that( "cas4 population FIM matches reference", {
  cas <- Filter( function( x ) x$id == "cas4_withCov_withIOV", cov_iov_evaluation_cases() )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  expect_equal( as.numeric( Dcriterion( fim ) ), 1568.77419074749, tolerance = 1e-6 )
} )

test_that( "cas5 population FIM matches reference", {
  cas <- Filter( function( x ) x$id == "cas5_withCov_mixed", cov_iov_evaluation_cases() )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  expect_equal( as.numeric( Dcriterion( fim ) ), 1457.36661504908, tolerance = 1e-6 )
} )

test_that( "cas6 occasion covariate + IOV matches reference", {
  cas <- Filter(
    function( x ) x$id == "cas6_noCovFixed_withCovOccasion_withIOV",
    cov_iov_evaluation_cases()
  )[[ 1L ]]
  evaluation <- run( build_cov_iov_evaluation( cas ) )
  fim <- setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  M   <- prop( fim, "fisherMatrix" )

  expect_equal( as.numeric( Dcriterion( fim ) ), 1837.7481985995, tolerance = 1e-6 )
  expect_equal( M[ 1L, 1L ], 334.061402, tolerance = 1e-4 )
  expect_equal( M[ 10L, 10L ], 37340.564, tolerance = 1e-3 )
} )
