path <- system.file( "fixtures/cov-iov-poster.R", package = "PFIM" )
if ( !nzchar( path ) )
  stop( "inst/fixtures/cov-iov-poster.R introuvable." )
source( path, local = FALSE )
