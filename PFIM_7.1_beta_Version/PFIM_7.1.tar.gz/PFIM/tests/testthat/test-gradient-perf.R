test_that("gradient performance options preserve FIM results (ODE 1cpt)", {
  admin = Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
  st    = SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) )
  arm   = Arm(
    name = "arm", size = 40,
    administrations = list( admin ),
    samplingTimes   = list( st )
  )
  design = Design( name = "d", arms = list( arm ) )
  mp = list(
    ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
    ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ) ),
    ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
  )
  err = Constant( output = "RespPK", sigmaInter = 0.1 )
  ev = Evaluation(
    name = "perf_test",
    modelFromLibrary = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters  = mp,
    modelError       = list( err ),
    outputs          = list( "RespPK" ),
    designs          = list( design ),
    fimType          = "population",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )

  opts_off = list(
    perf.adminCache    = FALSE,
    perf.fdCache       = FALSE,
    perf.odeTimesCache = FALSE
  )
  opts_on = list(
    perf.adminCache    = TRUE,
    perf.fdCache       = TRUE,
    perf.odeTimesCache = TRUE
  )

  run_baseline = function( opts ) {
    old = setNames( lapply( names( opts ), pfim_get_option ), names( opts ) )
    do.call( pfim_set_option, opts )
    on.exit( do.call( pfim_set_option, old ), add = TRUE )
    out = run( ev )
    list(
      det = getDeterminant( out ),
      rse = getRSE( out )$RSE
    )
  }

  base = run_baseline( opts_off )
  fast = run_baseline( opts_on )

  expect_equal( fast$det, base$det, tolerance = 1e-6 )
  expect_equal( fast$rse, base$rse, tolerance = 1e-6 )
})

test_that( "finiteDifferenceHessian grid excludes fixedMu parameters", {
  pfim_reset_session()
  mp = list(
    ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
    ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ), fixedMu = TRUE ),
    ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
  )
  ev = Evaluation(
    name = "fd_fixed_mu",
    modelFromLibrary = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters  = mp,
    modelError       = list( Constant( output = "RespPK", sigmaInter = 0.1 ) ),
    outputs          = list( "RespPK" ),
    designs          = list( Design(
      name = "d",
      arms = list( Arm(
        name = "a", size = 40,
        administrations = list( Administration( outcome = "RespPK", timeDose = 0, dose = 100 ) ),
        samplingTimes   = list( SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) ) )
      ) )
    ) ),
    fimType = "population",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )
  model = rebuildEvalModel( ev, finiteDifference = TRUE )
  grid  = prop( model, "parametersForComputingGradient" )

  expect_equal( grid$freeIdx, c( 1L, 3L ) )
  expect_equal( ncol( grid$shifted ), 6L )

  ref = run( ev )
  expect_gt( getDeterminant( ref ), 0 )
})

test_that( "fixedMu population FIM excludes mu_V from the Fisher matrix", {
  mp = list(
    ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
    ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ), fixedMu = TRUE ),
    ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
  )
  ev = Evaluation(
    name = "fd_fixed_fim",
    modelFromLibrary = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters  = mp,
    modelError       = list( Constant( output = "RespPK", sigmaInter = 0.1 ) ),
    outputs          = list( "RespPK" ),
    designs          = list( Design(
      name = "d",
      arms = list( Arm(
        name = "a", size = 40,
        administrations = list( Administration( outcome = "RespPK", timeDose = 0, dose = 100 ) ),
        samplingTimes   = list( SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) ) )
      ) )
    ) ),
    fimType = "population",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )

  pfim_reset_session()
  on.exit( pfim_reset_session(), add = TRUE )

  out = run( ev )
  M   = prop( prop( out, "fim" ), "fisherMatrix" )
  se  = getRSE( out )$Parameter

  expect_false( any( grepl( "mu_V|μ_V", se, fixed = FALSE ) ) )
  expect_gt( getDeterminant( out ), 0 )
  expect_true( all( is.finite( M ) ) )
})

test_that( "fixedMu individual FIM with covariates excludes mu_V (aligns with population)", {
  mp = list(
    ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
    ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ), fixedMu = TRUE ),
    ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
  )
  sex = Covariate(
    name = "Sex", categories = c( "M", "F" ), categoriesProportions = c( 0.5, 0.5 ),
    effects = list( "F" = c( "Cl" = log( 1.2 ) ) )
  )
  ev = Evaluation(
    name = "ind_fixed_mu_cov",
    modelFromLibrary        = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters         = mp,
    modelCovariates         = list( sex ),
    modelCovariatesEquation = "exponential",
    modelError              = list( Constant( output = "RespPK", sigmaInter = 0.1 ) ),
    outputs                 = list( "RespPK" ),
    designs = list( Design(
      name = "d",
      arms = list( Arm(
        name = "a", size = 40,
        administrations = list( Administration( outcome = "RespPK", timeDose = 0, dose = 100 ) ),
        samplingTimes   = list( SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) ) )
      ) )
    ) ),
    fimType = "individual",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )

  pfim_reset_session()
  on.exit( pfim_reset_session(), add = TRUE )

  out = run( ev )
  fim = setEvaluationFim( prop( out, "fim" ), out )
  M   = prop( fim, "fisherMatrix" )
  rn  = rownames( M )

  expect_false( any( grepl( "mu_V|μ_V|_V$", rn ) & grepl( "mu|μ", rn ) ) )
  expect_false( any( grepl( "^mu_V$|^μ_V$", rn ) ) )
  expect_true( any( grepl( "mu_ka|μ_ka", rn ) ) )
  expect_true( any( grepl( "mu_Cl|μ_Cl", rn ) ) )
  expect_true( any( grepl( "beta_|β_", rn ) ) )
  expect_true( all( is.finite( M ) ) )
  expect_true( is.finite( det( M ) ) && abs( det( M ) ) > 0 )
})

test_that( "FD grid has 1 + 2*n + n(n-1)/2 columns by default", {
  grid = PFIM:::.pfimFiniteDifferenceGrid( c( 1, 3.5, 2 ), seq_len( 3L ) )
  expect_equal( ncol( grid$shifted ), 10L )
} )

test_that( "perf.fdLinearOnly reduces FD grid to 1 + 2*n columns", {
  local_pfim_opts( list( perf.fdLinearOnly = TRUE ) )
  grid = PFIM:::.pfimFiniteDifferenceGrid( c( 1, 3.5, 2 ), seq_len( 3L ) )
  expect_equal( ncol( grid$shifted ), 7L )
} )

test_that( "linear FD stencil is close to quadratic on 1cpt ODE", {
  local_pfim_opts( list( perf.fdLinearOnly = FALSE, perf.fdCache = FALSE ) )
  ev = Evaluation(
    name = "fd_linear_cmp",
    modelFromLibrary = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters  = list(
      ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
      ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ) ),
      ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
    ),
    modelError = list( Constant( output = "RespPK", sigmaInter = 0.1 ) ),
    outputs    = list( "RespPK" ),
    designs    = list( Design(
      name = "d",
      arms = list( Arm(
        name = "a", size = 40,
        administrations = list( Administration( outcome = "RespPK", timeDose = 0, dose = 100 ) ),
        samplingTimes   = list( SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) ) )
      ) )
    ) ),
    fimType = "population",
    odeSolverParameters = list()
  )

  run_fd = function( linearOnly ) {
    local_pfim_opts( list( perf.fdLinearOnly = linearOnly, perf.fdCache = FALSE ) )
    getDeterminant( run( ev ) )
  }

  d_quad = run_fd( FALSE )
  d_lin  = run_fd( TRUE )
  expect_gt( d_quad, 0 )
  expect_gt( d_lin, 0 )
  expect_equal( d_lin, d_quad, tolerance = 1e-4 )
} )
