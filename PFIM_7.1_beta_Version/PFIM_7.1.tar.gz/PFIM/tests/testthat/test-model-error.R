# Residual error variance (sigmaInter + sigmaSlope * f^cError)^2.

test_that("cError applies power to proportional term", {
  err <- Combined1( output = "RespPK", sigmaInter = 0.2, sigmaSlope = 0.3, cError = 2 )
  f   <- c( 1, 2 )
  res <- evaluateErrorModelDerivatives( err, f )
  expect_equal( diag( res$errorVariance ), ( 0.2 + 0.3 * f^2 )^2 )
  expect_equal( res$sigmaDerivatives$sigmaInter[ 1L, 1L ], 2 * ( 0.2 + 0.3 ) )
  expect_equal( res$sigmaDerivatives$sigmaSlope[ 2L, 2L ], 2 * ( 0.2 + 0.3 * 4 ) * 4 )
})

test_that("cError = 1 matches linear proportional term", {
  f <- c( 1.5, 2 )
  err_c <- Combined1( output = "RespPK", sigmaInter = 0.1, sigmaSlope = 0.2, cError = 1 )
  err_l <- Combined1( output = "RespPK", sigmaInter = 0.1, sigmaSlope = 0.2 )
  expect_equal(
    evaluateErrorModelDerivatives( err_c, f ),
    evaluateErrorModelDerivatives( err_l, f )
  )
})

test_that("Constant rejects nonzero sigmaSlope", {
  expect_error(
    Constant( output = "RespPK", sigmaInter = 0.1, sigmaSlope = 0.05 ),
    "sigmaSlope must be 0",
    fixed = TRUE
  )
})

test_that("Proportional rejects nonzero sigmaInter", {
  expect_error(
    Proportional( output = "RespPK", sigmaInter = 0.1, sigmaSlope = 0.2 ),
    "sigmaInter must be 0",
    fixed = TRUE
  )
})

test_that("getModelErrorData reports cError", {
  err <- Combined1( output = "RespPK", sigmaInter = 0.1, sigmaSlope = 0.2, cError = 1.5 )
  row <- getModelErrorData( err )
  expect_equal( row$cError, "1.5" )
})
