test_that( "FD gradient preserves nominal model parameters", {
  ev = Evaluation(
    name = "fd_mu_preserve",
    modelFromLibrary = list( PKModel = "Linear1BolusSingleDose_kV" ),
    modelParameters = list(
      ModelParameter( name = "k", distribution = LogNormal( mu = 0.5, omega = 0.2 ) ),
      ModelParameter( name = "V", distribution = LogNormal( mu = 3.5, omega = 0.3 ) )
    ),
    modelError = list( Constant( output = "RespPK", sigmaInter = 0.1 ) ),
    outputs = list( RespPK = "C1" ),
    designs = list( Design(
      name = "d",
      arms = list( Arm(
        name = "a", size = 40,
        administrations = list(
          Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
        ),
        samplingTimes = list(
          SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 6, 12 ) )
        )
      ) )
    ) ),
    fimType = "population"
  )
  model = rebuildEvalModel( ev, finiteDifference = TRUE )
  arm   = prop( prop( ev, "designs" )[[ 1L ]], "arms" )[[ 1L ]]
  mu_before = map_dbl(
    prop( model, "modelParameters" ),
    ~ prop( prop( .x, "distribution" ), "mu" )
  )

  evaluateModelGradient( model, arm )

  mu_after = map_dbl(
    prop( model, "modelParameters" ),
    ~ prop( prop( .x, "distribution" ), "mu" )
  )
  expect_equal( mu_after, mu_before )
} )

test_that( "evaluateDesign matches independent per-arm runs", {
  fx     = cas10_design()
  design = cas10_design_two_arms()
  shared_ev = Evaluation(
    name                    = "two_arm_shared",
    modelFromLibrary        = cas10_model_from_library(),
    modelParameters         = cas10_model_parameters(),
    modelCovariates         = cas10_covariates(),
    modelCovariatesEquation = "exponential",
    modelError              = fx$modelError,
    designs                 = list( design ),
    fimType                 = "individual",
    outputs                 = list( "RespPK" ),
    odeSolverParameters     = list( atol = 1e-8, rtol = 1e-8 )
  )
  model    = rebuildEvalModel( shared_ev, finiteDifference = TRUE )
  fimProto = IndividualFim()
  shared   = evaluateDesign( design, model, fimProto )

  run_one_arm = function( arm ) {
    solo = Design( name = prop( design, "name" ), arms = list( arm ) )
    ev = Evaluation(
      name                    = "solo",
      modelFromLibrary        = cas10_model_from_library(),
      modelParameters         = cas10_model_parameters(),
      modelCovariates         = cas10_covariates(),
      modelCovariatesEquation = "exponential",
      modelError              = fx$modelError,
      designs                 = list( solo ),
      fimType                 = "individual",
      outputs                 = list( "RespPK" ),
      odeSolverParameters     = list( atol = 1e-8, rtol = 1e-8 )
    )
    m = rebuildEvalModel( ev, finiteDifference = TRUE )
    evaluateDesign( solo, m, IndividualFim() )
  }

  arms = prop( design, "arms" )
  for ( i in seq_along( arms ) ) {
    M_shared = prop(
      prop( prop( shared, "evaluationArms" )[[ i ]], "evaluationFim" ),
      "fisherMatrix"
    )
    M_solo = prop(
      prop( prop( run_one_arm( arms[[ i ]] ), "evaluationArms" )[[ 1L ]], "evaluationFim" ),
      "fisherMatrix"
    )
    expect_equal( M_shared, M_solo, tolerance = 1e-8 )
  }
} )

test_that( "checkValiditySamplingConstraint rejects infeasible windows", {
  arm = Arm(
    name = "a", size = 40,
    administrations = list(
      Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
    ),
    samplingTimes = list(
      SamplingTimes( outcome = "RespPK", samplings = c( 1, 2, 3 ) )
    ),
    samplingTimesConstraints = list(
      SamplingTimeConstraints(
        outcome                = "RespPK",
        samplingsWindows       = list( c( 0, 0.5 ) ),
        numberOfTimesByWindows = c( 3L ),
        minSampling            = 1
      )
    )
  )
  design = Design( name = "bad", arms = list( arm ) )
  expect_error(
    checkValiditySamplingConstraint( design ),
    "sampling times constraint is not possible"
  )
} )

test_that( "generateSamplingTimesCombination validates combn inputs", {
  arm = Arm(
    name = "a", size = 40,
    administrations = list(
      Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
    ),
    samplingTimes = list(
      SamplingTimes( outcome = "RespPK", samplings = c( 1, 2 ) )
    ),
    samplingTimesConstraints = list(
      SamplingTimeConstraints(
        outcome                      = "RespPK",
        initialSamplings             = c( 1, 2, 3, 4 ),
        fixedTimes                   = c( 1, 2 ),
        numberOfsamplingsOptimisable = 1
      )
    )
  )
  design = Design( name = "d", arms = list( arm ) )
  expect_error(
    generateSamplingTimesCombination( design ),
    "cannot be less than the number of fixed times"
  )
} )

test_that( "MultiplicativeAlgorithm_Rcpp reports singular FIM", {
  p   = 2L
  bad = matrix( c( 1, 1, 1, 1 ), 2, 2 )
  res = MultiplicativeAlgorithm_Rcpp(
    fisherMatrices = list( bad, bad ),
    n_fim = 2L,
    weights = c( 0.5, 0.5 ),
    p = p,
    lambda = 0.99,
    delta = 1e-3,
    iteration_init = 5L,
    show_process = FALSE
  )
  expect_true( isTRUE( res$singularFim ) )
  expect_false( isTRUE( res$converged ) )
} )

test_that( "continuous optimizers preserve distinct initial and optimal evaluations", {
  algos = c( "PSOAlgorithm", "PGBOAlgorithm", "SimplexAlgorithm" )
  for ( algo in algos ) {
    opt = suppressWarnings( run(
      .minimal_continuous_opt( algo, name = paste0( "init_opt_", algo ) )
    ) )
    od = prop( opt, "optimisationDesign" )
    expect_false( identical( od$evaluationInitialDesign, od$evaluationOptimalDesign ) )
    init_ev = od$evaluationInitialDesign
    opt_ev  = od$evaluationOptimalDesign
    init_arm = prop( prop( init_ev, "evaluationDesign" )[[ 1L ]], "arms" )[[ 1L ]]
    opt_arm  = prop( prop( opt_ev,  "evaluationDesign" )[[ 1L ]], "arms" )[[ 1L ]]
    expect_false( identical( init_arm, opt_arm ) )
  }
} )

test_that( "pso_optimize_Rcpp rejects non-positive population size", {
  expect_error(
    PFIM:::pso_optimize_Rcpp(
      n_pop_in = 0L, max_iter = 1L, initial_pos = c( 1, 2 ),
      windows_list = list( matrix( c( 0, 10 ), 1 ), matrix( c( 0, 10 ), 1 ) ),
      sorting_groups = list( c( 1L, 2L ) ),
      phi1 = 2.05, phi2 = 2.05, constriction = 0.7, show_process = FALSE,
      eval_fitness = function( x ) sum( x^2 )
    ),
    "n_pop_in must be positive"
  )
} )
