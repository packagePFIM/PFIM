# Unit tests for numerical helpers and CRAN packaging invariants.

test_that("getDcriterion on identity FIM equals 1", {
  fim = IndividualFim()
  prop( fim, "fisherMatrix" ) = diag( 3L )
  expect_equal( PFIM:::Dcriterion( fim ), 1 )
})

test_that("getDeterminant matches Dcriterion^(p) on the FIM", {
  fim = IndividualFim()
  M   = diag( c( 4, 9, 16 ) )
  prop( fim, "fisherMatrix" ) = M
  expect_equal( PFIM:::.fimDeterminant( M ), PFIM:::Dcriterion( fim )^3 )
})

test_that("condition number is Inf for indefinite FIM", {
  M = matrix( c( 1, 2, 2, -1 ), 2, 2 )
  expect_equal( PFIM:::.conditionNumber( M ), Inf )
})

test_that("LibraryOfPKModels class is not shadowed by default instance", {
  expect_true( is.function( LibraryOfPKModels ) )
  expect_s7_class( PFIM:::pkModelLibrary, LibraryOfPKModels )
  expect_s7_class( PFIM:::pdModelLibrary, LibraryOfPDModels )
  expect_gt( length( prop( PFIM:::pkModelLibrary, "models" ) ), 0L )
})

test_that("Administration aligns single timeDose for multiple doses", {
  admin = Administration( outcome = "RespPK", timeDose = c( 0 ), dose = c( 1, 2 ) )
  aligned = getFromNamespace( ".alignAdministrationDosing", "PFIM" )( admin )
  expect_equal( aligned$timeDose, c( 0, 0 ) )
  expect_equal( aligned$dose, c( 1, 2 ) )
  expect_s7_class(
    Administration( outcome = "RespPK", tau = 24, dose = 5500 ),
    Administration
  )
})

test_that("Administration validator rejects incompatible timeDose and dose lengths", {
  expect_error(
    Administration( outcome = "RespPK", timeDose = c( 0, 1 ), dose = c( 1, 2, 3 ) ),
    "length\\(timeDose\\)"
  )
})

test_that("Arm validator rejects negative size", {
  expect_error( Arm( name = "a1", size = -1 ), "size must be non-negative" )
})

test_that("Arm validator rejects non-Administration administrations", {
  expect_error(
    Arm( name = "a1", administrations = list( list( dose = 1 ) ) ),
    "Administration"
  )
})

test_that("Design validator rejects non-Arm arms", {
  expect_error(
    Design( name = "d1", arms = list( list( name = "a1" ) ) ),
    "Arm"
  )
})

test_that("SamplingTimeConstraints accepts scalar minSampling with multiple windows", {
  expect_s7_class(
    SamplingTimeConstraints(
      outcome                      = "RespPK",
      samplingsWindows             = list( c( 1, 2 ), c( 3, 4 ) ),
      numberOfTimesByWindows       = c( 2, 2 ),
      minSampling                  = 0.5
    ),
    SamplingTimeConstraints
  )
})

test_that("SamplingTimeConstraints validator rejects inconsistent window vectors", {
  expect_error(
    SamplingTimeConstraints(
      outcome                      = "RespPK",
      samplingsWindows             = list( c( 0, 1 ), c( 2, 3 ) ),
      numberOfTimesByWindows       = c( 1, 2, 3 ),
      minSampling                  = 0.5
    ),
    "numberOfTimesByWindows length"
  )
})

test_that("SamplingTimeConstraints validator rejects too many optimisable samplings", {
  expect_error(
    SamplingTimeConstraints(
      outcome                      = "RespPK",
      initialSamplings             = c( 1, 2 ),
      numberOfsamplingsOptimisable = 3
    ),
    "numberOfsamplingsOptimisable"
  )
})

test_that("Optimization uses composition (project slot)", {
  opt = Optimization(
    name = "opt_test",
    fimType = "individual",
    fim = IndividualFim(),
    designs = list()
  )
  expect_equal( projectProp( opt, "fimType" ), "individual" )
  expect_s7_class( prop( opt, "project" ), PFIMProject )
  expect_false( S7::S7_inherits( opt, PFIMProject ) )
})

test_that("Covariate is exported from NAMESPACE", {
  expect_true( "Covariate" %in% getNamespaceExports( "PFIM" ) )
})

test_that("tost is exported and documented as covariateTest alias", {
  expect_true( "tost" %in% getNamespaceExports( "PFIM" ) )
  expect_identical( getFromNamespace( "tost", "PFIM" ), covariateTest )
  rd <- testthat::test_path( "../../man/covariateTest.Rd" )
  skip_if_not( file.exists( rd ), "source Rd unavailable in installed-package check" )
  lines <- readLines( rd, warn = FALSE )
  expect_true( any( grepl( "^\\\\alias\\{tost\\}", lines ) ) )
})

test_that("generateDosesCombination enumerates dose grids", {
  admin = Administration( outcome = "RespPK", timeDose = 0, dose = 10 )
  ac = AdministrationConstraints( outcome = "RespPK", doses = as.list( c( 10, 20 ) ) )
  arm = Arm(
    name = "a1",
    size = 10,
    administrations = list( admin ),
    administrationsConstraints = list( ac )
  )
  design = Design( name = "d1", arms = list( arm ) )
  out = PFIM:::generateDosesCombination( design )
  expect_equal( out$numberOfDoses, 2L )
  expect_equal( out$a1$RespPK, c( 10, 20 ) )
})

test_that( "proportional subject allocation keeps two decimal places", {
  expect_equal(
    PFIM:::.allocProportionalSubjects( 100, c( 1, 1, 1 ) ),
    c( 33.33, 33.33, 33.33 )
  )
  expect_equal(
    PFIM:::.allocProportionalSubjects( 300, c( 1, 2, 1 ) ),
    c( 75, 150, 75 )
  )
  expect_equal(
    PFIM:::.allocProportionalSubjects( 100, c( 0.3003, 0.6997 ) ),
    c( 30.03, 69.97 )
  )
})

test_that( "population multiplicative N uses design numberOfArms like CRAN", {
  algo = MultiplicativeAlgorithm()
  prop( algo, "multiplicativeAlgorithmOutputs" ) = list(
    numberOfArms = 100,
    weightsIndex = c( 25L, 49L ),
    optimalWeights = c( 0.3003, 0.6997 )
  )
  cell = list( entries = list( list( arm = Arm( name = "x", size = 50 ) ) ) )
  cells = setNames( rep( list( cell ), 49 ), as.character( seq_len( 49 ) ) )
  N = PFIM:::.multiplicativePopulationNTotal( algo, cells, c( 25L, 49L ) )
  expect_equal( N, 100 )
  expect_equal(
    PFIM:::.allocProportionalSubjects( N, c( 0.3003, 0.6997 ) ),
    c( 30.03, 69.97 )
  )
})
