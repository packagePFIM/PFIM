# End-to-end optimization: all algorithms, Multiplicative grid, Fedorov-Wynn C++.

test_that("FedorovWynnAlgorithm: run() completes with valid optimal design", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_discrete_opt( "FedorovWynnAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("PSOAlgorithm: run() completes with valid optimal design", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_continuous_opt( "PSOAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("PGBOAlgorithm: run() completes with valid optimal design", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_continuous_opt( "PGBOAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("PGBOAlgorithm: optimal D-criterion is not worse than initial", {
  .skip_optimizer_run_on_cran()
  opt = run( .minimal_continuous_opt( "PGBOAlgorithm", name = "pgbo_best_d" ) )
  od = prop( opt, "optimisationDesign" )
  d_init = getDcriterion( od$evaluationInitialDesign )
  d_opt  = getDcriterion( od$evaluationOptimalDesign )
  expect_gte( d_opt, d_init )
})

test_that("pgbo_optimize_Rcpp fitness uses cost = 1/D (climbs toward higher D)", {
  # Regression for the Rcpp port: Metropolis must use cost = 1/D, not raw D.
  # With inverted fitness the resident walks downhill and bestD stays near the start.
  set.seed( 42 )
  eval_d = function( pos ) {
    as.numeric( 100 - ( pos[[ 1L ]] - 5 )^2 - ( pos[[ 2L ]] - 8 )^2 )
  }
  check_valid = function( pos, group_idx ) {
    all( is.finite( pos ) ) &&
      pos[[ 1L ]] <= pos[[ 2L ]] - 0.1 &&
      all( pos >= 0 ) && all( pos <= 10 )
  }
  out = PFIM:::pgbo_optimize_Rcpp(
    initial_pos     = c( 1, 2 ),
    sorting_groups  = list( 1:2 ),
    max_iteration   = 300L,
    N               = 20L,
    mute_effect     = 0.6,
    purge_iteration = 50L,
    fit_base        = 0.5,
    max_attempts    = 5000L,
    cauchy_prob     = 0.5,
    show_process    = FALSE,
    eval_d          = eval_d,
    check_valid_group = check_valid
  )
  expect_gt( out$bestD, out$initialD )
  expect_gt( out$bestD, 80 )
})

test_that("SimplexAlgorithm: run() completes with valid optimal design", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_continuous_opt( "SimplexAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("MultiplicativeAlgorithm: run() completes with valid optimal design", {
  opt = .minimal_discrete_opt( "MultiplicativeAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("generateFimsFromConstraints returns constraint-grid FIMs", {
  opt = .minimal_discrete_opt( "MultiplicativeAlgorithm" )
  res = generateFimsFromConstraints( opt )
  expect_type( res, "list" )
  expect_true( length( res$listFimsAlgoMult ) >= 1L )
  expect_gte( nrow( res$listFimsAlgoMult[[ 1L ]][[ 1L ]] ), 1L )
})

test_that("generateFimsFromConstraints: multi-arm joint FIM grid", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_discrete_opt_multi_arm( n_arms = 2L )
  res = generateFimsFromConstraints( opt )
  expect_length( PFIM:::.constraintCellArms( res$listArms[[ 1L ]][[ 1L ]] ), 2L )
  dims = unique( map_int( res$listFimsAlgoMult[[ 1L ]], nrow ) )
  expect_length( dims, 1L )
  expect_gt( dims, 0L )
})

test_that("generateFimsFromConstraints: multi-arm with covariates", {
  .skip_optimizer_run_on_cran()
  arms   = map( c( "arm1", "arm2" ), ~ .minimal_discrete_arm( .x, size = 40 ) )
  design = Design( name = "cov_multi", arms = arms )
  fx     = cas10_design()
  opt    = Optimization(
    name                    = "multi_cov_grid",
    modelFromLibrary        = cas10_model_from_library(),
    modelParameters         = cas10_model_parameters(),
    modelCovariates         = cas10_covariates(),
    modelCovariatesEquation = "exponential",
    modelError              = fx$modelError,
    designs                 = list( design ),
    fimType                 = "individual",
    optimizer               = "MultiplicativeAlgorithm",
    optimizerParameters     = list(
      lambda = 0.99, numberOfIterations = 5,
      weightThreshold = 0.01, delta = 1e-4
    ),
    outputs                 = list( "RespPK" ),
    odeSolverParameters     = list( atol = 1e-8, rtol = 1e-8 )
  )
  res = generateFimsFromConstraints( opt )
  expect_length( PFIM:::.constraintCellArms( res$listArms[[ 1L ]][[ 1L ]] ), 2L )
  expect_true( all( map_lgl( res$listFimsAlgoMult[[ 1L ]], ~ all( is.finite( .x ) ) ) ) )
})

test_that("MultiplicativeAlgorithm: multi-arm discrete run completes", {
  .skip_optimizer_run_on_cran()
  opt = run( .minimal_discrete_opt_multi_arm( n_arms = 2L ) )
  eval_opt = prop( opt, "optimisationDesign" )$evaluationOptimalDesign
  arms     = prop( prop( eval_opt, "designs" )[[ 1L ]], "arms" )
  expect_length( arms, 2L )
  expect_gt( getDcriterion( opt ), 0 )
})

test_that("optimizerParameters: unknown name suggests fix", {
  expect_error(
    .minimal_discrete_opt(
      "MultiplicativeAlgorithm",
      optimizerParameters = list(
        Lambda = 0.99, delta = 1e-4, numberOfIterations = 5, weightThreshold = 0.01
      )
    ),
    "did you mean 'lambda'",
    fixed = TRUE
  )
})

test_that("optimizerParameters: missing required names fail at construction", {
  expect_error(
    .minimal_discrete_opt(
      "MultiplicativeAlgorithm",
      optimizerParameters = list( lambda = 0.99 )
    ),
    "Missing optimizerParameters",
    fixed = TRUE
  )
})

test_that("MultiplicativeAlgorithm: run() fills optimal design and improves D-criterion", {
  .skip_optimizer_run_on_cran()
  opt = .minimal_mult_opt()

  combos = generateSamplingTimesCombination( projectProp( opt, "designs" )[[ 1L ]] )
  expect_gte( length( combos$opt_arm ), 2L )

  opt = run( opt )

  od = prop( opt, "optimisationDesign" )
  expect_type( od, "list" )
  expect_s7_class( od$evaluationInitialDesign, Evaluation )
  expect_s7_class( od$evaluationOptimalDesign, Evaluation )

  det_init = getDeterminant( od$evaluationInitialDesign )
  det_opt  = getDeterminant( od$evaluationOptimalDesign )
  expect_true( is.finite( det_init ) && det_init > 0 )
  expect_true( is.finite( det_opt ) && det_opt > 0 )

  weights = prop( opt, "optimisationAlgorithmOutputs" )$optimalWeights
  expect_true( length( weights ) >= 1L )
  expect_true( all( weights > 0 ) )

  expect_gt( getDcriterion( opt ), 0 )
})

test_that( "constraint grid stores independent arm snapshots per cell", {
  .skip_optimizer_run_on_cran()
  local_pfim_opts( list( fim.cache = FALSE ) )
  opt   = .minimal_mult_pop_dose_grid()
  fims  = generateFimsFromConstraints( opt )
  cells = fims$listArms[[ 1L ]]
  dose_at = function( i ) {
    arm = PFIM:::.constraintCellArms( cells[[ i ]] )[[ 1L ]]
    prop( prop( arm, "administrations" )[[ 1L ]], "dose" )
  }
  n_comb = length( generateSamplingTimesCombination(
    projectProp( opt, "designs" )[[ 1L ]]
  )$grid_arm )
  expect_equal( dose_at( 1L ), 50 )
  expect_equal( dose_at( n_comb + 1L ), 100 )
})

test_that( "generateSamplingTimesCombination yields independent copies per cell", {
  opt    = .minimal_mult_opt()
  design = projectProp( opt, "designs" )[[ 1L ]]
  combos = generateSamplingTimesCombination( design )$opt_arm
  expect_gte( length( combos ), 2L )
  samplings = lapply( combos, function( entry ) {
    sort( prop( entry[[ 1L ]], "samplings" ) )
  } )
  expect_equal( length( unique( samplings ) ), length( samplings ) )
})

test_that( "population multiplicative: arm sizes follow optimal weights", {
  .skip_optimizer_run_on_cran()
  local_pfim_opts( list( fim.cache = FALSE ) )
  opt     = run( .minimal_mult_pop_dose_grid() )
  outputs = prop(
    prop( opt, "optimisationAlgorithmOutputs" )$optimizationAlgorithm,
    "multiplicativeAlgorithmOutputs"
  )
  weights = outputs$optimalWeights
  N       = outputs$numberOfArms
  if ( !length( N ) || !is.finite( N ) || N <= 0 ) {
    init_design = prop(
      prop( opt, "optimisationDesign" )$evaluationInitialDesign,
      "designs"
    )[[ 1L ]]
    N = prop( prop( init_design, "arms" )[[ 1L ]], "size" )
  }
  design = prop(
    prop( opt, "optimisationDesign" )$evaluationOptimalDesign,
    "designs"
  )[[ 1L ]]
  arms  = prop( design, "arms" )
  sizes = map_dbl( arms, ~ prop( .x, "size" ) )
  expect_equal(
    sort( sizes ),
    sort( PFIM:::.allocProportionalSubjects( N, weights ) )
  )
})

test_that( "population multiplicative: optimal D matches algorithm mixture", {
  .skip_optimizer_run_on_cran()
  local_pfim_opts( list( fim.cache = FALSE ) )
  opt     = run( .minimal_mult_pop_dose_grid() )
  algo    = prop( opt, "optimisationAlgorithmOutputs" )$optimizationAlgorithm
  outputs = prop( algo, "multiplicativeAlgorithmOutputs" )
  w       = outputs$multiplicativeAlgorithmOutput$weights
  mats    = outputs$fisherMatrices
  M_mix   = Reduce( `+`, Map( `*`, mats, w ) )
  D_mix   = PFIM:::.fimDcriterionFromMatrix( M_mix )
  D_opt   = getDcriterion( opt )
  expect_equal( D_opt, D_mix, tolerance = 1e-2 )
})

test_that( "MultiplicativeAlgorithm_Rcpp: converged false at iteration limit", {
  set.seed( 1L )
  p <- 3L
  mk <- function() crossprod( matrix( rnorm( 20L * p ), 20L, p ) ) + diag( p )
  out <- MultiplicativeAlgorithm_Rcpp(
    list( mk(), mk() ), 2L, rep( 0.5, 2L ), p,
    lambda = 0.5, delta = 1e-12, iteration_init = 1L, show_process = FALSE
  )
  expect_false( out$converged )
  expect_equal( out$iterationEnd, 1L )
})

test_that("Fedorov-Wynn buffer sizes follow FIM dimension, not protocol count", {
  buf = getFromNamespace( ".fedorovWynnBufferSizes", "PFIM" )( 4L, 3L )
  expect_equal( buf$nFisher, 10L )
  expect_equal( buf$nMaxPop, 11L )
  expect_equal( buf$nBuf, 11L )
  expect_gt( buf$nFisher, 3L * 4L / 2L )
})

test_that("FedorovWynnAlgorithm run() has no C++ subscript warnings", {
  .skip_optimizer_run_on_cran()
  expect_no_warning(
    run( .minimal_discrete_opt( "FedorovWynnAlgorithm", name = "fw_cpp_buffers" ) )
  )
})

test_that("FedorovWynnAlgorithm converges with ndimFim > nProtocols grid", {
  .skip_optimizer_run_on_cran()
  opt = expect_no_warning(
    run( .minimal_discrete_opt( "FedorovWynnAlgorithm", name = "fw_cpp_conv" ) )
  )
  od = prop( opt, "optimisationDesign" )
  expect_s7_class( od$evaluationOptimalDesign, Evaluation )
  expect_gt( getDeterminant( od$evaluationOptimalDesign ), 0 )
  expect_gt( getDcriterion( opt ), 0 )
})
