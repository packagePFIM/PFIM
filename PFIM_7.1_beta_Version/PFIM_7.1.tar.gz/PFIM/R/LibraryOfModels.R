#' @title LibraryOfModels
#' @description
#' Registry of built-in PK and PD model definitions.
#'
#' Subclasses \code{LibraryOfPKModels} and \code{LibraryOfPDModels} store named
#' equation lists; \code{defineModelEquationsFromLibraryOfModel()} looks them up
#' via the package instances \code{pkModelLibrary} / \code{pdModelLibrary}.
#' @param models List of PK and PD model metadata objects.
#' @return An S7 object of class \code{LibraryOfModels}.
#' @examples
#' \donttest{
#' length(prop(pkModelLibrary, "models"))
#' length(prop(pdModelLibrary, "models"))
#' }
#' @export

LibraryOfModels = new_class("LibraryOfModels", package = "PFIM",

                       properties = list(
                         models = new_property( class_list, default = list())))

