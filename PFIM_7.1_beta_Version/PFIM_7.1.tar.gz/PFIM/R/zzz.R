# Package load hooks and S7/S4 method registration.
#
# On load: optionally record the source tree as `devPath` (when developing from
# a checkout), register selected S7 classes with S4 for method dispatch, then
# call `S7::methods_register()`.

#' Register S7 classes that need S4 method tables (show, etc.).
#' @noRd
#' @keywords internal
.registerS7WithS4 = function(pkgname) {
  ns = asNamespace(pkgname)
  for (nm in c(
    "BayesianFim", "CovariateTest", "Evaluation", "FedorovWynnAlgorithm",
    "IndividualFim", "MultiplicativeAlgorithm", "Optimization",
    "PGBOAlgorithm", "PopulationFim", "PSOAlgorithm", "SimplexAlgorithm"
  )) {
    if (exists(nm, envir = ns, inherits = FALSE)) {
      S4_register(get(nm, envir = ns))
    }
  }
}

#' Package \code{.onLoad}: set \code{devPath} when present, register S7/S4 methods.
#' @noRd
#' @keywords internal
.onLoad = function(libname, pkgname) {
  ns = asNamespace( pkgname )
  # Parent of the installed package path is the source tree during load_all().
  pkg_root = normalizePath( file.path( getNamespaceInfo( ns, "path" ), ".." ), winslash = "/" )
  if ( file.exists( file.path( pkg_root, "DESCRIPTION" ) ) &&
       is.null( pfim_get_option( "devPath" ) ) )
    pfim_set_option( devPath = pkg_root )
  .registerS7WithS4( pkgname )
  S7::methods_register()
}

# Silence R CMD check notes for magrittr/purrr placeholder `.`.
utils::globalVariables(c("."))
