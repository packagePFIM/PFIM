#' @title Constant
#' @description
#' Pure additive residual error: constant variance \code{sigmaInter^2}.
#' @inheritParams ModelError
#' @include ModelError.R
#' @return An S7 object of class \code{Constant}.
#' @export

Constant = new_class( "Constant", package = "PFIM", parent = ModelError,
                     constructor = function( output = character( 0 ),
                                            equation = expression( sigmaInter ),
                                            derivatives = list(),
                                            sigmaInter = 0.0,
                                            sigmaSlope = 0.0,
                                            sigmaInterFixed = FALSE,
                                            sigmaSlopeFixed = FALSE,
                                            cError = 1.0 ) {
                       .checkModelErrorSigmas( sigmaInter, sigmaSlope, cError )
                       # Pure additive: proportional slope must be zero.
                       if ( sigmaSlope != 0 )
                         stop( "Constant(): sigmaSlope must be 0.", call. = FALSE )
                       new_object( .parent = ModelError,
                                  output = output,
                                  equation = equation,
                                  derivatives = derivatives,
                                  sigmaInter = sigmaInter,
                                  sigmaSlope = 0.0,
                                  sigmaInterFixed = sigmaInterFixed,
                                  sigmaSlopeFixed = sigmaSlopeFixed,
                                  cError = cError )
                     } )
