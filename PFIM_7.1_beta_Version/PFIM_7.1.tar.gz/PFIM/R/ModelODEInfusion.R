#' @title ModelODEInfusion
#' @description ODE model with infusion inputs.
#' @inheritParams ModelInfusion
#' @include ModelInfusion.R
#' @return An S7 object of class \code{ModelODEInfusion}.
#' @export

ModelODEInfusion = new_class( "ModelODEInfusion", package = "PFIM", parent = ModelInfusion )

#' Evaluate initial conditions for ODE infusion models.
#'
#' Delegates to \code{.evalInitialConditionsImpl}: substitutes typical values
#' into arm initial-condition expressions (numeric values pass through).
#' @return Numeric vector of evaluated initial conditions.
#' @name evaluateInitialConditions
#' @keywords internal
method( evaluateInitialConditions, ModelODEInfusion ) = function( model, arm ) {
  .evalInitialConditionsImpl( model, arm )
}
