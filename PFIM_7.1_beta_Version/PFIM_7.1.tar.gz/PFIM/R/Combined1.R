#' @title Combined1
#' @description
#' Combined residual error: additive plus proportional,
#' \code{sigmaInter + sigmaSlope * f}.
#' @inheritParams ModelError
#' @include ModelError.R
#' @return An S7 object of class \code{Combined1}.
#' @export

Combined1 = new_class( "Combined1", package = "PFIM", parent = ModelError,
                      constructor = function( output = character( 0 ),
                                             equation = expression( sigmaInter + sigmaSlope * output ),
                                             derivatives = list(),
                                             sigmaInter = 0.0,
                                             sigmaSlope = 0.0,
                                             sigmaInterFixed = FALSE,
                                             sigmaSlopeFixed = FALSE,
                                             cError = 1.0 ) {
                        # Both additive and proportional SDs may be non-zero.
                        .checkModelErrorSigmas( sigmaInter, sigmaSlope, cError )
                        new_object( .parent = ModelError,
                                   output = output,
                                   equation = equation,
                                   derivatives = derivatives,
                                   sigmaInter = sigmaInter,
                                   sigmaSlope = sigmaSlope,
                                   sigmaInterFixed = sigmaInterFixed,
                                   sigmaSlopeFixed = sigmaSlopeFixed,
                                   cError = cError )
                      } )
