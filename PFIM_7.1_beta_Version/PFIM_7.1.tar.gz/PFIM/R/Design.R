#' @title Design
#' @description
#' Experimental design: one or more arms, each with dosing and sampling schedules.
#' Filled by \code{evaluateDesign()} with per-arm FIM results.
#' @param name Character string: design name.
#' @param size Total number of subjects (sum of arm sizes).
#' @param arms List of \code{Arm} objects.
#' @param numberOfArms Number of arms (computed).
#' @param evaluationArms Evaluated arms after \code{evaluateDesign()}.
#' @param fim Aggregated \code{Fim} for the design.
#' @include Fim.R
#' @include Arm.R
#' @return An S7 object of class \code{Design}.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' design <- prop(ev, "designs")[[1L]]
#' prop(prop(design, "arms")[[1L]], "size")
#' }
#' @export

Design = new_class("Design", package = "PFIM",
                   properties = list(
                     name = new_property(class_character, default = character(0)),
                     size = new_property(class_double, default = 0.0),
                     arms = new_property(class_list, default = list()),
                     evaluationArms = new_property(class_list, default = list()),
                     numberOfArms = new_property(class_double, default = 0.0),
                     fim = new_property(Fim, default = NULL)
                   ),
                   validator = function( self ) {
                     size = prop( self, "size" )
                     if ( length( size ) == 1L && is.finite( size ) && size < 0 )
                       return( "Design: size must be non-negative." )
                     nArms = prop( self, "numberOfArms" )
                     if ( length( nArms ) == 1L && is.finite( nArms ) && nArms < 0 )
                       return( "Design: numberOfArms must be non-negative." )
                     msg = .validateS7List(
                       prop( self, "arms" ), Arm, "Design:arms", "Arm"
                     )
                     if ( !is.null( msg ) )
                       return( msg )
                     msg = .validateS7List(
                       prop( self, "evaluationArms" ), Arm, "Design:evaluationArms", "Arm"
                     )
                     if ( !is.null( msg ) )
                       return( msg )
                     NULL
                   })


#' Sampling times for one outcome on an arm.
#' @param samplingTimes List of \code{SamplingTimes} objects.
#' @param outcome Character outcome name.
#' @return Numeric vector of sampling times.
#' @noRd
#' @keywords internal
.samplingsForOutcome = function( samplingTimes, outcome ) {
  keep( samplingTimes, ~ prop( .x, "outcome" ) == outcome ) |>
    map( ~ prop( .x, "samplings" ) ) |>
    unlist()
}


#' Sum arm-level FIM matrices into a new design-level \code{Fim} object.
#'
#' @param fimPrototype Template from \code{defineFim()} (class only; not mutated).
#' @param evaluationArms List of evaluated \code{Arm} objects.
#' @return Aggregated \code{Fim} for the design.
#' @noRd
#' @keywords internal
.assembleDesignFim = function( fimPrototype, evaluationArms, model = NULL ) {

  designFim = .duplicateFim( fimPrototype )
  armFims   = map( evaluationArms, ~ prop( .x, "evaluationFim" ) )

  fisherBlocks = map( armFims, ~ prop( .x, "fisherMatrix" ) )
  prop( designFim, "fisherMatrix" ) = Reduce( `+`, fisherBlocks )

  if ( S7::S7_inherits( fimPrototype, BayesianFim ) &&
       !is.null( model ) && length( evaluationArms ) > 0L ) {
    prop( designFim, "shrinkage" ) = .bayesianShrinkageForDesign(
      prop( designFim, "fisherMatrix" ), model, evaluationArms
    )
  }

  designFim
}

#' Evaluate a design for a model and FIM type
#' @param design A \code{Design} object.
#' @param ... Method-specific arguments. For \code{Design}, \code{model} and \code{fim} objects.
#' @usage evaluateDesign(design, ...)
#' @return The updated \code{Design} object after evaluation.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' length(prop(ev, "evaluationDesign"))
#' }
#' @name evaluateDesign
#' @export
evaluateDesign = new_generic( "evaluateDesign", c( "design" ) )

#' Enumerate dose combinations under design constraints
#' @param design A \code{Design} object.
#' @param ... Optional method arguments.
#' @name generateDosesCombination
#' @return A list or matrix of generated dose combinations.
#' @export
generateDosesCombination = new_generic( "generateDosesCombination", c( "design" ) )

#' Enumerate sampling-time combinations under constraints
#' @param design A \code{Design} object.
#' @param ... Optional method arguments.
#' @name generateSamplingTimesCombination
#' @return A list or matrix of generated sampling-time combinations.
#' @export
generateSamplingTimesCombination = new_generic( "generateSamplingTimesCombination", c( "design" ) )

#' Hard cap on discrete dose/sampling Cartesian products.
#'
#' Enumerating \code{combn()} / \code{expand.grid()} without a bound can exhaust
#' memory on large constraint grids. This limit applies to the *enumeration*
#' step only; it is independent of \code{constraints.maxTasks}, which only
#' subsamples FIM evaluations *after* the grid exists.
#' @noRd
#' @keywords internal
.pfimMaxCombinationCount = 1000000L

#' Stop when a discrete enumeration would exceed \code{.pfimMaxCombinationCount}.
#'
#' @param count Number of combinations about to be materialised (must be
#'   \code{nrow} for dose grids, or product of per-outcome list lengths for
#'   sampling grids — never \code{prod(dim(...))}).
#' @param context Short label included in the error (e.g. \code{"Dose enumeration"}).
#' @noRd
#' @keywords internal
.pfimStopIfCombinationOverflow = function( count, context ) {
  if ( !is.finite( count ) || count <= .pfimMaxCombinationCount )
    return( invisible( NULL ) )
  stop(
    context, " would enumerate ", format( count, scientific = FALSE ), " combinations ",
    "(limit ", format( .pfimMaxCombinationCount, scientific = FALSE ), "). ",
    "Reduce the number of candidate doses or sampling times.",
    call. = FALSE
  )
}

#' Validate generated sampling constraints for feasibility
#' @param design A \code{Design} object.
#' @param ... Optional method arguments.
#' @name checkValiditySamplingConstraint
#' @return Logical value indicating whether sampling constraints are valid.
#' @export
checkValiditySamplingConstraint = new_generic( "checkValiditySamplingConstraint", c( "design" ) )

#' Apply sampling constraints for optimization algorithms
#' @param design A \code{Design} object.
#' @param ... Optional method arguments.
#' @name setSamplingConstraintForOptimization
#' @return The modified \code{Design} object.
#' @export
setSamplingConstraintForOptimization = new_generic( "setSamplingConstraintForOptimization", c( "design" ) )

#' Evaluate every arm and assemble the design-level FIM.
#'
#' Clones the model per arm, runs \code{evaluateArm}, then
#' \code{.assembleDesignFim} (sum / stack according to FIM type).
#' For the \code{Design} method, \code{...} is \code{model} (cloned per arm)
#' and \code{fim} (FIM template).
#' @return The same \code{Design} with \code{evaluationArms} and \code{fim} set.
#' @name evaluateDesign
#' @usage NULL
method( evaluateDesign, Design ) = function( design, model, fim ) {

  arms = prop( design, "arms" )
  prop( design, "evaluationArms" ) = map(
    arms,
    function( arm ) evaluateArm( arm, .pfimCloneS7( model ), fim )
  )
  prop( design, "fim" ) = .assembleDesignFim( fim, prop( design, "evaluationArms" ), model )

  design
}

#' Enumerate dose levels under administration constraints.
#'
#' Builds the Cartesian product of dose lists across arms/outcomes, guarded by
#' \code{.pfimMaxCombinationCount}. Returns a nested list keyed by arm and
#' outcome, plus \code{numberOfDoses}.
#' @name generateDosesCombination
#' @export

method( generateDosesCombination, Design ) = function( design ) {

  arms = prop( design, "arms" )

  # Cartesian product of dose levels across administrations (one row = one combo).
  dosesForFIMsTmp = map( arms, function( arm ) {
    map( prop( arm, "administrationsConstraints" ), ~ prop( .x, "doses" ) )
  } ) |> flatten() |> expand.grid()

  # Guard uses nrow (= number of dose combinations), not prod(dim) = nrow*ncol.
  .pfimStopIfCombinationOverflow(
    nrow( dosesForFIMsTmp ),
    "Dose enumeration"
  )

  admin_specs = map( arms, function( arm ) {
    armName = prop( arm, "name" )
    map( prop( arm, "administrations" ), function( administration ) {
      list( armName = armName, outcome = prop( administration, "outcome" ) )
    } )
  } ) |> flatten()

  dosesForFIMs = reduce(
    imap( admin_specs, ~ list( spec = .x, col = .y ) ),
    function( acc, item ) {
      acc[[ item$spec$armName ]][[ item$spec$outcome ]] =
        unlist( dosesForFIMsTmp[, item$col, drop = TRUE ] )
      acc
    },
    .init = list()
  )
  c( dosesForFIMs, numberOfDoses = dim( dosesForFIMsTmp )[1L] )
}

#' Enumerate sampling-time combinations under sampling constraints.
#'
#' For each arm and outcome: \code{combn} of free times plus fixed times, then
#' \code{expand.grid} across outcomes (guarded before materialising). Returns a
#' named list of arms → list of sampling schedules for FIM evaluation.
#' @name generateSamplingTimesCombination
#' @export

method( generateSamplingTimesCombination, Design ) = function( design ) {

  arms = prop( design, "arms" )

  armResults = map( arms, function( arm ) {

    armName = prop( arm, "name" )
    samplingTimesConstraints = prop( arm, "samplingTimesConstraints" )
    samplingTimes = prop( arm, "samplingTimes")
    outcomeNames = map_chr( samplingTimesConstraints, ~ prop( .x, "outcome" ) )

    # Per outcome: choose k free times from the candidate grid (+ fixed times).
    samplingTimesCombinations = map( samplingTimesConstraints, function( samplingTimesConstraint ) {
      initialSamplings = prop( samplingTimesConstraint, "initialSamplings" )
      fixedTimes = prop( samplingTimesConstraint, "fixedTimes" )
      numberOfsamplingsOptimisable = prop( samplingTimesConstraint, "numberOfsamplingsOptimisable" )
      availableSamplings = setdiff( initialSamplings, fixedTimes )
      outcome = prop( samplingTimesConstraint, "outcome" )
      k = as.integer( numberOfsamplingsOptimisable - length( fixedTimes ) )
      if ( k < 0L )
        stop(
          "numberOfsamplingsOptimisable cannot be less than the number of fixed times for outcome ",
          outcome, ".", call. = FALSE
        )
      if ( k > length( availableSamplings ) )
        stop(
          "Not enough available sampling times for outcome ", outcome,
          " (need ", k, ", have ", length( availableSamplings ), ").", call. = FALSE
        )
      combinations = if ( k == 0L ) list( fixedTimes ) else combn( availableSamplings, k, simplify = FALSE )
      map( combinations, ~ c( fixedTimes, .x ) )
    })

    # Guard before expand.grid (Cartesian product across outcomes).
    n_combinations = prod( vapply( samplingTimesCombinations, length, integer( 1L ) ) )
    .pfimStopIfCombinationOverflow(
      n_combinations,
      paste0( "Sampling enumeration for arm '", armName, "'" )
    )

    samplingTimesCombinations = expand.grid( samplingTimesCombinations )
    colnames( samplingTimesCombinations ) = outcomeNames
    samplingTimesCombinations = pmap( samplingTimesCombinations, ~ list( ... ) )

    # Materialise SamplingTimes clones with the chosen times (sorted).
    samplingsForFIM = map( samplingTimesCombinations, function( samplingTimeCombination ) {
      map2( samplingTimes, outcomeNames, function( samplingTime, outcomeName ) {
        st = .pfimCloneS7( samplingTime )
        prop( st, "samplings" ) = sort( samplingTimeCombination[[outcomeName]] )
        st
      })
    })
  })
  set_names( armResults, map_chr( arms, ~ prop( .x, "name" ) ) )
}

#' Check feasibility of sampling constraints
#' @name checkValiditySamplingConstraint
#' @export

method( checkValiditySamplingConstraint, Design ) = function( design ) {

  arms = prop( design, "arms" )

  walk ( arms, function( arm ) {
    armName = prop( arm, "name" )

    # get the outcomes
    samplingTimesConstraints = prop( arm, "samplingTimesConstraints" )
    outcomes = map( samplingTimesConstraints, ~ prop( .x, "outcome" ) ) |> unlist()

    # get samplings window constraints
    samplingsWindow = map( samplingTimesConstraints, ~ prop( .x, "samplingsWindows" ) ) |> stats::setNames( outcomes )

    # get numberOfTimesByWindows constraints
    numberOfTimesByWindows = map( samplingTimesConstraints, ~ prop( .x, "numberOfTimesByWindows" ) ) |> stats::setNames( outcomes )

    # get minimal time step for each windows
    minSampling = map( samplingTimesConstraints, ~ prop( .x, "minSampling" ) ) |> stats::setNames( outcomes )

    inputRandomSpaced = list()
    samplingTimesArms = list()

    walk ( outcomes, function( outcome ) {
      intervalsConstraints = list()

      # get samplingTimes and samplings
      samplingTimes = prop( arm, "samplingTimes")
      samplings = .samplingsForOutcome( samplingTimes, outcome )

      minSamplingAndNumberOfTimesByWindows = as.data.frame( list( minSampling[[outcome]], numberOfTimesByWindows[[outcome]] ) )
      tmp = t( as.data.frame(samplingsWindow[[outcome]] ) )
      inputRandomSpaced[[outcome]] = as.data.frame( do.call( "cbind", list( tmp, minSamplingAndNumberOfTimesByWindows ) ) )

      colnames( inputRandomSpaced[[outcome]] ) = c("min","max","delta","n")
      rownames( inputRandomSpaced[[outcome]] ) = NULL

      if ( sum( numberOfTimesByWindows[[outcome]] ) != length( samplings ) ) {
        stop(
          "The sampling times constraint is not possible for arm ",
          armName, " and outcome ", outcome, ".", call. = FALSE
        )
      }

      walk( seq_len( length( inputRandomSpaced[[outcome]]$n)), function( iter ) {
        min = inputRandomSpaced[[outcome]]$min[iter]
        max = inputRandomSpaced[[outcome]]$max[iter]
        delta = inputRandomSpaced[[outcome]]$delta[iter]
        n = inputRandomSpaced[[outcome]]$n[iter]

        distance = max-min-(n-1)*delta

        if ( distance < 0 ) {
          stop(
            "The sampling times constraint is not possible for arm ",
            armName, " and outcome ", outcome, ".", call. = FALSE
          )
        }
      })
    })
  })
}

#' Prepare sampling constraints for optimization
#' @name setSamplingConstraintForOptimization
#' @export

method( setSamplingConstraintForOptimization, Design ) = function( design ) {

  arms = prop( design, "arms" )

  arms = map ( arms, function( arm )
  {
    # get the outcomes in the sampling times
    samplingTimes = prop( arm, "samplingTimes" )
    outcomes = map_chr( samplingTimes, ~ prop( .x, "outcome" ) )

    # set the sampling time constraints for missing outcomes ie from its sampling times
    samplingTimesConstraints = prop( arm, "samplingTimesConstraints" )
    outcomesSamplingTimesConstraints = map_chr( samplingTimesConstraints, ~ prop( .x, "outcome" ) )
    outcomesSamplingNotInTimesConstraints = outcomes[!outcomes %in% outcomesSamplingTimesConstraints]

    if ( length( outcomesSamplingNotInTimesConstraints ) !=0 )
    {
      samplingTimesConstraints = reduce(
        outcomesSamplingNotInTimesConstraints,
        function( stc, outcomeSamplingNotInTimesConstraints ) {
          samplings = .samplingsForOutcome( samplingTimes, outcomeSamplingNotInTimesConstraints )
          newSamplingTimeConstraints = SamplingTimeConstraints( outcome = outcomeSamplingNotInTimesConstraints,
                                                                initialSamplings = samplings,
                                                                samplingsWindows = list( c( min( samplings ), max( samplings ) ) ),
                                                                numberOfTimesByWindows = length( samplings ),
                                                                minSampling = 0 )
          append( stc, newSamplingTimeConstraints )
        },
        .init = samplingTimesConstraints
      )
    }
    prop( arm, "samplingTimesConstraints" ) = samplingTimesConstraints
    arm
  })

  prop( design, "arms" ) = arms
  design
}






