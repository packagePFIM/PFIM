#' @title BayesianFim
#' @description
#' Bayesian Fisher information matrix with shrinkage on random effects.
#'
#' Supports covariates and IOV via expectation over combinations and occasions.
#' PK parameters use the Bayesian shrinkage formula; covariate \code{beta} effects
#' enter as extra fixed-effect columns without IIV shrinkage.
#'
#' @inheritParams Fim
#' @return A \code{BayesianFim} object (filled by \code{run()}).
#' @examples
#' \dontrun{
#' vignette("Example01")
#' }
#' @include Fim.R
#' @include PFIMProject.R
#' @export

BayesianFim = new_class( "BayesianFim",
                         package    = "PFIM",
                         parent     = Fim
)
S4_register( BayesianFim )

# Estimable mu names with Greek prefix (setEvaluationFim, plots, …).
#' Build estimable parameter labels for Bayesian outputs.
#' @param parameters List of \code{ModelParameter} objects.
#' @param greekPrefix Character prefix added to each parameter name.
#' @return Character vector of estimable parameter labels.
#' @noRd
#' @keywords internal
.bayesianEstimableParamNames = function( parameters, greekPrefix ) {
  parameters |>
    keep( .paramOmegaEstimable ) |>
    map_chr( ~ prop( .x, "name" ) ) |>
    map_chr( ~ paste0( greekPrefix, .x ) )
}

#' PK mu/omega vectors for Bayesian shrinkage blocks.
#' @noRd
#' @keywords internal
.bayesianPkMuOmegaBlock = function( idx, feCols, paramByName ) {
  mu_v = omega_v = numeric( length( idx ) )
  fixed = logical( length( idx ) )
  for ( i in seq_along( idx ) ) {
    j     = idx[[ i ]]
    col   = feCols[[ j ]]
    pname = sub( "^mu_", "", col )
    p     = paramByName[[ pname ]]
    d     = prop( p, "distribution" )
    mu_v[[ i ]]    = adjustGradient( d, 1, prop( d, "mu" ) )
    omega_v[[ i ]] = prop( d, "omega" )
    fixed[[ i ]]   = .paramOmegaFixed( p )
  }
  list( mu = mu_v, omega = omega_v, fixed = fixed )
}

#' Shrinkage (%) from PK FIM block and prior variance (single Cholesky pair).
#' @noRd
.bayesianShrinkageFromPrior = function( MF_pk, priorVariance ) {
  as.vector( diag( .safeCholInv( MF_pk ) %*% .safeCholInv( priorVariance ) ) * 100 )
}

#' @noRd
.bayesianShrinkageValues = function( shrinkage ) {
  if ( !is.matrix( shrinkage ) )
    return( as.numeric( shrinkage ) )
  if ( nrow( shrinkage ) == 1L )
    return( as.numeric( shrinkage[ 1L, , drop = TRUE ] ) )
  if ( ncol( shrinkage ) == 1L )
    return( as.numeric( shrinkage[ , 1L, drop = TRUE ] ) )
  as.numeric( shrinkage )
}

#' Console mu-labels aligned with stored Bayesian shrinkage.
#' @noRd
#' @keywords internal
.bayesianShrinkageMuLabels = function( shrinkage, evaluation ) {
  muPrefix = .greekConsole[ "mu" ]
  cols     = character( 0L )
  if ( is.matrix( shrinkage ) ) {
    if ( nrow( shrinkage ) == 1L && !is.null( colnames( shrinkage ) ) )
      cols = colnames( shrinkage )
    else if ( ncol( shrinkage ) == 1L && !is.null( rownames( shrinkage ) ) )
      cols = rownames( shrinkage )
  }
  if ( !length( cols ) || identical( cols, "Shrinkage" ) )
    cols = .fimFixedEffectLabels( evaluation )$columnNamesMu
  .stripGreekPrefix( cols, muPrefix )
}

#' @noRd
.bayesianShrinkageMatrix = function( shrinkage, shrinkageCols ) {
  matrix(
    .bayesianShrinkageValues( shrinkage ),
    nrow = 1L,
    dimnames = list( "Shrinkage", shrinkageCols )
  )
}

#' PK prior variance and shrinkage from a Bayesian FIM block.
#' @noRd
#' @keywords internal
.bayesianShrinkage = function( fisherMatrix, model, arm ) {

  parameters  = prop( model, "modelParameters" )
  feCols      = .fimFixedEffectColumnNames( model, arm )
  betaIdx     = which( startsWith( feCols, "beta_" ) )
  pkIdx       = if ( any( startsWith( feCols, "mu_" ) ) ) {
    which( startsWith( feCols, "mu_" ) )
  } else {
    seq_along( feCols )[ !seq_along( feCols ) %in% betaIdx ]
  }
  paramByName = set_names( parameters, map_chr( parameters, ~ prop( .x, "name" ) ) )
  pk          = .bayesianPkMuOmegaBlock( pkIdx, feCols, paramByName )
  keepPk      = !pk$fixed
  mu_pk       = pk$mu[ keepPk ]
  omega_pk    = pk$omega[ keepPk ]

  mu_d = if ( length( mu_pk ) == 1L ) mu_pk[[ 1L ]] else diag( mu_pk )
  om_d = if ( length( omega_pk ) == 1L ) omega_pk[[ 1L ]]^2 else diag( omega_pk^2 )
  priorVariance = mu_d %*% om_d %*% mu_d
  n_keep        = length( mu_pk )

  if ( length( betaIdx ) > 0L ) {
    MF_pk = fisherMatrix[ seq_len( n_keep ), seq_len( n_keep ), drop = FALSE ]
  } else {
    MF_pk = fisherMatrix
    if ( nrow( MF_pk ) != n_keep && any( pk$fixed ) ) {
      indexFixed = which( pk$fixed )
      MF_pk = MF_pk[ -indexFixed, -indexFixed, drop = FALSE ]
    }
  }

  .bayesianShrinkageFromPrior( MF_pk, priorVariance )
}

#' Bayesian shrinkage on a design-level aggregated FIM across arms.
#' @param fisherMatrix Aggregated design Fisher matrix.
#' @param model \code{Model} used for shrinkage blocks.
#' @param evaluationArms List of evaluated \code{Arm} objects.
#' @return Numeric shrinkage vector aligned with PK fixed effects.
#' @noRd
#' @keywords internal
.bayesianShrinkageForDesign = function( fisherMatrix, model, evaluationArms ) {
  if ( !length( evaluationArms ) )
    return( numeric( 0 ) )
  fe_cols = map( evaluationArms, ~ .fimFixedEffectColumnNames( model, .x ) )
  ref     = fe_cols[[ 1L ]]
  if ( !all( map_lgl( fe_cols, ~ identical( .x, ref ) ) ) )
    warning(
      "Bayesian shrinkage: arms differ in FIM column layout; using first arm.",
      call. = FALSE
    )
  .bayesianShrinkage( fisherMatrix, model, evaluationArms[[ 1L ]] )
}

#' Variance block of the Bayesian FIM (fixed-effect contribution only).
#'
#' Bayesian FIMs have no separate omega/sigma estimation block here: the
#' returned \code{MFbeta} is later shrunk with the prior variance.
#' @name evaluateVarianceFIM
#' @keywords internal

method( evaluateVarianceFIM, list( BayesianFim, Model, Arm ) ) = function( fim, model, arm ) {

  feCols   = .fimFixedEffectColumnNames( model, arm )
  gradient = .gradientMatrix( arm, feCols, model )
  V        = as.matrix( getArmEvaluationVarianceFlat( arm )$errorVariance )
  MFbeta   = crossprod( gradient, .safeCholInv( V ) ) %*% gradient

  list( MFbeta = MFbeta, V = V )
}

#' Compute the Bayesian FIM for one arm.
#'
#' PK mu columns get the Bayesian update
#' \eqn{\mu^\top M_{pk} \mu + \Omega^{-1}}; covariate \code{beta} columns stay
#' unshrunk and are block-diagonaled after the PK block. Shrinkage (\%) is stored
#' from the PK prior pair.
#' @name evaluateFim
#' @keywords internal

method( evaluateFim, list( BayesianFim, Model, Arm ) ) = function( fim, model, arm ) {

  parameters   = prop( model, "modelParameters" )
  varBlock    = evaluateVarianceFIM( fim, model, arm )
  MFbeta_full = varBlock$MFbeta
  feCols      = .fimFixedEffectColumnNames( model, arm )
  betaIdx = which( startsWith( feCols, "beta_" ) )
  # Prefer explicit mu_ columns; otherwise treat non-beta fixed effects as PK.
  pkIdx   = if ( any( startsWith( feCols, "mu_" ) ) ) {
    which( startsWith( feCols, "mu_" ) )
  } else {
    seq_along( feCols )[ !seq_along( feCols ) %in% betaIdx ]
  }

  paramByName = set_names( parameters, map_chr( parameters, ~ prop( .x, "name" ) ) )

  if ( length( betaIdx ) > 0L ) {
    pk  = .bayesianPkMuOmegaBlock( pkIdx, feCols, paramByName )
    keepPk = !pk$fixed

    pkIdxKeep = pkIdx[ keepPk ]
    mu_pk     = pk$mu[ keepPk ]
    omega_pk  = pk$omega[ keepPk ]

    MF_pk = MFbeta_full[ pkIdxKeep, pkIdxKeep, drop = FALSE ]
    mu_d  = if ( length( mu_pk ) == 1L ) mu_pk[[ 1L ]] else diag( mu_pk )
    om_d  = if ( length( omega_pk ) == 1L ) omega_pk[[ 1L ]]^2 else diag( omega_pk^2 )

    priorVariance = mu_d %*% om_d %*% mu_d
    # Bayesian information = transformed data FIM + prior precision.
    MF_bayes_pk   = t( mu_d ) %*% MF_pk %*% mu_d + .safeSolve( priorVariance )

    MF_beta = MFbeta_full[ betaIdx, betaIdx, drop = FALSE ]
    MFbeta  = as.matrix( bdiag( MF_bayes_pk, MF_beta ) )
    shrinkage_block = MF_bayes_pk
  } else {
    pk = .bayesianPkMuOmegaBlock( pkIdx, feCols, paramByName )
    indexFixed = which( pk$fixed )
    mu_vec    = pk$mu
    omega_vec = pk$omega
    MF_pk     = MFbeta_full

    if ( length( indexFixed ) > 0L ) {
      mu_vec    = mu_vec[ -indexFixed ]
      omega_vec = omega_vec[ -indexFixed ]
      MF_pk     = MF_pk[ -indexFixed, -indexFixed, drop = FALSE ]
      MFbeta_full = MFbeta_full[ -indexFixed, -indexFixed, drop = FALSE ]
    }

    mu    = if ( length( mu_vec ) == 1L ) mu_vec[[ 1L ]] else diag( mu_vec )
    omega = if ( length( omega_vec ) == 1L ) omega_vec[[ 1L ]]^2 else diag( omega_vec^2 )

    priorVariance = mu %*% omega %*% mu
    MFbeta        = t( mu ) %*% MFbeta_full %*% mu + .safeSolve( priorVariance )
    shrinkage_block = MFbeta
  }
  prop( fim, "fisherMatrix" ) = MFbeta
  prop( fim, "shrinkage" )    = .bayesianShrinkageFromPrior( shrinkage_block, priorVariance )
  fim
}

#' Attach evaluated Bayesian FIM results (labels, SE/RSE, shrinkage matrix).
#' @name setEvaluationFim
#' @export

method( setEvaluationFim, BayesianFim ) = function( fim, evaluation ) {

  parameters = prop( evaluation, "modelParameters" )
  greek      = .greekConsole
  fe         = .fimFixedEffectLabels( evaluation, greek )

  useCovBeta = fe$has_cov && length( fe$feInternal ) > 0L &&
    any( startsWith( fe$feInternal, "beta_" ) )

  if ( useCovBeta ) {
    allNames      = c( fe$columnNamesMu, fe$columnNamesBeta )
    pVals         = c( fe$muValues, fe$betaValues )
    shrinkageCols = fe$columnNamesMu
  } else {
    allNames      = .bayesianEstimableParamNames( parameters, greek[ "mu" ] )
    pVals         = parameters |>
      keep( .paramOmegaEstimable ) |>
      map_dbl( ~ prop( prop( .x, "distribution" ), "mu" ) )
    shrinkageCols = allNames[ str_starts( allNames, greek[ "mu" ] ) ]
  }

  fisherMatrix = prop( fim, "fisherMatrix" )
  colnames( fisherMatrix ) = allNames
  rownames( fisherMatrix ) = allNames
  fixedEffects = fisherMatrix

  shrinkage = .bayesianShrinkageValues( prop( fim, "shrinkage" ) )
  se        = .fimBuildSeAndRse( fisherMatrix, allNames, pVals, abs_denominator = TRUE )

  prop( fim, "fisherMatrix"           ) = fisherMatrix
  prop( fim, "fixedEffects"           ) = fixedEffects
  prop( fim, "shrinkage"              ) = .bayesianShrinkageMatrix( shrinkage, shrinkageCols )
  prop( fim, "condNumberFixedEffects" ) = .conditionNumber( fixedEffects )
  prop( fim, "SEAndRSE"               ) = se
  prop( fim, "singularFim"            ) = isTRUE( se$singular )

  fim
}

#' Print FIM summaries to the console
#' @name showFIM
#' @export

method( showFIM, BayesianFim ) = function( fim ) {

  SEAndRSE               = prop( fim, "SEAndRSE" )
  fisherMatrix           = prop( fim, "fisherMatrix" )
  fixedEffects           = prop( fim, "fixedEffects" )
  shrinkage              = prop( fim, "shrinkage" )
  condNumberFixedEffects = prop( fim, "condNumberFixedEffects" )
  dcrit                  = Dcriterion( fim )

  cat( "\n*************************************** \n Bayesian Fisher Matrix \n*************************************** \n\n" )
  print( fisherMatrix )
  cat( "\n*************************************** \n Fixed effects \n*************************************** \n\n" )
  print( fixedEffects )
  cat( "\n*********************************************** \n Determinant, condition numbers and D-criterion \n*********************************************** \n\n" )
  cat( c( "log-Determinant:",  as.numeric( .fimLogDeterminant( fisherMatrix ) ) ), "\n" )
  cat( c( "D-criterion:",  as.numeric( dcrit              ) ), "\n" )
  cat( c( "Conditional number of the fixed effects:", as.numeric( condNumberFixedEffects ), "\n" ) )
  cat( "\n*************************************** \n Shrinkage \n*************************************** \n\n" )
  print( shrinkage )
  cat( "\n*************************************** \n Parameters estimation \n*************************************** \n\n" )
  .printFimSeAndRse( fim )

  rn = rownames( prop( fim, "fisherMatrix" ) )
  if ( any( grepl( "\u03b2_", rn, fixed = TRUE ) ) ) {
    cat( "\n*************************************** \n Legend: \n" )
    cat( " \u03bc  = fixed effects\n" )
    cat( " \u03b2  = covariate effects\n" )
    cat( "*************************************** \n\n" )
  }

  invisible( fim )
}

#' ggplot data for Bayesian SE/RSE barplots (mu and beta facets).
#' @param evaluation A \code{PFIMProject} object.
#' @param metric Character scalar, \code{"SE"} or \code{"RSE"}.
#' @return List with \code{data} (plot-ready \code{data.frame}) and \code{facet_levels}.
#' @noRd
#' @keywords internal
.bayesianSeRsePlotData = function( evaluation, metric ) {
  fim    = setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  seDF   = prop( fim, "SEAndRSE" )$SEAndRSE
  greekC = .greekConsole
  fe     = .fimFixedEffectLabels( evaluation, greekC )
  facet  = function( key ) .pfimSeRseFacetLabel( metric, key )

  # SE/RSE barplots: mu + beta (sensitivity plots omit beta).
  paramLabelsMu   = .stripGreekPrefix( fe$columnNamesMu,   greekC[ "mu" ] )
  paramLabelsBeta = .stripGreekPrefix( fe$columnNamesBeta, greekC[ "beta" ] )
  if ( !length( paramLabelsMu ) && !length( paramLabelsBeta ) )
    paramLabelsMu = .bayesianEstimableParamNames( prop( evaluation, "modelParameters" ), "" )
  n_mu   = length( paramLabelsMu )
  n_beta = length( paramLabelsBeta )
  paramLabels = c( paramLabelsMu, paramLabelsBeta )
  cats = c(
    rep( facet( "mu"   ), n_mu ),
    rep( facet( "beta" ), n_beta )
  )
  y_vals = if ( metric == "SE" )
    seDF$SE[ seq_len( n_mu + n_beta ) ]
  else
    seDF$RSE[ seq_len( n_mu + n_beta ) ]

  df = data.frame(
    Parameter = paramLabels,
    y         = y_vals,
    cat       = cats
  )
  names( df )[ 2L ] = metric
  list( data = df, facet_levels = unique( cats ) )
}

.bayesianSeRseBarPlot = function( evaluation, metric ) {
  px = .bayesianSeRsePlotData( evaluation, metric )
  .fimSeRseBarPlot( px$data, metric, px$facet_levels )
}

method( plotSEFIM, list( BayesianFim, PFIMProject ) ) = function( fim, evaluation )
  .bayesianSeRseBarPlot( evaluation, "SE" )

method( plotRSEFIM, list( BayesianFim, PFIMProject ) ) = function( fim, evaluation )
  .bayesianSeRseBarPlot( evaluation, "RSE" )

#' Default method for \code{BayesianFim}.
#' @param fim First argument of generic.
#' @param evaluation \code{PFIMProject} providing model parameter labels.
#' @return \code{ggplot} object showing Bayesian shrinkage by parameter.
#' @name plotShrinkage
#' @export
method( plotShrinkage, list( BayesianFim, PFIMProject ) ) = function( fim, evaluation ) {
  fim         = setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  shrinkage   = prop( fim, "shrinkage" )
  paramLabels = .bayesianShrinkageMuLabels( shrinkage, evaluation )
  shrinkVals  = .bayesianShrinkageValues( shrinkage )

  data = data.frame( Parameter = paramLabels, Shrinkage = shrinkVals )
  ggplot( data, aes( x = Parameter, y = Shrinkage ) ) +
    geom_bar( stat = "identity", show.legend = FALSE ) +
    labs( x = "Parameter", y = "Shrinkage (%)" ) +
    .pfimBaseTheme()
}

#' FIM tables for HTML reports
#' @name tablesForReport
#' @export

method( tablesForReport, list( BayesianFim, PFIMProject ) ) = function( fim, evaluation ) {

  fim = setEvaluationFim( fim, evaluation )

  SEAndRSE               = prop( fim, "SEAndRSE" )$SEAndRSE
  fisherMatrix           = prop( fim, "fisherMatrix" )
  fixedEffects           = as.matrix( prop( fim, "fixedEffects" ) )
  shrinkage              = prop( fim, "shrinkage" )
  condNumberFixedEffects = prop( fim, "condNumberFixedEffects" )
  fe_info                = .fimFixedEffectLabels( evaluation )

  columnNamesFe = .fimFixedEffectLatexLabels( evaluation, fixedEffects = fixedEffects )
  colnames( fixedEffects ) = columnNamesFe
  rownames( fixedEffects ) = columnNamesFe

  shrink_vals = .bayesianShrinkageValues( shrinkage )
  if ( length( shrink_vals ) != length( fe_info$columnNamesMu ) )
    shrink_vals = rep( NA_real_, length( fe_info$columnNamesMu ) )
  shrink_col = c(
    shrink_vals,
    rep( NA_real_, length( fe_info$columnNamesBeta ) )
  )
  if ( length( shrink_col ) != length( columnNamesFe ) )
    shrink_col = rep( NA_real_, length( columnNamesFe ) )

  list(
    fixedEffectsTable = .kblReportStyled( fixedEffects ),
    FIMCriteriaTable  = .fimCriteriaKable(
      .fimLogDeterminant( fisherMatrix ), Dcriterion( fim ), condNumberFixedEffects
    ),
    SEAndRSETable     = .fimSeRseKable( columnNamesFe, SEAndRSE, shrink_col )
  )
}

# Report rendering methods

#' Render the evaluation HTML report
#' @name generateReportEvaluation
#' @export
method( generateReportEvaluation, BayesianFim ) =
  .renderEvalReport( "EvaluationBayesianFIM.Rmd" )
