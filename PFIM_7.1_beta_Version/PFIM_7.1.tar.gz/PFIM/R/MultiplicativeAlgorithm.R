#' @title MultiplicativeAlgorithm
#' @description
#' Multiplicative weight algorithm for optimal sampling-time allocation (Rcpp kernel).
#' Pass \code{lambda}, \code{delta}, \code{numberOfIterations}, and
#' \code{weightThreshold} via \code{optimizerParameters} on \code{\link{Optimization}}.
#' @param multiplicativeAlgorithmOutputs Raw algorithm outputs (weights, history).
#'   Filled by \code{optimizeDesign()}.
#' @return A \code{MultiplicativeAlgorithm} specification object.
#' @examples
#' \dontrun{
#' vignette("Example01")
#' }
#' @include Optimization.R
#' @export

MultiplicativeAlgorithm = new_class("MultiplicativeAlgorithm",
                                    package = "PFIM",

                                    properties = list(
                                      multiplicativeAlgorithmOutputs = new_property(class_list, default = list())
                                    ))
S4_register( MultiplicativeAlgorithm )

plotWeightsMultiplicativeAlgorithm = new_generic( "plotWeightsMultiplicativeAlgorithm", c( "optimization", "optimizationAlgorithm" ) )

#' MultiplicativeAlgorithm_Rcpp
#'
#' Calls the compiled Rcpp implementation of the multiplicative weight-update
#' algorithm. Registered via \code{Rcpp::compileAttributes()}
#' in \code{R/RcppExports.R}.
#'
#' @param fisherMatrices  List of FIM matrices.
#' @param n_fim           Integer number of FIMs.
#' @param weights         Numeric vector of initial weights.
#' @param p               Integer FIM dimension.
#' @param lambda          Numeric exponent parameter lambda.
#' @param delta           Numeric convergence tolerance delta.
#' @param iteration_init  Integer maximum iterations.
#' @param show_process    Logical; print iteration progress to the console.
#' @return Named list: \code{weights} (final weights), \code{iterationEnd},
#'   \code{converged} (logical).
#' @name MultiplicativeAlgorithm_Rcpp
#' @keywords internal
NULL

#' Multiplicative discrete D-optimal design (Rcpp kernel).
#'
#' Pipeline: build candidate FIMs on the constraint grid → run multiplicative
#' weight updates → drop weights \eqn{\le} \code{weightThreshold} → map surviving
#' protocols to arms → re-evaluate initial vs optimal designs for reporting.
#'
#' @param optimizationObject An \code{\link{Optimization}} project.
#' @param optimizationAlgorithm A \code{MultiplicativeAlgorithm} instance.
#' @return The same \code{Optimization} with \code{optimisationDesign} and
#'   \code{optimisationAlgorithmOutputs} filled.
#' @name optimizeDesign
#' @export

method( optimizeDesign, list( Optimization, MultiplicativeAlgorithm ) ) = function( optimizationObject, optimizationAlgorithm ) {

  p                  = projectProp( optimizationObject, "optimizerParameters" )
  lambda             = p$lambda
  delta              = p$delta
  numberOfIterations = p$numberOfIterations
  weightThreshold    = p$weightThreshold
  showProcess        = isTRUE( p$showProcess )

  # Candidate FIMs / arms for every dose × sampling cell under constraints.
  fimsFromConstraints = generateFimsFromConstraints( optimizationObject )
  design              = pluck( projectProp( optimizationObject, "designs" ), 1 )
  initialDesign       = .pfimCloneS7( design )
  optimalDesign       = .pfimCloneS7( design )
  designName          = prop( design, "name" )
  numberOfArms        = prop( design, "numberOfArms" )
  armFims             = fimsFromConstraints$listArms[[ designName ]]
  fisherMatrices      = fimsFromConstraints$listFimsAlgoMult[[ designName ]]

  # Uniform start on the simplex; C++ refines weights toward D-optimality.
  numberOfFisherMatrices = length( fisherMatrices )
  weights                = rep( 1 / numberOfFisherMatrices, numberOfFisherMatrices )
  fimDim = dim( pluck( fisherMatrices, 1 ) )[ 1L ]

  multiplicativeAlgorithmOutput = MultiplicativeAlgorithm_Rcpp(
    fisherMatrices, numberOfFisherMatrices, weights, fimDim,
    lambda, delta, numberOfIterations, showProcess
  )

  weights        = multiplicativeAlgorithmOutput$weights
  # Drop near-zero weights before building optimal arms (affects realised D).
  weightsIndex   = which( weights > weightThreshold )
  optimalWeights = weights[ weightsIndex ]

  # Note: storing the full fisherMatrices list makes vignette RDS large (~MB).
  # Needed today for setOptimalArms / reports; candidates for future thinning.
  prop( optimizationAlgorithm, "multiplicativeAlgorithmOutputs" ) = list(
    armFims                       = armFims,
    fisherMatrices                = fisherMatrices,
    multiplicativeAlgorithmOutput = multiplicativeAlgorithmOutput,
    numberOfArms                  = numberOfArms,
    weightThreshold               = weightThreshold,
    weightsIndex                  = weightsIndex,
    optimalWeights                = optimalWeights
  )

  # Dispatch by FIM type (population allocates subjects; individual keeps size 1).
  fim         = projectProp( optimizationObject, "fim" )
  optimalArms = setOptimalArms( fim, optimizationAlgorithm )
  if ( length( optimalArms ) == length( optimalWeights ) )
    optimalWeights = .alignOptimalWeightsToArms(
      optimalArms, weightsIndex, optimalWeights
    )
  prop( optimalDesign, "arms" ) = optimalArms

  .pfimOptimizationCacheFlush()

  evaluationResults = .pfimRunEvaluations( list(
    .evaluationFromOptimization( optimizationObject, optimalDesign, name = "...." ),
    .evaluationFromOptimization( optimizationObject, initialDesign )
  ) )

  prop( optimizationObject, "optimisationDesign" ) = list(
    evaluationInitialDesign = evaluationResults[[ 2L ]],
    evaluationOptimalDesign = evaluationResults[[ 1L ]]
  )
  prop( optimizationObject, "optimisationAlgorithmOutputs" ) = list(
    optimizationAlgorithm = optimizationAlgorithm,
    optimalArms           = optimalArms,
    optimalWeights        = optimalWeights
  )

  optimizationObject
}

#' Weight trajectories of the multiplicative algorithm
#' @name plotWeightsMultiplicativeAlgorithm
#' @return A \code{ggplot2} plot object.
#' @export

method( plotWeightsMultiplicativeAlgorithm, list( Optimization, MultiplicativeAlgorithm ) ) = function( optimization, optimizationAlgorithm )
{
  out = prop( optimization, "optimisationAlgorithmOutputs" )
  .algoBars(
    data.frame(
      optimalArmsName = map_chr( out$optimalArms, ~ prop( .x, "name" ) ),
      optimalWeights  = out$optimalWeights
    ),
    x = "optimalArmsName", y = "optimalWeights",
    xlab = "Arms", ylab = "Weights",
    ylim = c( 0, 1 ), breaks = seq( 0, 1, by = 0.1 )
  )
}

#' Constraint tables for optimization reports
#' @name constraintsTableForReport
#' @export

method( constraintsTableForReport, MultiplicativeAlgorithm ) = function( optimizationAlgorithm, arms ) {
  .pfimConstraintsTableDiscrete( optimizationAlgorithm, arms )
}
