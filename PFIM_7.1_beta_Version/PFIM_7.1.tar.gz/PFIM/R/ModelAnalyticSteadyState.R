#' ModelAnalyticSteadyState
#' @title ModelAnalyticSteadyState
#' @description Analytic model at steady state (tau in equations).
#' @inheritParams ModelAnalytic
#' @param wrapperModelAnalytic                   Wrapper for the analytic solver.
#' @param functionArgumentsModelAnalytic         A list with the function arguments.
#' @param functionArgumentsSymbolModelAnalytic   A list with the function argument symbols.
#' @param solverInputs                           A list with the solver inputs.
#' @inheritParams Model
#' @include ModelAnalytic.R
#' @return An S7 object of class \code{ModelAnalyticSteadyState}.
#' @export

ModelAnalyticSteadyState = new_class( "ModelAnalyticSteadyState",
                                      package = "PFIM",
                                      parent  = ModelAnalytic,
                                      properties = list(
                                        wrapperModelAnalytic                 = new_property(class_list, default = list()),
                                        functionArgumentsModelAnalytic       = new_property(class_list, default = list()),
                                        functionArgumentsSymbolModelAnalytic = new_property(class_list, default = list()),
                                        solverInputs                         = new_property(class_list, default = list())
                                      ))


#' Compile bolus / oral analytic wrappers at steady state (\code{tau} in formals).
#' @return Updated model with compiled analytic wrappers.
#' @name defineModelWrapper
#' @keywords internal
method( defineModelWrapper, ModelAnalyticSteadyState ) = function( model, evaluation ) {

  outcomesWithAdministration = .getOutcomesFromEvaluation( evaluation )

  parameters     = prop( evaluation, "modelParameters" )
  parameterNames = map_chr( parameters, "name" )
  doseNames      = paste0( "dose_", outcomesWithAdministration )
  timeNames      = paste0( "t_",    outcomesWithAdministration )

  # Administered vs passive equations (PD typically has no dose_*).
  equations            = prop( evaluation, "modelEquations" )
  equationsWithAdmin   = equations[  names( equations ) %in% outcomesWithAdministration ]
  equationsWithNoAdmin = equations[ !names( equations ) %in% outcomesWithAdministration ]

  outputAdmin   = names( equationsWithAdmin )
  outputNoAdmin = names( equationsWithNoAdmin )

  # Steady-state closed forms need the dosing interval tau.
  functionArgumentsWithAdmin   = unique( c( doseNames, parameterNames, timeNames, "tau" ) )
  functionArgumentsWithNoAdmin = unique( c( outcomesWithAdministration, parameterNames, timeNames, "tau" ) )

  prop( model, "wrapperModelAnalytic" ) = list(
    functionDefinitionWithAdmin   = .buildAnalyticWrapper( equationsWithAdmin,   functionArgumentsWithAdmin,   timeNames, outputAdmin   ),
    functionDefinitionWithNoAdmin = .buildAnalyticWrapper( equationsWithNoAdmin, functionArgumentsWithNoAdmin, timeNames, outputNoAdmin )
  )
  prop( model, "functionArgumentsModelAnalytic" ) = list(
    functionArgumentsWithAdmin   = functionArgumentsWithAdmin,
    functionArgumentsWithNoAdmin = functionArgumentsWithNoAdmin
  )
  prop( model, "outputNames" ) = unlist( names( equations ) )
  prop( model, "outcomesWithAdministration" ) = outcomesWithAdministration

  return( model )
}


#' Expand steady-state doses and relative sampling times for each administration.
#' @return Updated model with solver input structures.
#' @name defineModelAdministration
#' @keywords internal
method( defineModelAdministration, ModelAnalyticSteadyState ) = function( model, arm ) {

  administrations            = prop( arm,   "administrations" )
  outcomesWithAdministration = prop( model, "outcomesWithAdministration" )
  samplingTimes              = prop( arm,   "samplingTimes" )
  samplings                  = map( samplingTimes, ~ prop( .x, "samplings" ) ) |>
    unlist() |> sort() |> unique()

  solverInputs = map( administrations, function( adm ) {
    tau         = prop( adm, "tau" )
    dosing      = .alignAdministrationDosing( adm )
    timeDose    = dosing$timeDose
    dose        = dosing$dose
    maxSampling = max( samplings )

    # Regular dosing grid 0, tau, 2*tau, ... when tau is set.
    if ( tau != 0 ) {
      timeDose = seq( 0, maxSampling, tau )
      dose     = rep( dose, length( timeDose ) )
    }

    # Relative time since each dose (or absolute time if sampling precedes dose).
    timeDose = timeDose |>
      map( ~ ifelse( samplings - .x > 0, samplings - .x, samplings ) ) |>
      reduce( cbind )

    # How many distinct relative times at this sampling (= # contributing doses).
    indicesDoses = map_int( seq_len( nrow( timeDose ) ),
                            ~ length( unique( timeDose[.x, ] ) ) )

    list( data = data.frame( timeDose, indicesDoses ), dose = dose, tau = tau )
  }) |> set_names( outcomesWithAdministration )

  prop( model, "samplings" ) = samplings
  prop( model, "solverInputs" ) = solverInputs

  return( model )
}


#' Evaluate analytic steady-state predictions (sum over contributing doses).
#' @param model A \code{ModelAnalyticSteadyState} object.
#' @param arm   An \code{Arm} object.
#' @return Named list of output data frames at requested sampling times.
#' @keywords internal
evaluateAnalyticSteadyStateCore = function( model, arm ) {

  parameters                 = prop( model, "modelParameters" )
  outcomesWithAdministration = prop( model, "outcomesWithAdministration" )
  outputNames                = prop( model, "outputNames" )
  samplings                  = prop( model, "samplings" )
  solverInputs               = prop( model, "solverInputs" )

  wrapperModelAnalytic          = prop( model, "wrapperModelAnalytic" )
  functionDefinitionWithAdmin   = wrapperModelAnalytic$functionDefinitionWithAdmin
  functionDefinitionWithNoAdmin = wrapperModelAnalytic$functionDefinitionWithNoAdmin

  mu = .extractMu( parameters )

  evaluationModelTmpList = map( seq_along( samplings ), function( iterTime ) {

    # Accumulator for PK predictions used by passive (no-admin) equations.
    currentArgsNoAdmin = as.list( mu )

    outcomesResults = vector( "list", length( outcomesWithAdministration ) )
    for ( i in seq_along( outcomesWithAdministration ) ) {
      outcome = outcomesWithAdministration[[ i ]]
      data         = solverInputs[[ outcome ]]$data
      dose         = solverInputs[[ outcome ]]$dose
      indicesDoses = data$indicesDoses[ iterTime ]

      # Relative times and doses for all infusions that contribute at this t.
      timesVec = as.numeric( data[ iterTime, seq_len( indicesDoses ) ] )
      dosesVec = as.numeric( dose[ seq_len( indicesDoses ) ] )

      argsAdmin = c( currentArgsNoAdmin,
                     set_names( list( timesVec, dosesVec ),
                                c( paste0( "t_", outcome ), paste0( "dose_", outcome ) ) ) )
      argsAdmin[[ "tau" ]] = solverInputs[[ outcome ]]$tau

      # Superposition: sum closed-form contribution of each dose.
      evaluationOutcomeWithAdmin = sum( do.call( functionDefinitionWithAdmin, argsAdmin )[[ 1L ]] )
      currentArgsNoAdmin[[ outcome ]] = evaluationOutcomeWithAdmin
      currentArgsNoAdmin[[ "tau" ]]   = solverInputs[[ outcome ]]$tau

      evaluationOutcomeWithNoAdmin = do.call( functionDefinitionWithNoAdmin, currentArgsNoAdmin )[[ 1L ]]

      outcomesResults[[ i ]] = if ( is.null( evaluationOutcomeWithNoAdmin ) ||
                                    length( evaluationOutcomeWithNoAdmin ) == 0L ) {
        data.frame( Admin = evaluationOutcomeWithAdmin )
      } else {
        data.frame( Admin = evaluationOutcomeWithAdmin, NoAdmin = evaluationOutcomeWithNoAdmin )
      }
    }
    data.frame( time = samplings[[iterTime]], do.call( cbind, outcomesResults ) )
  })

  evaluationModelTmp = list_rbind( evaluationModelTmpList )
  colnames( evaluationModelTmp ) = c( "time", outputNames )

  samplings_by_output = set_names( map( prop( arm, "samplingTimes" ), ~ prop( .x, "samplings" ) ), outputNames )
  set_names(
    map( outputNames, ~ evaluationModelTmp[ evaluationModelTmp$time %in% samplings_by_output[[.x]], c("time", .x) ] ),
    outputNames
  )
}


#' Default method for \code{ModelAnalyticSteadyState}.
#' @return Named list of output data frames at requested sampling times.
#' @name evaluateModel
#' @keywords internal
method( evaluateModel, ModelAnalyticSteadyState ) = function( model, arm ) {
  if ( usesCovariateOccasionStructure( model ) )
    evaluateModelWithCovariates( model, arm, evaluateAnalyticSteadyStateCore )
  else
    evaluateAnalyticSteadyStateCore( model, arm )
}


#' Default method for \code{ModelAnalyticSteadyState}.
#' @param pkModel First argument of generic.
#' @param pfimproject \code{PFIMProject} object (unused).
#' @return List of PK equations from \code{pkModel}.
#' @name definePKModel
#' @keywords internal
method( definePKModel, list( ModelAnalyticSteadyState, PFIMProject ) ) = function( pkModel, pfimproject ) {
  prop( pkModel, "modelEquations" )
}


#' Default method for \code{ModelAnalyticSteadyState}.
#' @param pkModel First argument of generic.
#' @param pdModel Analytic PD model.
#' @param pfimproject \code{PFIMProject} object (unused).
#' @return Concatenated analytic PK/PD equation list.
#' @name definePKPDModel
#' @keywords internal
method( definePKPDModel, list( ModelAnalyticSteadyState, ModelAnalytic, PFIMProject ) ) =
  function( pkModel, pdModel, pfimproject ) {
    c( prop( pkModel, "modelEquations" ), prop( pdModel, "modelEquations" ) )
  }


#' Default method for \code{ModelAnalyticSteadyState}.
#' @param pkModel First argument of generic.
#' @param pdModel ODE PD model.
#' @param pfimproject \code{PFIMProject} used for remapping.
#' @return Named list of remapped ODE equations.
#' @name definePKPDModel
#' @keywords internal
method( definePKPDModel, list( ModelAnalyticSteadyState, ModelODE, PFIMProject ) ) =
  function( pkModel, pdModel, pfimproject ) {

    equations = c(
      convertPKModelAnalyticToPKModelODE( pkModel ),
      prop( pdModel, "modelEquations" )
    )
    eq = remapPkpdLibraryEquations( equations, pfimproject )
    set_names( eq, .derivativeNamesFromCompartments( pfimproject, length( eq ) ) )
  }
