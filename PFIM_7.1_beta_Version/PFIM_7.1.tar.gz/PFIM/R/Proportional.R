#' @title Proportional
#' @description
#' Proportional residual error: variance proportional to the prediction.
#' @inheritParams ModelError
#' @include ModelError.R
#' @return An S7 object of class \code{Proportional}.
#' @export

Proportional = new_class( "Proportional", package = "PFIM", parent = ModelError,
                         constructor = function( output = character( 0 ),
                                                equation = expression( sigmaSlope ),
                                                derivatives = list(),
                                                sigmaInter = 0.0,
                                                sigmaSlope = 0.0,
                                                sigmaInterFixed = FALSE,
                                                sigmaSlopeFixed = FALSE,
                                                cError = 1.0 ) {
                           .checkModelErrorSigmas( sigmaInter, sigmaSlope, cError )
                           # Pure proportional: additive intercept must be zero.
                           if ( sigmaInter != 0 )
                             stop( "Proportional(): sigmaInter must be 0.", call. = FALSE )
                           new_object( .parent = ModelError,
                                      output = output,
                                      equation = equation,
                                      derivatives = derivatives,
                                      sigmaInter = 0.0,
                                      sigmaSlope = sigmaSlope,
                                      sigmaInterFixed = sigmaInterFixed,
                                      sigmaSlopeFixed = sigmaSlopeFixed,
                                      cError = cError )
                         } )
