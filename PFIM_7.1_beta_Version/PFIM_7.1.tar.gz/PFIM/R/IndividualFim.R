#' @title IndividualFim
#' @description
#' Individual (subject-level) Fisher information matrix.
#'
#' Supports covariates and IOV: gradients and residual variance are averaged over
#' covariate combinations and occasions (same expectation as for population designs).
#'
#' @inheritParams Fim
#' @details
#' Block-diagonal structure:
#' \deqn{M_I = \mathrm{bdiag}(M_\mu, M_\sigma)}
#' where \eqn{M_\mu = G^\top V^{-1} G} and \eqn{M_\sigma} is the variance-effects block.
#' @return An \code{IndividualFim} object (filled by \code{run()}).
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' }
#' @include Fim.R
#' @include PFIMProject.R
#' @export

IndividualFim = new_class( "IndividualFim", package = "PFIM", parent = Fim )
S4_register( IndividualFim )

#' Variance block of the individual FIM (\eqn{\partial V / \partial \sigma} form).
#' @name evaluateVarianceFIM
#' @keywords internal

method( evaluateVarianceFIM, list( IndividualFim, Model, Arm ) ) = function( fim, model, arm ) {

  ev    = getArmEvaluationVarianceFlat( arm )
  V     = as.matrix( ev$errorVariance )
  V_inv = .safeCholInv( V )

  list( MFVar = .computeMFVar( V_inv, ev$sigmaDerivatives ), V = V, V_inv = V_inv )
}

#' Compute the individual FIM for one arm.
#'
#' Fixed-effect block \eqn{G^\top V^{-1} G} plus residual variance block; not
#' scaled by arm size (individual / subject-level FIM).
#' @name evaluateFim
#' @keywords internal

method( evaluateFim, list( IndividualFim, Model, Arm ) ) = function( fim, model, arm ) {

  varBlock = evaluateVarianceFIM( fim, model, arm )
  feCols   = .fimFixedEffectColumnNames( model, arm )
  G        = .gradientMatrix( arm, feCols, model )
  V_inv    = varBlock$V_inv
  MFbeta   = crossprod( G, V_inv ) %*% G

  prop( fim, "fisherMatrix" ) = as.matrix( bdiag( MFbeta, varBlock$MFVar ) )
  fim
}

#' Attach evaluated individual FIM results (labels, SE/RSE, condition numbers).
#' @name setEvaluationFim
#' @export

method( setEvaluationFim, IndividualFim ) = function( fim, evaluation ) {

  greek  = .greekConsole
  fe     = .fimFixedEffectLabels( evaluation, greek )
  sigma  = .fimSigmaBlockLabels( evaluation, greek )

  allNames = c( fe$columnNamesMu, fe$columnNamesBeta, sigma$columnNamesSigma )
  pVals    = c( fe$muValues, fe$betaValues, sigma$sigmaValues )

  M = prop( fim, "fisherMatrix" )

  if ( ncol( M ) != length( allNames ) )
    stop( sprintf(
      "IndividualFim setEvaluationFim: FIM dim %d != %d column names.",
      ncol( M ), length( allNames )
    ), call. = FALSE )

  dimnames( M ) = list( allNames, allNames )

  feNames         = c( fe$columnNamesMu, fe$columnNamesBeta )
  fixedEffects    = M[ feNames, feNames, drop = FALSE ]
  varianceEffects = M[ sigma$columnNamesSigma, sigma$columnNamesSigma, drop = FALSE ]

  se = .fimBuildSeAndRse( M, allNames, pVals, abs_denominator = TRUE )

  prop( fim, "fisherMatrix"              ) = M
  prop( fim, "fixedEffects"              ) = fixedEffects
  prop( fim, "varianceEffects"           ) = varianceEffects
  prop( fim, "condNumberFixedEffects"    ) = .conditionNumber( fixedEffects )
  prop( fim, "condNumberVarianceEffects" ) = .conditionNumber( varianceEffects )
  prop( fim, "SEAndRSE"                  ) = se
  prop( fim, "singularFim"               ) = isTRUE( se$singular )

  fim
}

#' Print FIM summaries to the console
#' @name showFIM
#' @export

method( showFIM, IndividualFim ) = function( fim ) {

  .hdr = function( t ) cat( sprintf(
    "\n*************************************** \n %s \n*************************************** \n\n", t
  ))

  .hdr( "Individual Fisher Matrix" );        print( prop( fim, "fisherMatrix"   ) )
  .hdr( "Fixed effects (\u03bc)" );          print( prop( fim, "fixedEffects"   ) )
  .hdr( "Variance components (\u03c3)" );    print( prop( fim, "varianceEffects") )

  M   = prop( fim, "fisherMatrix" )
  cn1 = prop( fim, "condNumberFixedEffects"    )
  cn2 = prop( fim, "condNumberVarianceEffects" )

  cat( "\n*********************************************** \n",
       " log-Determinant, condition numbers and D-criterion \n",
       "*********************************************** \n\n" )
  cat( "log-Determinant:",  as.numeric( .fimLogDeterminant( M ) ),       "\n" )
  cat( "D-criterion:",  as.numeric( Dcriterion(fim) ), "\n" )
  cat( "Conditional number (fixed effects):",    as.numeric( cn1 ), "\n" )
  cat( "Conditional number (variance effects):", as.numeric( cn2 ), "\n" )
  .hdr( "Parameters estimation" )
  .printFimSeAndRse( fim )

  rn = rownames( prop( fim, "fisherMatrix" ) )
  if ( any( grepl( "\u03b2_", rn, fixed = TRUE ) ) ) {
    cat( "\n*************************************** \n Legend: \n" )
    cat( " \u03bc  = fixed effects\n" )
    cat( " \u03b2  = covariate effects\n" )
    cat( " \u03c3  = residual error\n" )
    cat( "*************************************** \n\n" )
  }

  invisible( fim )
}

# SE / RSE bar charts
#' Build Individual FIM SE/RSE bar plot data and figure.
#' @param fim \code{IndividualFim} object.
#' @param evaluation \code{PFIMProject} providing labels and fitted FIM.
#' @param metric \code{"SE"} or \code{"RSE"}.
#' @return \code{ggplot} object of parameter uncertainty bars.
#' @noRd
#' @keywords internal
.individualSEPlot = function( fim, evaluation, metric ) {
  fim   = setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  seDF  = prop( fim, "SEAndRSE" )$SEAndRSE
  greekC = .greekConsole
  fe    = .fimFixedEffectLabels( evaluation, greekC )
  sigma = .fimSigmaBlockLabels( evaluation, greekC )
  facet = function( key ) .pfimSeRseFacetLabel( metric, key )

  # SE/RSE barplots: mu / beta / sigma (sensitivity plots omit beta).
  n_mu    = length( fe$columnNamesMu )
  n_beta  = length( fe$columnNamesBeta )
  n_sigma = length( sigma$columnNamesSigma )
  idx = seq_len( n_mu + n_beta + n_sigma )
  paramLabels = c(
    .stripGreekPrefix( fe$columnNamesMu,       greekC[ "mu"    ] ),
    .stripGreekPrefix( fe$columnNamesBeta,     greekC[ "beta"  ] ),
    .stripGreekPrefix( sigma$columnNamesSigma, greekC[ "sigma" ] )
  )
  cats = c(
    rep( facet( "mu"    ), n_mu ),
    rep( facet( "beta"  ), n_beta ),
    rep( facet( "sigma" ), n_sigma )
  )
  y_vals = if ( metric == "SE" ) seDF$SE[ idx ] else seDF$RSE[ idx ]
  df = data.frame( Parameter = paramLabels, y = y_vals, cat = cats )
  names( df )[ 2L ] = metric
  .fimSeRseBarPlot( df, metric, unique( cats ) )
}

#' @export
method( plotSEFIM,  list( IndividualFim, PFIMProject ) ) =
  function( fim, evaluation ) .individualSEPlot( fim, evaluation, "SE"  )

#' @export
method( plotRSEFIM, list( IndividualFim, PFIMProject ) ) =
  function( fim, evaluation ) .individualSEPlot( fim, evaluation, "RSE" )

#' FIM tables for HTML reports
#' @name tablesForReport
#' @export

method( tablesForReport, list( IndividualFim, PFIMProject ) ) = function( fim, evaluation ) {

  SEAndRSE                  = prop( fim, "SEAndRSE" )$SEAndRSE
  M                         = prop( fim, "fisherMatrix"            )
  fe                        = as.matrix( prop( fim, "fixedEffects"    ) )
  ve                        = as.matrix( prop( fim, "varianceEffects" ) )
  condNumberFixedEffects    = prop( fim, "condNumberFixedEffects"    )
  condNumberVarianceEffects = prop( fim, "condNumberVarianceEffects" )

  columnNamesFe    = .fimFixedEffectLatexLabels( evaluation, fixedEffects = fe )
  columnNamesSigma = .fimConsoleToLatexLabels( rownames( ve ) )

  dimnames( fe ) = list( columnNamesFe,    columnNamesFe    )
  dimnames( ve ) = list( columnNamesSigma, columnNamesSigma )

  FIMCriteriaTable = .fimCriteriaKable(
    .fimLogDeterminant( M ), Dcriterion( fim ),
    condNumberFixedEffects, condNumberVarianceEffects
  )

  paramLabels = .fimSeRseReportLabels(
    evaluation, SEAndRSE, fixedEffects = fe, varianceEffects = ve
  )

  SEAndRSETable = .fimSeRseKable( paramLabels, SEAndRSE )

  list( fixedEffectsTable    = .kblReportStyled( fe ),
        varianceEffectsTable = .kblReportStyled( ve ),
        FIMCriteriaTable     = FIMCriteriaTable,
        SEAndRSETable        = SEAndRSETable )
}

# Report rendering
# .renderReport and .renderEvalReport are defined in Fim.R.

#' Render the evaluation HTML report
#' @name generateReportEvaluation
#' @export
method( generateReportEvaluation, IndividualFim ) =
  .renderEvalReport( "EvaluationIndividualFIM.Rmd" )
