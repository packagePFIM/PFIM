# Residual variance (sigmaInter + sigmaSlope * f^cError)^2 and derivatives.

#' Derivatives of residual variance w.r.t. estimable sigma parameters.
#'
#' Builds diagonal variance \eqn{( \sigma_{\mathrm{inter}} +
#' \sigma_{\mathrm{slope}} f^{c} )^2} and sparse derivative matrices for each
#' unfixed, non-zero sigma component used in the population FIM lambda block.
#' @param sigmaInter Additive residual SD.
#' @param sigmaSlope Proportional residual SD.
#' @param sigmaInterFixed Logical; skip derivative when fixed.
#' @param sigmaSlopeFixed Logical; skip derivative when fixed.
#' @param cError Power on the prediction in the proportional term.
#' @param f Numeric vector of model predictions at sampling times.
#' @return List with \code{sigmaDerivatives} (named list of matrices) and
#'   \code{errorVariance} (diagonal variance matrix).
#' @noRd
#' @keywords internal
.pfimErrorModelDerivatives = function( sigmaInter, sigmaSlope, sigmaInterFixed,
                                       sigmaSlopeFixed, cError, f ) {
  # Proportional contribution: f or f^cError when power differs from 1.
  f_term   = if ( cError == 1 ) f else f^cError
  base     = sigmaInter + sigmaSlope * f_term
  variance = base^2
  n        = length( f )
  I        = diag( n )

  # ∂(base^2)/∂sigmaInter = 2*base; ∂(base^2)/∂sigmaSlope = 2*base*f_term.
  specs = list(
    list( name = "sigmaInter", value = sigmaInter, fixed = sigmaInterFixed,
          scale = 2 * base ),
    list( name = "sigmaSlope", value = sigmaSlope, fixed = sigmaSlopeFixed,
          scale = 2 * base * f_term )
  )
  # Drop fixed or zero sigmas (not part of the estimable residual block).
  specs = keep( specs, ~ .x$value != 0 && !.x$fixed )
  sigmaDerivatives = map( specs, function( spec ) {
    stats::setNames( list( spec$scale * I ), spec$name )
  } ) |> list_flatten()

  list(
    sigmaDerivatives = sigmaDerivatives,
    errorVariance    = variance * I
  )
}
