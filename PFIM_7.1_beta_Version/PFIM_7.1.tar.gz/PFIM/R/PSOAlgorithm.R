#' @title PSOAlgorithm
#' @description
#' Particle Swarm Optimization for sampling-time search (Rcpp kernel in \code{src/PSOKernel.cpp}).
#' Pass \code{maxIteration}, \code{populationSize}, \code{seed}, and learning coefficients
#' via \code{optimizerParameters} on \code{\link{Optimization}}.
#' Optional \code{tolerance} (default \code{0}, disabled) and \code{stallIterations}
#' (default \code{5}) enable early stopping.
#' @param optimizerOutputs List filled by \code{optimizeDesign()} (optimal arms, etc.).
#' @return A \code{PSOAlgorithm} specification object.
#' @examples
#' \dontrun{
#' vignette("Example02")
#' }
#' @include Optimization.R
#' @export

PSOAlgorithm = new_class( "PSOAlgorithm", package = "PFIM",
                          properties = list(
                            optimizerOutputs = new_property( class_list, default = list() )
                          ) )
S4_register( PSOAlgorithm )

#' Particle Swarm Optimization kernel (Rcpp).
#'
#' Compiled implementation in \code{src/PSOKernel.cpp}. FIM evaluation uses
#' \code{eval_fitness} (scalar fallback) and \code{eval_fitness_batch}
#' (one matrix per swarm step).
#'
#' @name pso_optimize_Rcpp
#' @return A list of optimization results.
#' @keywords internal
NULL

#' PSO continuous D-optimal design (delegates to multi-design driver).
#'
#' @param optimizationObject An \code{\link{Optimization}} project.
#' @param optimizationAlgorithm A \code{PSOAlgorithm} instance.
#' @return Updated \code{Optimization} after optimizing each design in turn.
#' @name optimizeDesign
#' @export

method( optimizeDesign, list( Optimization, PSOAlgorithm ) ) = function( optimizationObject, optimizationAlgorithm ) {
  .pfimContinuousOptimizeDesigns(
    optimizationObject,
    optimizationAlgorithm,
    .optimizePSOOneDesign
  )
}

#' Run PSO on a single design: flatten sampling windows, call C++ swarm, rebuild arms.
#'
#' Sets the RNG from \code{optimizerParameters$seed} and restores
#' \code{.Random.seed} on exit (\code{NULL} seed leaves the stream unchanged).
#' Fitness is \code{1/D} via R callbacks; invalid flat positions receive a large penalty.
#' @param optimizationObject Parent \code{Optimization}.
#' @param optimizationAlgorithm \code{PSOAlgorithm} instance (outputs filled here).
#' @return List with optimal arms / design evaluation pieces for the driver.
#' @noRd
#' @keywords internal
.optimizePSOOneDesign = function( optimizationObject, optimizationAlgorithm ) {

  optimizerParameters = projectProp( optimizationObject, "optimizerParameters" )
  restore_seed = .pfimLocalSeed( optimizerParameters$seed )
  on.exit( restore_seed(), add = TRUE )

  prep = .pfimPrepareContinuousDesign( optimizationObject )
  design = prep$design
  arms   = prep$arms

  prop( design, "arms" ) = .pfimSeedArmsFromConstraints( arms )
  initialDesign = .pfimCloneS7( design )

  layout = .buildFlatSamplingLayout( design )
  evalTemplate = .evaluationFromOptimization( optimizationObject, initialDesign, name = "" )

  # Scalar fitness: one particle position -> cost (used as fallback / single eval).
  eval_fitness = function( flat_pos ) {
    if ( !.isFlatValid( layout, flat_pos ) )
      return( .metaheuristicFitnessPenalty )
    .pfimMetaheuristicFitness( evalTemplate, design, arms, flat_pos )
  }

  # Batch fitness: one swarm iteration matrix (rows = particles) -> cost vector.
  eval_fitness_batch = function( pos_matrix ) {
    pos_matrix = as.matrix( pos_matrix )
    n = nrow( pos_matrix )
    if ( n == 0L ) return( numeric( 0 ) )
    costs = .pfimMetaheuristicFitnessBatch(
      evalTemplate, design, arms, pos_matrix, layout = layout
    )
    invalid = !vapply(
      seq_len( n ),
      function( i ) .isFlatValid( layout, pos_matrix[ i, ] ),
      logical( 1L )
    )
    costs[ invalid ] = .metaheuristicFitnessPenalty
    costs
  }

  phi1 = optimizerParameters$personalLearningCoefficient
  phi2 = optimizerParameters$globalLearningCoefficient
  phi  = phi1 + phi2
  if ( phi <= 4 )
    stop( sprintf(
      paste0(
        "PSOAlgorithm: personalLearningCoefficient + globalLearningCoefficient must be > 4 ",
        "(Clerc & Kennedy 2002). Current phi = %.4f; typical default is 4.1."
      ),
      phi
    ), call. = FALSE )
  phi_inner = phi * ( phi - 4 )
  if ( phi_inner <= 0 )
    stop( "PSOAlgorithm: phi * (phi - 4) must be positive.", call. = FALSE )

  constriction = 2 / abs( 2 - phi - sqrt( phi_inner ) )

  res_cpp = pso_optimize_Rcpp(
    n_pop_in           = as.integer( optimizerParameters$populationSize ),
    max_iter           = as.integer( optimizerParameters$maxIteration ),
    initial_pos        = layout$initial_flat,
    windows_list       = layout$windows_list,
    sorting_groups     = layout$sorting_groups,
    phi1               = phi1,
    phi2               = phi2,
    constriction       = constriction,
    show_process       = optimizerParameters$showProcess,
    eval_fitness       = eval_fitness,
    eval_fitness_batch = eval_fitness_batch,
    sample_valid_pos   = function() .sampleFlatFromConstraints( layout ),
    ftol               = optimizerParameters$tolerance %||% 0,
    stall_iterations   = as.integer( optimizerParameters$stallIterations %||% 5L )
  )

  finalArms     = .applyFlatToArms( res_cpp$globalBestDesign, arms )
  optimalDesign = .pfimOptimalDesignFrom( initialDesign, finalArms )

  .pfimStoreContinuousOptimization(
    optimizationObject, optimizationAlgorithm,
    initialDesign, optimalDesign,
    optimizerOutputs = list(
      optimalArms        = finalArms,
      psoAlgorithmOutput = res_cpp[ c( "globalBestCost", "converged", "iterations", "improved" ) ]
    ),
    finalArms = finalArms
  )
}

#' Constraint tables for optimization reports
#' @name constraintsTableForReport
#' @export

method( constraintsTableForReport, PSOAlgorithm ) = function( optimizationAlgorithm, arms ) {
  .pfimConstraintsTableContinuous( optimizationAlgorithm, arms )
}
