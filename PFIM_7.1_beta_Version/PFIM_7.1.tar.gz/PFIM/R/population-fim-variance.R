#' Chain-rule scale ∂f/∂η|₀ per parameter (uses \code{adjustGradient()}).
#' @noRd
#' @keywords internal
.pfimPopMuChainFactors = function( parameters ) {
  vapply( parameters, function( p ) {
    d = prop( p, "distribution" )
    adjustGradient( d, 1, prop( d, "mu" ) )
  }, numeric( 1L ) )
}

#' Outer product of a numeric vector with itself (\eqn{v v^\top}).
#' @noRd
#' @keywords internal
.outerColPopFim <- function( v ) tcrossprod( v )

#' Split mu-gradient columns by occasion widths.
#' @noRd
#' @keywords internal
.splitGradMuByOccasion <- function( G_adj_mu, occ_col_widths ) {
  if ( length( occ_col_widths ) < 2L ) return( list( G_adj_mu ) )
  offsets = c( 0L, cumsum( occ_col_widths ) )
  map( seq_along( occ_col_widths ), function( k ) {
    cols = ( offsets[[ k ]] + 1L ):offsets[[ k + 1L ]]
    G_adj_mu[ , cols, drop = FALSE ]
  } )
}

#' Block-diagonal IOV outer products across occasions for one gamma parameter.
#' @noRd
#' @keywords internal
.iovOuterBlocks <- function( gamma_idx, occ_grads_T ) {
  blocks = map( occ_grads_T, ~ .outerColPopFim( .x[ , gamma_idx, drop = FALSE ] ) )
  if ( length( blocks ) == 1L ) blocks[[ 1L ]] else as.matrix( bdiag( blocks ) )
}

#' One covariate x occasion block (MFbeta + MFVar); R reference for C++ parity tests.
#' @param mu_values Per-parameter chain-rule factors (LogNormal: \eqn{\mu};
#'   Normal: \eqn{1}); from \code{.pfimPopMuChainFactors()}.
#' @noRd
#' @keywords internal
.computePopFimCombo_R <- function( gradients,
                                   mu_values,
                                   omega_iiv,
                                   gamma_values,
                                   error_variance,
                                   occ_col_widths,
                                   sigma_derivatives,
                                   has_iov ) {
  n_omega     = length( mu_values )
  n_rows      = nrow( gradients )
  n_occasions = length( occ_col_widths )
  n_sigma     = length( sigma_derivatives )

  # Rows: mu block first, then optional beta rows from covariate effects.
  gradients_mu = gradients[ seq_len( n_omega ), , drop = FALSE ]
  if ( n_rows > n_omega ) {
    gradients_beta = gradients[ ( n_omega + 1L ):n_rows, , drop = FALSE ]
  } else {
    gradients_beta = matrix( 0, nrow = 0L, ncol = ncol( gradients ) )
  }

  # Random-effect covariance: IIV alone, IIV+IOV pooled, or IIV ⊕ γ blocks per occasion.
  n_omega_rows = length( omega_iiv )
  OMEGA = if ( has_iov && n_occasions > 1L ) {
    diag( c( omega_iiv, rep( gamma_values^2, n_occasions ) ) )
  } else if ( has_iov ) {
    diag( omega_iiv + gamma_values^2 )
  } else {
    diag( omega_iiv, nrow = n_omega_rows )
  }

  # Chain-rule scale ∂f/∂η|₀ (LogNormal: ×μ; Normal: ×1).
  gradients_adjusted_mu = gradients_mu * mu_values
  gradients_adjusted  = if ( nrow( gradients_beta ) > 0L )
    rbind( gradients_adjusted_mu, gradients_beta )
  else
    gradients_adjusted_mu

  if ( has_iov && n_occasions > 1L ) {
    # Multi-occasion IOV: V = V_IIV + Σ_i γ_i² blockdiag(g_i g_iᵀ) + R.
    scaled_mu     = gradients_adjusted_mu * sqrt( omega_iiv )
    V_iiv         = as.matrix( crossprod( scaled_mu ) )
    occ_grads_T   = map( .splitGradMuByOccasion( gradients_adjusted_mu, occ_col_widths ), t )
    gamma_indices = which( gamma_values > 0 )

    V_iov = if ( length( gamma_indices ) > 0L ) {
      Reduce( `+`, lapply( gamma_indices, function( i )
        gamma_values[ i ]^2 * .iovOuterBlocks( i, occ_grads_T )
      ))
    } else {
      matrix( 0, nrow = nrow( error_variance ), ncol = ncol( error_variance ) )
    }

    V     = V_iiv + V_iov + error_variance
    V_inv = .safeCholInv( V )

    # Fixed-effect block MFβ = G V⁻¹ Gᵀ (includes beta rows when present).
    MFbeta_full = ( gradients %*% V_inv ) %*% t( gradients )
    grad_mu_T   = t( gradients_adjusted_mu )

    # dV/dγ_i outer products; residual sigma derivatives appended for MFVar.
    dV_gamma = lapply( gamma_indices, function( i )
      .iovOuterBlocks( i, occ_grads_T )
    )
    dV_full  = c( dV_gamma, sigma_derivatives )
  } else {
    # Single occasion (or no IOV): V = Gᵀ Ω G + R.
    G_mu  = gradients_adjusted[ seq_len( n_omega_rows ), , drop = FALSE ]
    tmp   = OMEGA %*% G_mu
    V     = crossprod( tmp, G_mu ) + error_variance
    V_inv = .safeCholInv( V )

    MFbeta_full = ( gradients %*% V_inv ) %*% t( gradients )
    grad_mu_T   = t( gradients_adjusted_mu )

    gamma_indices = if ( has_iov ) which( gamma_values > 0 ) else integer( 0L )
    dV_full       = sigma_derivatives
  }

  # W columns feed the mixed MFVar (omega, optional gamma, then sigma via dV_full).
  W = grad_mu_T[ , seq_len( n_omega ), drop = FALSE ]
  if ( has_iov && n_occasions <= 1L && length( gamma_indices ) > 0L )
    W = cbind( W, grad_mu_T[ , gamma_indices, drop = FALSE ] )

  MFVar = computeMFVar_mixed_Rcpp( V_inv, W, dV_full )

  # Assemble full combination block: fixed effects then variance parameters.
  n_fixed = nrow( MFbeta_full )
  n_var   = nrow( MFVar )
  out     = matrix( 0, n_fixed + n_var, n_fixed + n_var )
  out[ seq_len( n_fixed ), seq_len( n_fixed ) ] = MFbeta_full
  out[ n_fixed + seq_len( n_var ), n_fixed + seq_len( n_var ) ] = MFVar
  out
}

#' Standard population path: fixed mu, diagonal IIV, no occasion structure.
#'
#' Builds \eqn{V = G_\eta^\top \Omega G_\eta + R}, then the fixed-effect block
#' \eqn{G V^{-1} G^\top} and the mixed variance block via Rcpp.
#' @param model A \code{Model} object.
#' @param arm An \code{Arm} with flat gradients and variance.
#' @param isFixedMu Logical vector of fixed mu flags.
#' @param isFixedOmega Logical vector of fixed omega flags (unused here; MFVar
#'   already drops fixed sigmas upstream).
#' @return List with \code{MFbeta} and \code{MFVar} matrices.
#' @noRd
#' @keywords internal
.evaluateVarianceFIMPopSimple <- function( model, arm, isFixedMu, isFixedOmega ) {
  parameters     = prop( model, "modelParameters" )
  parameterNames = map_chr( parameters, ~ prop( .x, "name" ) )

  allGradientsData = prop( arm, "evaluationGradients" )
  varianceResults  = prop( arm, "evaluationVariance" )
  outputNames      = prop( model, "outputNames" )

  omega_IIV     = .modelOmegaIIVVariance( model )
  muChain       = .pfimPopMuChainFactors( parameters )
  nOmega        = length( parameterNames )
  errorVariance = as.matrix( varianceResults$errorVariance )

  # Stack outputs horizontally: rows = parameters, cols = observations.
  gradients         = do.call( cbind, map( outputNames, ~ t( allGradientsData[[ .x ]] ) ) )
  OMEGA             = diag( omega_IIV, nrow = nOmega )
  gradientsAdjusted = gradients * muChain

  V     = crossprod( OMEGA %*% gradientsAdjusted, gradientsAdjusted ) + errorVariance
  V_inv = .safeCholInv( V )

  MFbeta_full = ( gradients %*% V_inv ) %*% t( gradients )
  MFVar       = computeMFVar_mixed_Rcpp(
    V_inv, t( gradientsAdjusted ), varianceResults$sigmaDerivatives
  )

  # Drop fixed-mu rows/cols from the reported fixed-effect block.
  mu_idx_keep = seq_len( nOmega )[ !isFixedMu ]
  list(
    MFbeta = MFbeta_full[ mu_idx_keep, mu_idx_keep, drop = FALSE ],
    MFVar  = MFVar
  )
}

#' Covariate / occasion path: sum Fisher blocks over covariate combinations.
#' @noRd
#' @keywords internal
.evaluateVarianceFIMPopCovariateOccasion <- function( model, arm,
                                                       isFixedMu,
                                                       isFixedOmega,
                                                       isFixedLambda = NULL ) {
  parameters     = prop( model, "modelParameters" )
  parameterNames = map_chr( parameters, ~ prop( .x, "name" ) )

  allGradientsData = prop( arm, "evaluationGradients" )
  varianceResults  = prop( arm, "evaluationVariance" )
  outputNames      = prop( model, "outputNames" )

  omega_IIV     = .modelOmegaIIVVariance( model )
  gamma_values  = vapply( parameters, function(x) pluck( x, "gamma", .default = 0 ), numeric( 1L ), USE.NAMES = FALSE )
  has_IOV       = any( gamma_values > 0 )
  muChain       = .pfimPopMuChainFactors( parameters )

  nOmega = length( parameterNames )
  nGamma = sum( gamma_values > 0 )
  nSigma = length(
    varianceResults[[ 1L ]]$variances[[ 1L ]]$variance$sigmaDerivatives
  )
  numberOfOccasions = varianceResults[[ 1L ]]$variances |>
    map_chr( "occasion" ) |> unique() |> length()
  # IOV gamma block only when at least one gamma > 0
  nGamma_eff = if ( has_IOV ) nGamma else 0L
  nLambda    = nOmega + nGamma_eff + nSigma

  compute_fisher_one_combination = function( iter ) {
    # one covariate combination: gradients and R block-diagonal over occasions
    gradients_by_occasion = map( seq_len( numberOfOccasions ), function( occ ) {
      gpo = map( outputNames, ~ t( allGradientsData[[ iter ]]$gradients[[ occ ]]$gradient[[ .x ]] ) )
      if ( length( gpo ) == 1L ) gpo[[ 1L ]] else do.call( cbind, gpo )
    })

    variance_by_occasion = map(
      seq_len( numberOfOccasions ),
      ~ as.matrix( varianceResults[[ iter ]]$variances[[ .x ]]$variance$errorVariance )
    )

    # sigma_k derivatives: block-diag across occasions when n_occ > 1
    sigma_derivatives = map( seq_len( nSigma ), function( i ) {
      sdo = map( seq_len( numberOfOccasions ),
                 ~ varianceResults[[ iter ]]$variances[[ .x ]]$variance$sigmaDerivatives[[ i ]] )
      if ( length( sdo ) == 1L ) as.matrix( sdo[[ 1L ]] ) else as.matrix( bdiag( sdo ) )
    })

    error_variance = if ( length( variance_by_occasion ) == 1L )
      variance_by_occasion[[ 1L ]]
    else
      as.matrix( bdiag( variance_by_occasion ) )

    block = computePopFimCombo_Rcpp(
      if ( length( gradients_by_occasion ) == 1L ) gradients_by_occasion[[ 1L ]]
      else reduce( gradients_by_occasion, cbind ),
      unname( muChain ),
      unname( omega_IIV ),
      unname( gamma_values ),
      error_variance,
      vapply( gradients_by_occasion, ncol, integer( 1L ) ),
      sigma_derivatives,
      has_iov = has_IOV
    )
    as.matrix( block ) * allGradientsData[[ iter ]]$proportion
  }

  # population FIM = sum_c pi_c M_c over covariate combinations c
  fisherMatrix = Reduce( "+", lapply( seq_along( allGradientsData ), compute_fisher_one_combination ) )

  # layout: [mu (nOmega) | beta | omega/gamma/sigma (nLambda)]
  nBeta_total = nrow( fisherMatrix ) - nLambda - nOmega
  nMuAndBeta  = nOmega + nBeta_total
  mu_idx_keep = seq_len( nOmega )[ !isFixedMu ]
  beta_idx    = if ( nBeta_total > 0L ) ( nOmega + 1L ):nMuAndBeta else integer( 0L )
  var_idx     = ( nMuAndBeta + 1L ):nrow( fisherMatrix )

  MFbeta     = fisherMatrix[ c( mu_idx_keep, beta_idx ), c( mu_idx_keep, beta_idx ), drop = FALSE ]
  MFVar_full = fisherMatrix[ var_idx, var_idx, drop = FALSE ]
  isFixedLambda = isFixedLambda %||% ( isFixedMu | isFixedOmega )
  if ( length( isFixedLambda ) != nOmega )
    stop(
      "isFixedLambda length (", length( isFixedLambda ),
      ") must match the number of parameters (", nOmega, ").",
      call. = FALSE
    )
  keepLambda = c( !isFixedLambda, rep( TRUE, nGamma_eff + nSigma ) )

  list(
    MFbeta = MFbeta,
    MFVar  = MFVar_full[ keepLambda, keepLambda, drop = FALSE ]
  )
}

#' Dispatch population variance FIM between simple and covariate/occasion paths.
#' @noRd
#' @keywords internal
.evaluateVarianceFIMPop <- function( fim, model, arm,
                                    isFixedMu     = NULL,
                                    isFixedOmega  = NULL,
                                    isFixedLambda = NULL ) {
  parameters = prop( model, "modelParameters" )
  isFixedMu = isFixedMu %||% map_lgl( parameters, .paramMuFixed )
  isFixedOmega = isFixedOmega %||% map_lgl( parameters, .paramOmegaFixed )
  isFixedLambda = isFixedLambda %||% ( isFixedMu | isFixedOmega )

  if ( !usesCovariateOccasionStructure( model ) ) {
    .evaluateVarianceFIMPopSimple( model, arm, isFixedMu, isFixedOmega )
  } else {
    .evaluateVarianceFIMPopCovariateOccasion(
      model, arm, isFixedMu, isFixedOmega, isFixedLambda
    )
  }
}
