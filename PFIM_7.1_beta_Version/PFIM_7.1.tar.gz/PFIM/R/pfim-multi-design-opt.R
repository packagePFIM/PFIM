#' @include Optimization.R
#' @include pfim-fim-cache.R
#' @keywords internal
NULL

# Continuous multi-design optimization (Simplex / PSO / PGBO).
#
# When `length(designs) > 1`, run one independent search per design. The primary
# `optimisationDesign` / algorithm outputs stay on design 1; other designs are
# stored under `optimisationAlgorithmOutputs$perDesign`.

#' Run a continuous optimizer once per design, then reassemble the Optimization.
#'
#' @param optimizationObject An \code{Optimization} with one or more designs.
#' @param optimizationAlgorithm The continuous algorithm object.
#' @param one_design_fn Function(\code{optimizationObject}, \code{algorithm}) that
#'   optimizes the single design currently in \code{projectProp(..., "designs")}.
#' @return Updated \code{Optimization} with all designs optimized.
#' @noRd
#' @keywords internal
.pfimContinuousOptimizeDesigns = function(
    optimizationObject,
    optimizationAlgorithm,
    one_design_fn
) {
  designs = projectProp( optimizationObject, "designs" )
  # Single design: open a FIM cache scope and delegate immediately.
  if ( length( designs ) <= 1L ) {
    .pfimFimCacheBegin( optimizationObject )
    return( one_design_fn( optimizationObject, optimizationAlgorithm ) )
  }

  .pfimFimCacheBegin( optimizationObject )
  optimized = vector( "list", length( designs ) )
  per_design = vector( "list", length( designs ) )
  primary = NULL

  for ( i in seq_along( designs ) ) {
    # Restrict the project to one design for this search.
    projectProp( optimizationObject, "designs" ) <- list( designs[[ i ]] )
    optimizationObject = one_design_fn( optimizationObject, optimizationAlgorithm )
    optimized[[ i ]]  = projectProp( optimizationObject, "designs" )[[ 1L ]]
    per_design[[ i ]] = list(
      name                 = prop( optimized[[ i ]], "name" ),
      optimisationDesign   = prop( optimizationObject, "optimisationDesign" ),
      optimalArms          = pluck(
        prop( optimizationObject, "optimisationAlgorithmOutputs" ),
        "optimalArms"
      )
    )
    # Keep design-1 outputs as the top-level Optimization result.
    if ( i == 1L )
      primary = list(
        optimisationDesign           = prop( optimizationObject, "optimisationDesign" ),
        optimisationAlgorithmOutputs = prop( optimizationObject, "optimisationAlgorithmOutputs" )
      )
  }

  projectProp( optimizationObject, "designs" ) <- optimized
  prop( optimizationObject, "optimisationDesign" ) = primary$optimisationDesign
  outputs = primary$optimisationAlgorithmOutputs
  outputs$perDesign = per_design
  prop( optimizationObject, "optimisationAlgorithmOutputs" ) = outputs
  optimizationObject
}
