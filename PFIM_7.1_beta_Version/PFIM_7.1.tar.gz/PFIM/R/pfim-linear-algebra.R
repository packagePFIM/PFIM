# Matrix inverses and FIM packing helpers (C++ kernels in pfim-linalg.hpp).
#
# Thin R wrappers around chol_inv / safe_solve, plus lower-triangle packing used
# by the Fedorov-Wynn PackedFim layout, and correlation from the FIM inverse.

#' Cholesky-based inverse of a symmetric positive-definite matrix.
#' @noRd
#' @keywords internal
.safeCholInv = function( V ) chol_inv_Rcpp( V )

#' Pack the lower triangle of a symmetric FIM row-wise (Fedorov-Wynn \code{PackedFim} order).
#'
#' Returns a 1-row matrix of length \eqn{p(p+1)/2} with elements
#' \eqn{M_{11}, M_{21}, M_{22}, M_{31}, \ldots}.
#' @noRd
#' @keywords internal
.packFisherLowerTriangle = function( M ) {
  p = nrow( M )
  n = p * ( p + 1L ) / 2L
  out = numeric( n )
  k = 1L
  for ( row in seq_len( p ) ) {
    for ( col in seq_len( row ) ) {
      out[[ k ]] = M[ row, col ]
      k = k + 1L
    }
  }
  matrix( out, nrow = 1L )
}

#' Estimator correlation matrix from a Fisher information matrix.
#'
#' Computes \code{cov2cor(solve(M))} via a safe Cholesky inverse. Singular FIMs
#' return an NA matrix instead of aborting (same cases as \code{.fimBuildSeAndRse}).
#' @noRd
#' @keywords internal
.fimCorrelationMatrix = function( M ) {
  tryCatch(
    stats::cov2cor( .safeCholInv( M ) ),
    error = function( e ) {
      p = nrow( M )
      matrix( NA_real_, p, p, dimnames = dimnames( M ) )
    }
  )
}

#' General square-matrix inverse (singular -> error from C++).
#' @noRd
#' @keywords internal
.safeSolve = function( M ) safe_solve_Rcpp( M )
