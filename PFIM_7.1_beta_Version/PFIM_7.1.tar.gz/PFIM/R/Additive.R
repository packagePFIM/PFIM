#' @title Additive
#' @description
#' Additive covariate link: theta(cov) = mu * (1 + beta * cov).
#' @inheritParams CovariateModelEquation
#' @include CovariateModelEquation.R
#' @return An S7 object of class \code{Additive}.
#' @export

Additive = new_class("Additive", package = "PFIM", parent = CovariateModelEquation,
                     properties = list(
                       beta = new_property(class_double, default = 0),
                       combinedEffect = new_property(class_double, default = 0),
                       value = new_property(class_double, default = 0)
                     ),
                     constructor = function(beta = 0.0,
                                            combinedEffect = 0.0,
                                            value = 0.0) {
                       # value slot stores mu * (1 + combinedEffect) for each parameter.
                       new_object(.parent = CovariateModelEquation,
                                  beta = beta,
                                  combinedEffect = combinedEffect,
                                  value = beta * ( 1 + combinedEffect ) )
                     })

#' Apply the additive covariate link to typical values.
#'
#' Builds a new \code{Additive} whose \code{value} is
#' \code{beta * (1 + combinedEffect)} (elementwise over parameters).
#' @param equation First argument of generic.
#' @param beta Named numeric vector of baseline parameter values (mu).
#' @param combinedEffect Named numeric vector of summed covariate effects.
#' @return \code{Additive} object containing transformed parameter values.
#' @name computeCovariateValue
#' @keywords internal
method(computeCovariateValue, Additive) = function(equation, beta, combinedEffect) {
  Additive(beta = beta, combinedEffect = combinedEffect)
}
