#' FIM type and optimizer registries.
#'
#' Package-private environments map string names to factory functions:
#' \itemize{
#'   \item \code{.pfimFimTypeRegistry} — \code{"population"}, \code{"individual"},
#'     \code{"bayesian"} (and any type registered with \code{pfim_register_fim_type})
#'   \item \code{.pfimFimDuplicatorRegistry} — how to clone a FIM while clearing
#'     computed slots (SE, matrices, …) for design-level copies
#'   \item \code{.pfimOptimizerRegistry} — S7 optimizer constructors used by
#'     \code{\link{Optimization}} / \code{run()}
#' }
#' Built-ins are registered at load time via \code{.pfimInitBuiltinRegistries()}.
#' @name pfim-registry
#' @include PopulationFim.R
#' @include IndividualFim.R
#' @include BayesianFim.R
#' @include MultiplicativeAlgorithm.R
#' @include FedorovWynnAlgorithm.R
#' @include PSOAlgorithm.R
#' @include PGBOAlgorithm.R
#' @include SimplexAlgorithm.R
#' @keywords internal
NULL

.pfimFimTypeRegistry = new.env( parent = emptyenv() )
.pfimFimDuplicatorRegistry = new.env( parent = emptyenv() )
.pfimOptimizerRegistry = new.env( parent = emptyenv() )

#' Clone a FIM and clear all computed numerical slots.
#'
#' Used as the default \code{duplicator} when registering a FIM type so that
#' design-level copies start empty (no leftover Fisher matrix / SE / shrinkage).
#' @param fim A \code{Fim} S7 object.
#' @return A deep clone with numeric result slots reset.
#' @noRd
#' @keywords internal
.fimDuplicateReset = function( fim ) {
  .pfimCloneS7( fim, reset = list(
    fisherMatrix              = numeric( 0 ),
    fixedEffects              = numeric( 0 ),
    varianceEffects           = numeric( 0 ),
    SEAndRSE                  = list(),
    condNumberFixedEffects    = 0.0,
    condNumberVarianceEffects = 0.0,
    shrinkage                 = numeric( 0 )
  ) )
}

#' Register a custom FIM type
#'
#' Extends PFIM with a new \code{fimType} string for \code{\link{Evaluation}} /
#' \code{\link{Optimization}}. The factory is called whenever a project needs a
#' fresh FIM of that type. Overwrites silently if \code{name} already exists.
#'
#' @param name Character label (e.g. \code{"population"}).
#' @param factory Zero-argument function returning a \code{Fim} object.
#' @param duplicator Optional \code{function(fim)} for design-level FIM copies;
#'   defaults to \code{.fimDuplicateReset}.
#' @return Invisibly, \code{NULL}.
#' @export
pfim_register_fim_type = function( name, factory, duplicator = .fimDuplicateReset ) {
  if ( length( name ) != 1L || !is.character( name ) || !nzchar( name ) )
    stop( "name must be a non-empty character string.", call. = FALSE )
  if ( !is.function( factory ) )
    stop( "factory must be a function.", call. = FALSE )
  if ( !is.function( duplicator ) )
    stop( "duplicator must be a function.", call. = FALSE )
  key = tolower( name )
  assign( key, factory, envir = .pfimFimTypeRegistry )
  sample = factory()
  cls    = S7::S7_class( sample )@name
  assign( cls, duplicator, envir = .pfimFimDuplicatorRegistry )
  invisible( NULL )
}

#' Register a custom optimizer
#'
#' Makes \code{optimizer = name} valid on \code{\link{Optimization}}. The factory
#' must return an S7 optimizer object with an \code{optimizeDesign} method.
#' Overwrites silently if \code{name} already exists.
#'
#' @param name Character optimizer name (e.g. \code{"PSOAlgorithm"}).
#' @param factory Zero-argument function returning an optimizer object.
#' @return Invisibly, \code{NULL}.
#' @export
pfim_register_optimizer = function( name, factory ) {
  if ( length( name ) != 1L || !is.character( name ) || !nzchar( name ) )
    stop( "name must be a non-empty character string.", call. = FALSE )
  if ( !is.function( factory ) )
    stop( "factory must be a function.", call. = FALSE )
  assign( name, factory, envir = .pfimOptimizerRegistry )
  invisible( NULL )
}

#' Instantiate a FIM from a registered \code{fimType} string.
#' @param fimType Character; compared case-insensitively to registry keys.
#' @return A new \code{Fim} S7 object.
#' @noRd
#' @keywords internal
.pfimInstantiateFimType = function( fimType ) {
  key = tolower( fimType )
  if ( !exists( key, envir = .pfimFimTypeRegistry, inherits = FALSE ) )
    stop(
      sprintf(
        "Invalid fimType '%s' (population, individual, Bayesian, or pfim_register_fim_type).",
        fimType
      ),
      call. = FALSE
    )
  get( key, envir = .pfimFimTypeRegistry )()
}

#' Instantiate an optimizer from a registered name.
#' @param name Exact registry key (e.g. \code{"MultiplicativeAlgorithm"}).
#' @return A new optimizer S7 object.
#' @noRd
#' @keywords internal
.pfimInstantiateOptimizer = function( name ) {
  if ( !exists( name, envir = .pfimOptimizerRegistry, inherits = FALSE ) )
    stop(
      sprintf(
        "Unknown optimizer '%s' (pfim_register_optimizer).",
        name
      ),
      call. = FALSE
    )
  get( name, envir = .pfimOptimizerRegistry )()
}

#' Required / optional \code{optimizerParameters} per built-in algorithm.
#'
#' Used by \code{.pfimCheckOptimizerParameters} at \code{Optimization()} construction.
#' Custom optimizers registered via \code{pfim_register_optimizer} are not listed
#' here and skip this validation.
#' @return Named list of \code{list(required=, optional=)} specs.
#' @noRd
#' @keywords internal
.pfimOptimizerParamSpecs = function() {
  list(
    MultiplicativeAlgorithm = list(
      required = c( "lambda", "delta", "numberOfIterations", "weightThreshold" ),
      optional = "showProcess"
    ),
    FedorovWynnAlgorithm = list(
      required = c( "elementaryProtocols", "numberOfSubjects", "proportionsOfSubjects" ),
      optional = "showProcess"
    ),
    PSOAlgorithm = list(
      required = c(
        "maxIteration", "populationSize", "seed",
        "personalLearningCoefficient", "globalLearningCoefficient"
      ),
      optional = c( "showProcess", "tolerance", "stallIterations" )
    ),
    PGBOAlgorithm = list(
      required = c( "maxIteration", "N", "muteEffect", "purgeIteration", "seed" ),
      optional = c( "showProcess", "fitBase", "cauchyProb", "tolerance", "stallIterations" )
    ),
    SimplexAlgorithm = list(
      required = c( "pctInitialSimplexBuilding", "tolerance", "maxIteration" ),
      optional = "showProcess"
    )
  )
}

#' Validate \code{optimizerParameters} against the built-in spec for \code{optimizer}.
#'
#' Checks unknown names (with fuzzy \code{agrep} suggestions) and missing required
#' keys. Returns \code{params} unchanged for empty optimizer or custom names.
#' @param optimizer Character optimizer class name.
#' @param params Named list (may be \code{NULL}).
#' @return The validated \code{params} list (invisibly).
#' @noRd
#' @keywords internal
.pfimCheckOptimizerParameters = function( optimizer, params ) {
  if ( !length( optimizer ) || !nzchar( optimizer[[ 1L ]] ) )
    return( invisible( params ) )
  spec = .pfimOptimizerParamSpecs()[[ optimizer ]]
  if ( is.null( spec ) )
    return( invisible( params ) )

  params  = params %||% list()
  allowed = c( spec$required, spec$optional )
  unknown = setdiff( names( params ), allowed )
  if ( length( unknown ) ) {
    parts = vapply( unknown, function( nm ) {
      hit = agrep( nm, allowed, ignore.case = TRUE, max.distance = 0.2, value = TRUE )
      paste0( "'", nm, "'", if ( length( hit ) ) paste0( " (did you mean '", hit[[ 1L ]], "'?)" ) else "" )
    }, character( 1L ) )
    stop(
      "Unknown optimizerParameters for ", optimizer, ": ",
      paste( parts, collapse = ", " ),
      ". Use Optimization(..., optimizerParameters = list(...)).",
      call. = FALSE
    )
  }

  missing = setdiff( spec$required, names( params ) )
  if ( length( missing ) ) {
    stop(
      "Missing optimizerParameters for ", optimizer, ": ",
      paste( missing, collapse = ", " ),
      ". See ?Optimization.",
      call. = FALSE
    )
  }

  invisible( params )
}

#' Register built-in FIM types and optimizers (called once at package load).
#' @noRd
#' @keywords internal
.pfimInitBuiltinRegistries = function() {
  pfim_register_fim_type( "population", function() PopulationFim() )
  pfim_register_fim_type( "individual", function() IndividualFim() )
  pfim_register_fim_type( "bayesian", function() BayesianFim() )
  pfim_register_optimizer( "MultiplicativeAlgorithm", function() MultiplicativeAlgorithm() )
  pfim_register_optimizer( "FedorovWynnAlgorithm", function() FedorovWynnAlgorithm() )
  pfim_register_optimizer( "PSOAlgorithm", function() PSOAlgorithm() )
  pfim_register_optimizer( "PGBOAlgorithm", function() PGBOAlgorithm() )
  pfim_register_optimizer( "SimplexAlgorithm", function() SimplexAlgorithm() )
}

.pfimInitBuiltinRegistries()
