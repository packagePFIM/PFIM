# Observation variance and sigma derivatives for the population FIM lambda block.

#' Error variance and sigma derivatives at one evaluation point (no covariates).
#' @param model A \code{Model} object.
#' @param evaluationModel Named list of output \code{data.frame}s (time + response columns).
#' @return List with \code{errorVariance} (block-diagonal matrix) and
#'   \code{sigmaDerivatives} (list of sparse derivative matrices per sigma parameter).
#' @keywords internal
evaluateModelVarianceCore = function( model, evaluationModel ) {

  modelErrors = prop( model, "modelError"  )
  outputNames = prop( model, "outputNames" )

  # Per-output residual variance and ∂R/∂σ from the error model.
  errorDerivativesList = map( modelErrors, function( err ) {
    outcome = prop( err, "output" )
    if ( outcome %in% outputNames )
      evaluateErrorModelDerivatives( err, evaluationModel[[ outcome ]][ , outcome ] )
    else NULL
  }) |> compact() |> set_names( outputNames )

  # Block-diagonal R over outputs (observation order = outputNames × times).
  errorVariance  = map( errorDerivativesList, ~ bdiag( .x$errorVariance ) ) |> bdiag()
  totalSamplings = map_int( evaluationModel, ~ length( .x[["time"]] ) ) |> sum()

  # Starting index of each output block in the stacked observation vector.
  samplingOffsets = accumulate(
    outputNames,
    function( offset, outName ) offset + length( evaluationModel[[ outName ]][["time"]] ),
    .init = 0L
  ) |> head( -1L ) |> set_names( outputNames )

  # Embed each output's sigma derivative into the full observation × observation matrix.
  sigmaDerivatives = outputNames |>
    map( function( outName ) {
      n   = length( evaluationModel[[ outName ]][["time"]] )
      rng = ( samplingOffsets[[ outName ]] + 1L ):( samplingOffsets[[ outName ]] + n )

      map( errorDerivativesList[[ outName ]]$sigmaDerivatives, function( derivComp ) {
        mat             = matrix( 0, nrow = totalSamplings, ncol = totalSamplings )
        mat[ rng, rng ] = derivComp
        mat
      })
    }) |> list_flatten()

  list( errorVariance = errorVariance, sigmaDerivatives = sigmaDerivatives )
}

#' Default \code{Model} method: variance at nominal point or per covariate occasion.
#' @return Variance list (simple path) or nested list by combination and occasion.
#' @name evaluateModelVariance
#' @keywords internal
method( evaluateModelVariance, Model ) = function( model, arm ) {
  evaluationModel = prop( arm, "evaluationModel" )
  if ( !usesCovariateOccasionStructure( model ) ) {
    evaluateModelVarianceCore( model, evaluationModel )
  } else {
    evaluateModelVarianceWithCovariates( model, evaluationModel )
  }
}

#' Error variance and sigma derivatives for every covariate combination and occasion.
#' @param model A \code{Model} object.
#' @param evaluationModelWithCovariates Nested structure from covariate-occasion evaluation.
#' @return List keyed by combination, each with \code{proportion} and per-occasion variance lists.
#' @keywords internal
evaluateModelVarianceWithCovariates = function( model, evaluationModelWithCovariates ) {
  map( evaluationModelWithCovariates, function( combinationData ) {
    list(
      combination = combinationData$combination,
      proportion  = combinationData$proportion,
      variances   = map( combinationData$evaluations, function( occasionData ) {
        list(
          occasion = occasionData$occasion,
          variance = evaluateModelVarianceCore( model, occasionData$evaluation )
        )
      })
    )
  })
}
