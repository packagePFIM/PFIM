# FD / ODE gradient performance caches (session options under perf.*).
#
# Speeds repeated gradient evaluations during continuous optimization:
#   - `.pfimFdSchemeCache`  — finite-difference stencil for a mu signature
#   - `.pfimGradAdminCache` — ODE administration wrappers (dose/sampling layout)
#   - C++ ODE sim-time grid cache (ode-cache.cpp) via `pfimOdeSimTimesCached_Rcpp`
#
# Keys are hashed when long (Windows env name limit). Clear with
# `.pfimClearGradientPerfCaches()` / `pfim_reset_session()`.

.pfimFdSchemeCache  = new.env( parent = emptyenv() )
.pfimGradAdminCache = new.env( parent = emptyenv() )

#' Read a boolean performance option (default FALSE unless overridden).
#' @noRd
#' @keywords internal
.pfimPerfOption = function( name, default = FALSE ) {
  isTRUE( pfim_get_option( name, default ) )
}

# Hash long cache keys (Windows env name limit ~255 chars for bindings).
#' @noRd
#' @keywords internal
.pfimEnvCacheKey = function( x ) {
  pfimEnvCacheKey_Rcpp( as.character( x ) )
}

#' Compact signature of parameter names, mu values, and fixed-mu flags.
#' @noRd
#' @keywords internal
.pfimMuSignature = function( parameters ) {
  paste(
    map_chr( parameters, ~ prop( .x, "name" ) ),
    format(
      map_dbl( parameters, ~ prop( prop( .x, "distribution" ), "mu" ) ),
      digits = 12, scientific = TRUE
    ),
    map_lgl( parameters, .paramMuFixed ),
    sep = "=",
    collapse = "|"
  )
}

# Expand free-parameter FD shifts back to full-length parameter columns.
# Indices of mu parameters included in the FD grid (matches PopulationFim isFixedMu).
#' @noRd
#' @keywords internal
.pfimFdShiftedFull = function( pars, freeIdx, shiftedFree ) {
  nFull = length( pars )
  shifted = vapply(
    seq_len( ncol( shiftedFree ) ),
    function( j ) {
      full = pars
      full[ freeIdx ] = shiftedFree[ , j ]
      full
    },
    numeric( nFull )
  )
  dim( shifted ) = c( nFull, ncol( shiftedFree ) )
  shifted
}

#' Indices of estimable (non-fixed) mu parameters for the FD grid.
#' @noRd
#' @keywords internal
.pfimFdFreeIndices = function( parameters ) {
  which( map_lgl( parameters, .paramMuEstimable ) )
}

# Quadratic FD stencil on free parameters; full-length shifted columns for evaluateModel().
# Linear-only mode (perf.fdLinearOnly) drops cross terms and returns incr for central differences.
#' @param pars Numeric vector of all parameter mus.
#' @param freeIdx Integer indices of estimable mus.
#' @param odeSolverParameters Optional list with \code{atol}/\code{rtol}; used to
#'   keep the FD step larger than ODE truncation error when \code{scaleToOdeTol}.
#' @param scaleToOdeTol Logical; if \code{TRUE}, enlarge FD step from ODE tolerances.
#' @noRd
#' @keywords internal
.pfimFiniteDifferenceGrid = function( pars, freeIdx,
                                      odeSolverParameters = NULL,
                                      scaleToOdeTol = FALSE ) {
  nFull = length( pars )
  nFree = length( freeIdx )

  if ( nFree == 0L ) {
    return( list(
      shifted  = matrix( pars, ncol = 1L ),
      XcolsInv = matrix( 1, 1, 1 ),
      frac     = 1,
      freeIdx  = freeIdx
    ) )
  }

  parsFree = pars[ freeIdx ]
  relStep = .Machine$double.eps^( 1 / 3 )
  # For ODE models, enlarge the step so truncation error does not dominate FD noise.
  if ( isTRUE( scaleToOdeTol ) ) {
    odeTol = {
      tols = .pfimDeSolveTolerances( odeSolverParameters )
      min( as.numeric( tols$atol ), as.numeric( tols$rtol ) )
    }
    if ( !is.finite( odeTol ) || odeTol <= 0 )
      odeTol = 1e-8
    relStep = max( relStep, odeTol^( 1 / 3 ) )
    incr = pmax( abs( parsFree ), 1e-4 ) * relStep
    if ( any( incr < 10 * odeTol ) )
      warning(
        "Finite-difference step is close to ODE solver tolerance; ",
        "gradients (and the FIM) may be inaccurate. ",
        "Tighten odeSolverParameters atol/rtol or expect larger FD steps.",
        call. = FALSE
      )
  } else {
    incr = pmax( abs( parsFree ), 1e-4 ) * relStep
  }
  baseInd     = diag( nFree )
  linearOnly  = .pfimPerfOption( "perf.fdLinearOnly", FALSE )

  if ( linearOnly ) {
    # Columns: baseline, +e_i, -e_i (no quadratic / cross terms).
    indMat      = cbind( 0, baseInd, -baseInd )
    shiftedFree = parsFree + incr * indMat
    return( list(
      shifted    = .pfimFdShiftedFull( pars, freeIdx, shiftedFree ),
      XcolsInv   = NULL,
      linearOnly = TRUE,
      incr       = incr,
      frac       = c( 1, incr, incr ),
      freeIdx    = freeIdx
    ) )
  }

  # Extra columns for pairwise products (quadratic response-surface stencil).
  extraCols   = if ( nFree > 1L )
    map( seq_len( nFree - 1L ), ~ baseInd[ , .x ] + baseInd[ , -seq_len( .x ) ] )
  else list()
  extraFrac   = if ( nFree > 1L )
    map( seq_len( nFree - 1L ), ~ incr[ .x ] * incr[ -seq_len( .x ) ] )
  else list()
  cols        = c( list( 0, baseInd, -baseInd ), extraCols )
  frac        = c( 1, incr, incr^2, unlist( extraFrac ) )
  indMat      = do.call( cbind, cols )
  shiftedFree = parsFree + incr * indMat

  # Design matrix for the polynomial fit; invert once and reuse.
  indMatT = t( indMat )
  Xcols   = c(
    list( 1, indMatT, indMatT^2 ),
    if ( nFree > 1L )
      map( seq_len( nFree - 1L ), ~ indMatT[ , .x ] * indMatT[ , -seq_len( .x ) ] )
    else list()
  )

  list(
    shifted  = .pfimFdShiftedFull( pars, freeIdx, shiftedFree ),
    XcolsInv = .safeSolve( do.call( cbind, Xcols ) ),
    frac     = frac,
    freeIdx  = freeIdx
  )
}

# Signature of doses, sampling times, and initial-condition expressions for an arm.
#' @noRd
#' @keywords internal
.pfimArmAdminSignature = function( arm ) {
  adms = prop( arm, "administrations" )
  sts  = prop( arm, "samplingTimes" )
  ic   = prop( arm, "initialConditions" )

  dose_sig = vapply( adms, function( adm ) {
    dosing = .alignAdministrationDosing( adm )
    paste(
      prop( adm, "outcome" ),
      paste( dosing$timeDose, collapse = "," ),
      paste( dosing$dose, collapse = "," ),
      paste( dosing$Tinf, collapse = "," ),
      prop( adm, "tau" ),
      sep = ":"
    )
  }, character( 1L ) )

  samp_sig = vapply( sts, function( st ) {
    paste( prop( st, "outcome" ), paste( prop( st, "samplings" ), collapse = "," ), sep = ":" )
  }, character( 1L ) )

  ic_sig = if ( length( ic ) )
    paste( names( ic ), vapply( ic, as.character, character( 1L ) ), sep = "=", collapse = ";" )
  else ""

  paste( paste( dose_sig, collapse = ";" ), paste( samp_sig, collapse = ";" ), ic_sig, sep = "||" )
}

#' Cache key for ODE admin layout (model class + param names + arm admin signature).
#' @noRd
#' @keywords internal
.pfimGradAdminCacheKey = function( model, arm ) {
  cls = class( model )[[ 1L ]]
  param_names = paste( map_chr( prop( model, "modelParameters" ), ~ prop( .x, "name" ) ), collapse = "," )
  .pfimEnvCacheKey( paste( cls, param_names, .pfimArmAdminSignature( arm ), sep = "::" ) )
}

#' Clone parameters and overwrite each mu with the corresponding shifted value.
#' @noRd
#' @keywords internal
.pfimShiftModelParameters = function( parameters, shiftedCol ) {
  map2( parameters, shiftedCol, function( param, newMu ) {
    param = .pfimCloneS7( param )
    distr = prop( param, "distribution" )
    prop( distr, "mu" ) = newMu
    prop( param, "distribution" ) = distr
    param
  } )
}

#' Attach FD Hessian scheme, reusing a cached stencil when mu signature matches.
#' @noRd
#' @keywords internal
.pfimFiniteDifferenceHessianCached = function( model ) {
  if ( !.pfimPerfOption( "perf.fdCache", TRUE ) )
    return( finiteDifferenceHessian( model ) )

  key = .pfimEnvCacheKey( .pfimMuSignature( prop( model, "modelParameters" ) ) )
  cached = .pfimFdSchemeCache[[ key ]]
  if ( !is.null( cached ) ) {
    prop( model, "parametersForComputingGradient" ) = .pfimCloneCached( cached )
    return( model )
  }

  model = finiteDifferenceHessian( model )
  .pfimCacheStore(
    .pfimFdSchemeCache, key,
    .pfimCloneCached( prop( model, "parametersForComputingGradient" ) )
  )
  model
}

#' TRUE for model classes that benefit from administration caching.
#' @noRd
#' @keywords internal
.pfimUsesAdminCache = function( model ) {
  S7::S7_inherits( model, ModelODE ) ||
    S7::S7_inherits( model, ModelODEInfusionDoseInEquation )
}

#' Build a hash key for the C++ ODE sim-time cache from mode, samples, and events.
#' @noRd
#' @keywords internal
.pfimOdeSimCacheKey = function( mode, raw_samplings, events_df ) {
  parts = c( mode, paste( raw_samplings, collapse = "," ) )
  if ( !is.null( events_df ) )
    parts = c( parts, paste( events_df$time, events_df$value, sep = ":", collapse = "," ) )
  pfimCacheHash_Rcpp( parts )
}

#' Cached unique sorted ODE simulation times (samples ∪ event times).
#' @noRd
#' @keywords internal
.pfimOdeSimTimesCached = function( cacheKey, raw_samplings, events_df ) {
  event_times = if ( !is.null( events_df ) ) events_df$time else NULL
  max_entries = pfim_get_option( "perf.odeTimesCache.maxEntries", 2048L )
  if ( is.null( max_entries ) || !is.finite( max_entries ) )
    max_entries = -1L
  pfimOdeSimTimesCached_Rcpp(
    cacheKey,
    raw_samplings,
    event_times,
    enabled = .pfimPerfOption( "perf.odeTimesCache", TRUE ),
    max_entries = as.integer( max_entries )
  )
}

# First call builds administration; later calls refresh mu/dose only from the cached entry.
#' @noRd
#' @keywords internal
.pfimDefineModelAdministrationCached = function( model, arm ) {
  if ( !.pfimPerfOption( "perf.adminCache", TRUE ) || !.pfimUsesAdminCache( model ) )
    return( defineModelAdministration( model, arm ) )

  key   = .pfimGradAdminCacheKey( model, arm )
  entry = .pfimGradAdminCache[[ key ]]

  if ( is.null( entry ) ) {
    # Miss: build full administration and store a reusable entry.
    if ( S7::S7_inherits( model, ModelODEInfusionDoseInEquation ) ) {
      parts = .odeInfusionAdminParts( model, arm )
      .pfimCacheStore( .pfimGradAdminCache, key, .pfimInfusionAdminEntryFromParts( parts ) )
      return( .odeInfusionApplyParts( model, parts ) )
    }
    model = defineModelAdministration( model, arm )
    .pfimCacheStore( .pfimGradAdminCache, key, .pfimCaptureOdeAdminEntry( model, arm ) )
    return( model )
  }

  # Hit: reapply cached wrapper / dose tables with current mu values.
  .pfimRefreshOdeAdministration( model, arm, entry )
}

# Parsed wrapper / RHS / dose tables — enough to rebuild after a mu shift.
#' @noRd
#' @keywords internal
.pfimCaptureOdeAdminEntry = function( model, arm ) {
  if ( !S7::S7_inherits( model, ModelODE ) ) return( list( type = "full" ) )
  mode = tryCatch( .odeBolusMode( model ), error = function( e ) "full" )
  if ( identical( mode, "full" ) ) return( list( type = "full" ) )

  entry = list(
    type                       = mode,
    samplings                  = prop( model, "samplings" ),
    wrapper                    = prop( model, "wrapper" ),
    functionArguments          = prop( model, "functionArguments" ),
    functionArgumentsSymbols   = prop( model, "functionArgumentsSymbol" ),
    outputFormula              = .getOutputFormulaParsed( model )
  )
  if ( mode == "doseInEq" ) {
    entry$solverInputs               = prop( model, "solverInputs" )
    entry$outcomesWithAdministration = prop( model, "outcomesWithAdministration" )
  } else {
    entry$doseEventTemplate = .odeDoseEventFromArm( arm, prop( model, "samplings" ) )
    if ( mode == "bolusIc" )
      entry$initialConditionsParsed = .parseInitialConditionExprs( prop( arm, "initialConditions" ) )
  }
  entry
}

#' Reapply a cached admin entry (or fall back to a full defineModelAdministration).
#' @noRd
#' @keywords internal
.pfimRefreshOdeAdministration = function( model, arm, entry ) {
  if ( entry$type == "full" )
    defineModelAdministration( model, arm )
  else if ( entry$type == "infusionDoseInEq" )
    .odeInfusionApplyAdminEntry( model, arm, entry )
  else
    .odeApplyAdminEntry( model, arm, entry )
}

#' Bind arm administration to a model (uses admin cache when enabled).
#' @noRd
#' @keywords internal
.pfimPrepareModelForEvaluation = function( model, arm ) {
  .pfimDefineModelAdministrationCached( model, arm )
}

#' Clear all R and C++ gradient / ODE performance caches.
#' @noRd
#' @keywords internal
.pfimClearGradientPerfCaches = function() {
  .pfimEnvClear( .pfimFdSchemeCache )
  .pfimEnvClear( .pfimGradAdminCache )
  pfimOdeSimTimesCacheClear_Rcpp()
  .pfimEnvClear( .pfimOutputFormulaCache )
  .pfimEnvClear( .pfimParsedOutputFormulaCache )
  invisible( NULL )
}
