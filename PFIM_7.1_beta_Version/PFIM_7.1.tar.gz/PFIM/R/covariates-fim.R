#' Detect nested covariate×occasion arm evaluations (gradients or variances).
#' @param x \code{evaluationGradients} or \code{evaluationVariance} from an arm.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.isNestedArmEvaluation = function( x ) {
  length( x ) > 0L && is.list( x[[1L]] ) &&
    ( !is.null( x[[1L]]$gradients ) || !is.null( x[[1L]]$variances ) )
}

#' Detect nested \code{evaluateModel()} output (covariate × occasion combinations).
#' @param x Arm \code{evaluationModel} structure.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.isNestedEvaluationModel = function( x ) {
  length( x ) > 0L && is.list( x[[1L]] ) && !is.null( x[[1L]]$evaluations )
}

#' Proportion-weighted mean model curves for report plots.
#'
#' Averages over occasions within each combination, then weights by combination
#' proportion so plotted curves match the mixture used in the population FIM.
#' @param nested_eval Nested evaluation structure from covariate×occasion path.
#' @return Named list of \code{data.frame}s (\code{time}, output) per outcome.
#' @noRd
#' @keywords internal
.aggregateEvaluationModelForPlot = function( nested_eval ) {
  outputNames = names( nested_eval[[1L]]$evaluations[[1L]]$evaluation )
  map( outputNames, function( out_name ) {
    acc = NULL
    for ( combo in nested_eval ) {
      # Equal weight across occasions within a combination.
      w_occ = combo$proportion / length( combo$evaluations )
      for ( occ in combo$evaluations ) {
        df = occ$evaluation[[ out_name ]]
        y  = df[[ out_name ]]
        if ( is.null( acc ) ) {
          acc = list( time = df$time, y = w_occ * y )
        } else {
          idx = match( acc$time, df$time )
          acc$y = acc$y + w_occ * y[ idx ]
        }
      }
    }
    out = data.frame( time = acc$time )
    out[[ out_name ]] = acc$y
    out
  } ) |> set_names( outputNames )
}

#' Build a dictionary of non-zero covariate beta effect sizes.
#'
#' Keys follow \code{beta_<param>_<covariate>_<category>} (reference category skipped).
#' @param modelCovariates List of covariate objects.
#' @return Named numeric vector of beta values.
#' @noRd
#' @keywords internal
.betaDictFromCovariates = function( modelCovariates ) {
  if ( length( modelCovariates ) == 0L )
    return( set_names( numeric( 0L ), character( 0L ) ) )
  lst = modelCovariates |>
    map( function( cov ) {
      covName    = prop( cov, "name" )
      categories = prop( cov, "categories" )
      effects    = prop( cov, "effects" )
      ( seq_len( length( categories ) - 1L ) + 1L ) |>
        map( function( icat ) {
          cat = categories[[ icat ]]
          if ( !cat %in% names( effects ) ) return( list() )
          eff = effects[[ cat ]]
          names( eff )[ eff != 0 ] |>
            map( ~ list(
              key = paste0( "beta_", .x, "_", covName, "_", cat ),
              val = as.numeric( eff[[ .x ]] )
            ) )
        }) |> list_flatten()
    }) |> list_flatten()
  if ( length( lst ) == 0L )
    return( set_names( numeric( 0L ), character( 0L ) ) )
  set_names( map_dbl( lst, "val" ), map_chr( lst, "key" ) )
}

#' Map internal beta names to numeric values from covariate definitions.
#'
#' @param modelCovariates List of covariate objects.
#' @param betaInternal Character vector of \code{beta_*} names
#' @return Numeric vector aligned with \code{betaInternal}.
#' @noRd
#' @keywords internal
.betaValuesFromCovariates = function( modelCovariates, betaInternal ) {
  if ( length( betaInternal ) == 0L ) return( numeric( 0L ) )
  dict = .betaDictFromCovariates( modelCovariates )
  vals = map_dbl( betaInternal, ~ dict[[ .x ]] )
  vals
}

#' Collapse nested combination-by-occasion gradients to one matrix (all outputs stacked).
#'
#' @param model A \code{Model} object.
#' @param arm An \code{Arm} object with nested \code{evaluationGradients}.
#' @return Numeric matrix (stacked outputs x parameters).
#' @keywords internal
aggregateGradientsWithCovariates = function( model, arm ) {

  allGradientsData = prop( arm, "evaluationGradients" )
  outputNames      = prop( model, "outputNames" )

  if ( length( outputNames ) == 0L && length( allGradientsData ) > 0L ) {
    outputNames = names( allGradientsData[[1L]]$gradients[[1L]]$gradient )
  }

  gradDfs = map( outputNames, function( outName ) {
    zeroGrad = allGradientsData[[1L]]$gradients[[1L]]$gradient[[ outName ]] * 0

    matList = map( allGradientsData, function( combinationData ) {
      nOcc     = length( combinationData$gradients )
      meanGrad = reduce( map( combinationData$gradients, ~ .x$gradient[[ outName ]] ), `+` ) / nOcc
      combinationData$proportion * meanGrad
    })

    reduce( matList, `+`, .init = zeroGrad )
  })

  mat = list_rbind( gradDfs ) |> as.matrix()
  if ( !is.null( gradDfs[[1L]] ) && ncol( gradDfs[[1L]] ) > 0L )
    colnames( mat ) = colnames( gradDfs[[1L]] )
  mat
}

#' Expectation of the residual variance structure over covariate combinations and occasions.
#'
#' @param arm An \code{Arm} object with nested \code{evaluationVariance}.
#' @return List with \code{errorVariance} and \code{sigmaDerivatives}.
#' @keywords internal
aggregateVarianceWithCovariates = function( arm ) {

  varianceResults = prop( arm, "evaluationVariance" )

  meanOccasionVariance = function( occVars ) {
    n = length( occVars )
    err = Reduce( `+`, map( occVars, ~ as.matrix( .x$variance$errorVariance ) ) ) / n
    sig = occVars[[1L]]$variance$sigmaDerivatives
    if ( n > 1L ) {
      sig = map( seq_along( sig ), function( k ) {
        Reduce( `+`, map( occVars, ~ .x$variance$sigmaDerivatives[[ k ]] ) ) / n
      })
    }
    list( errorVariance = err, sigmaDerivatives = sig )
  }

  out = NULL
  for ( combo in varianceResults ) {
    p = combo$proportion
    v = meanOccasionVariance( combo$variances )
    if ( is.null( out ) ) {
      out = list(
        errorVariance      = p * v$errorVariance,
        sigmaDerivatives   = map( v$sigmaDerivatives, ~ p * .x )
      )
    } else {
      out$errorVariance    = out$errorVariance + p * v$errorVariance
      out$sigmaDerivatives = map2( out$sigmaDerivatives, v$sigmaDerivatives, `+` )
    }
  }
  out
}

#' Flat gradient matrix for Individual/Bayesian FIM (aggregates nested evaluations when needed).
#'
#' @param model A \code{Model} object.
#' @param arm An \code{Arm} object.
#' @return Numeric matrix (observation rows x parameter columns).
#' @keywords internal
getArmEvaluationGradientsMatrix = function( model, arm, pfimproject = NULL, evalModel = NULL ) {
  if ( !is.null( evalModel ) ) {
    model = evalModel
  } else if ( !is.null( pfimproject ) ) {
    model = rebuildEvalModel( pfimproject, finiteDifference = FALSE )
  }
  raw = prop( arm, "evaluationGradients" )
  if ( .isNestedArmEvaluation( raw ) ) {
    aggregateGradientsWithCovariates( model, arm )
  } else if ( is.data.frame( raw ) ) {
    as.matrix( raw )
  } else {
    do.call( rbind, raw ) |> as.matrix()
  }
}

#' Flat residual variance for Individual/Bayesian FIM.
#'
#' @param arm An \code{Arm} object.
#' @return List with \code{errorVariance} and \code{sigmaDerivatives}.
#' @keywords internal
getArmEvaluationVarianceFlat = function( arm ) {
  raw = prop( arm, "evaluationVariance" )
  if ( .isNestedArmEvaluation( raw ) ) aggregateVarianceWithCovariates( arm ) else raw
}

#' Internal beta column names (beta_param_covariate_category) from covariate definitions.
#'
#' @param modelCovariates List of covariate objects.
#' @return Character vector.
#' @noRd
#' @keywords internal
.betaInternalNamesFromCovariates = function( modelCovariates ) {
  if ( length( modelCovariates ) == 0L ) return( character( 0L ) )
  extractNames = function( covList ) {
    if ( length( covList ) == 0L ) return( character( 0L ) )
    covList |>
      map( function( cov ) {
        covName    = prop( cov, "name" )
        categories = prop( cov, "categories" )
        effects    = prop( cov, "effects" )
        ( seq_len( length( categories ) - 1L ) + 1L ) |>
          map( function( icat ) {
            cat = categories[[ icat ]]
            if ( !cat %in% names( effects ) ) return( character( 0L ) )
            paste0(
              "beta_", names( effects[[ cat ]] )[ effects[[ cat ]] != 0 ],
              "_", covName, "_", cat
            )
          }) |> unlist( use.names = FALSE )
      }) |> unlist( use.names = FALSE )
  }
  byClass = .splitCovariatesByClass( modelCovariates )
  unique( c(
    extractNames( pluck( byClass, "CategoricalCovariate",        .default = list() ) ),
    extractNames( pluck( byClass, "CategoricalCovariateWithIOV", .default = list() ) )
  ) )
}

#' Drop fixed-\eqn{\mu} columns from a fixed-effects name vector.
#'
#' Gradient matrices may still carry zero columns for \code{fixedMu} parameters;
#' Population already removes them when building \code{MFbeta}. Individual /
#' Bayesian must use the same estimable-only set so the FE block stays
#' non-singular.
#'
#' @param cn Character vector (\code{mu_*}, \code{beta_*}, or bare mu names).
#' @param parameters List of \code{ModelParameter} objects.
#' @return \code{cn} without non-estimable \eqn{\mu} entries (\eqn{\beta} kept).
#' @noRd
#' @keywords internal
.fimDropFixedMuColumns = function( cn, parameters ) {
  if ( !length( cn ) ) return( cn )
  estimable_mu   = .estimableMuNames( parameters, "mu_" )
  estimable_bare = .estimableMuNames( parameters, "" )
  keep = vapply( cn, function( nm ) {
    if ( startsWith( nm, "beta_" ) ) return( TRUE )
    if ( startsWith( nm, "mu_" ) ) return( nm %in% estimable_mu )
    # Bare parameter name (no-covariate Individual / Bayesian path).
    if ( nm %in% estimable_bare ) return( TRUE )
    bare_all = map_chr( parameters, ~ prop( .x, "name" ) )
    if ( nm %in% bare_all ) return( FALSE )
    TRUE
  }, logical( 1L ) )
  cn[ keep ]
}

#' Column names for the fixed-effects block (mu_* and beta_* when covariates/IOV apply).
#'
#' @param model A \code{Model} object.
#' @param arm An \code{Arm} object (required when covariates or IOV are present).
#' @return Character vector of estimable FE columns (subset of
#'   \code{getArmEvaluationGradientsMatrix()} when covariates/IOV apply).
#' @noRd
#' @keywords internal
.fimFixedEffectColumnNames = function( model, arm = NULL, pfimproject = NULL, evalModel = NULL ) {
  if ( !is.null( evalModel ) ) {
    model = evalModel
  } else if ( !is.null( pfimproject ) ) {
    model = rebuildEvalModel( pfimproject, finiteDifference = FALSE )
  }
  parameters = prop( model, "modelParameters" )
  if ( !usesCovariateOccasionStructure( model ) ) {
    .estimableMuNames( parameters )
  } else {
    if ( is.null( arm ) )
      stop( "arm is required to resolve FIM columns with covariates or IOV.", call. = FALSE )
    cn = colnames( getArmEvaluationGradientsMatrix( model, arm, evalModel = model ) )
    if ( is.null( cn ) || !length( cn ) ) {
      cn = c(
        .estimableMuNames( parameters, "mu_" ),
        .betaInternalNamesFromCovariates( prop( model, "modelCovariates" ) )
      )
    }
    .fimDropFixedMuColumns( cn, parameters )
  }
}

#' Fixed-effects labels after \code{run()} (Individual + Bayesian FIM).
#' @noRd
#' @keywords internal
.fimFixedEffectLabels = function( evaluation, greek = .greekConsole ) {

  parameters      = prop( evaluation, "modelParameters" )
  modelCovariates = prop( evaluation, "modelCovariates" )
  has_cov         = length( modelCovariates ) > 0L

  evalDesign = pluck( prop( evaluation, "evaluationDesign" ), 1L )
  evalArm    = pluck( prop( evalDesign, "evaluationArms" ), 1L )
  evalModel  = rebuildEvalModel( evaluation, finiteDifference = FALSE )
  hasComplex = usesCovariateOccasionStructure( evalModel )

  feInternal = if ( hasComplex ) {
    .fimFixedEffectColumnNames( evalModel, evalArm, evalModel = evalModel )
  } else {
    character( 0L )
  }

  # Prefer FE column order from the (already estimable-filtered) gradient layout.
  muBare = if ( hasComplex && length( feInternal ) > 0L ) {
    sub( "^mu_", "", feInternal[ startsWith( feInternal, "mu_" ) ] )
  } else {
    .estimableMuNames( parameters, "" )
  }
  columnNamesMu = paste0( greek[ "mu" ], muBare )

  betaInternal = if ( !has_cov ) {
    character( 0L )
  } else if ( length( feInternal ) > 0L ) {
    feInternal[ startsWith( feInternal, "beta_" ) ]
  } else {
    .betaInternalNamesFromCovariates( modelCovariates )
  }

  columnNamesBeta = if ( length( betaInternal ) > 0L ) {
    paste0( greek[ "beta" ], sub( "^beta_", "", betaInternal ) )
  } else {
    character( 0L )
  }

  paramByName = set_names( parameters, map_chr( parameters, ~ prop( .x, "name" ) ) )
  muValues = if ( length( muBare ) ) {
    map_dbl( muBare, function( nm ) .paramDist( paramByName[[ nm ]], "mu" ) )
  } else {
    numeric( 0L )
  }

  betaValues = if ( length( betaInternal ) > 0L ) {
    .betaValuesFromCovariates( modelCovariates, betaInternal )
  } else {
    numeric( 0L )
  }

  list(
    feInternal      = feInternal,
    columnNamesMu   = columnNamesMu,
    columnNamesBeta = columnNamesBeta,
    betaInternal    = betaInternal,
    muValues        = muValues,
    betaValues      = betaValues,
    has_cov         = has_cov,
    hasComplex      = hasComplex,
    evalModel       = evalModel,
    evalArm         = evalArm
  )
}

#' Display names and values for the residual-variance block (Individual FIM).
#'
#' @param evaluation A \code{Evaluation} object.
#' @param greek Named character vector (default \code{.greekConsole}).
#' @return List with \code{columnNamesSigma} and \code{sigmaValues}.
#' @noRd
#' @keywords internal
.fimSigmaBlockLabels = function( evaluation, greek = .greekConsole ) {
  modelError = prop( evaluation, "modelError" )
  list(
    columnNamesSigma = .sigmaNames( modelError, greek[ "sigma" ] ),
    sigmaValues      = .sigmaValues( modelError )
  )
}

#' Diagonal of a Moore-Penrose covariance from a possibly singular FIM.
#'
#' Used when Cholesky inversion fails (e.g. inactive covariate effect when the
#' global covariate value is 0). Directions with no information get \code{Inf}.
#' @noRd
#' @keywords internal
.fimPinvCovarianceDiagonal = function( M ) {
  M = as.matrix( 0.5 * ( M + t( M ) ) )
  p = nrow( M )
  if ( p == 0L ) return( numeric( 0L ) )
  if ( any( !is.finite( M ) ) ) return( rep( Inf, p ) )

  ev    = eigen( M, symmetric = TRUE )
  vals  = ev$values
  scale = max( abs( vals ), 0 )
  tol   = max( scale * .Machine$double.eps * max( p, 1L ), 1e-14 )
  pos   = vals > tol

  if ( !any( pos ) ) return( rep( Inf, p ) )

  Vpos = ev$vectors[ , pos, drop = FALSE ]
  cov_diag = as.numeric( rowSums( Vpos^2 * rep( 1 / vals[ pos ], each = p ) ) )

  if ( any( !pos ) ) {
    V0 = ev$vectors[ , !pos, drop = FALSE ]
    null_mass = as.numeric( rowSums( V0^2 ) )
    cov_diag[ null_mass > 1e-8 ] = Inf
  }
  # Entire FIM row ≈ 0 => no information for that parameter.
  cov_diag[ rowSums( abs( M ) ) <= tol ] = Inf
  pmax( cov_diag, 0 )
}

#' Build SE / RSE data frames from a labelled FIM matrix.
#'
#' @param M Full Fisher matrix with \code{dimnames} set.
#' @param allNames Row/column names (same order as \code{pVals}).
#' @param pVals Parameter values for RSE denominators.
#' @param abs_denominator If \code{TRUE} (default), RSE uses \code{abs(pVals)}.
#' @return List with \code{SE}, \code{RSE}, \code{table}/\code{SEAndRSE}, and
#'   \code{singular} (logical: Cholesky failed, pseudo-inverse used).
#' @noRd
#' @keywords internal
.fimBuildSeAndRse = function( M, allNames, pVals, abs_denominator = TRUE ) {
  # Singular FIM: keep run()/show() alive via pseudo-inverse SE;
  # non-informative directions (e.g. beta_SEX when SEX = 0) get Inf.
  singular = FALSE
  SE = tryCatch(
    sqrt( pmax( diag( .safeCholInv( M ) ), 0 ) ),
    error = function( e ) {
      singular <<- TRUE
      sqrt( .fimPinvCovarianceDiagonal( M ) )
    }
  )
  if ( singular ) {
    n_inf = sum( !is.finite( SE ) )
    warning(
      "Fisher information matrix is singular or not positive definite; ",
      "SE/RSE used a Moore-Penrose pseudo-inverse",
      if ( n_inf > 0L )
        paste0( " (", n_inf, " non-informative direction(s) have Inf SE)" )
      else
        "",
      ". Interpret SE/RSE and design criteria with caution.",
      call. = FALSE
    )
  }
  den = if ( abs_denominator ) abs( pVals ) else pVals
  RSE = SE / den * 100
  seDF = data.frame( parametersValues = pVals, SE = SE, RSE = RSE )
  rownames( seDF ) = allNames
  list(
    SE       = seDF[ , c( "parametersValues", "SE"  ), drop = FALSE ],
    RSE      = seDF[ , c( "parametersValues", "RSE" ), drop = FALSE ],
    table    = seDF,
    SEAndRSE = seDF,
    singular = singular
  )
}
