# Model-class registry: detect() tried in registration order.
#
# `pfim_register_model_class()` stores factory + optional detect() handlers.
# Resolution: explicit `modelClass` on the project, else first matching detect(),
# else legacy fallback in model-type-dispatch.R.
# Register specific detect() handlers before catch-all entries
# (see `.pfimInitBuiltinModelRegistry`).

#' @include model-type-dispatch.R
#' @include ModelAnalytic.R
#' @include ModelAnalyticSteadyState.R
#' @include ModelAnalyticInfusion.R
#' @include ModelAnalyticInfusionSteadyState.R
#' @include ModelODE.R
#' @include model-ode-bolus.R
#' @include ModelODEInfusion.R
#' @include ModelODEInfusionDoseInEquation.R
#' @keywords internal
NULL

.pfimModelClassRegistry = new.env( parent = emptyenv() )

#' Ordered list of registered model class names (registration order).
#' @noRd
#' @keywords internal
.pfimModelClassOrder = function() {
  if ( exists( "__order__", envir = .pfimModelClassRegistry, inherits = FALSE ) )
    get( "__order__", envir = .pfimModelClassRegistry )
  else
    character( 0L )
}

#' Append a class name to the registry order (no duplicates).
#' @noRd
#' @keywords internal
.pfimModelClassOrderAppend = function( className ) {
  ord = .pfimModelClassOrder()
  if ( !className %in% ord )
    assign( "__order__", c( ord, className ), envir = .pfimModelClassRegistry )
}

#' Register a model class
#' @param className Character S7 class name (e.g. \code{"ModelAnalytic"}).
#' @param factory Zero-argument function returning a \code{Model} object.
#' @param detect Optional \code{function(pfimproject)} returning logical.
#' @return Invisibly, \code{NULL}.
#' @export
pfim_register_model_class = function( className, factory, detect = NULL ) {
  if ( length( className ) != 1L || !is.character( className ) || !nzchar( className ) )
    stop( "className must be a non-empty character string.", call. = FALSE )
  if ( !is.function( factory ) )
    stop( "factory must be a function.", call. = FALSE )
  if ( !is.null( detect ) && !is.function( detect ) )
    stop( "detect must be NULL or a function.", call. = FALSE )
  assign(
    className,
    list( factory = factory, detect = detect ),
    envir = .pfimModelClassRegistry
  )
  .pfimModelClassOrderAppend( className )
  invisible( NULL )
}

#' Resolve model class name for a project
#' @param pfimproject A \code{PFIMProject}, \code{Evaluation}, or \code{Optimization}.
#' @return Character class name with attribute \code{source} (\code{"registry"} or \code{"legacy"}).
#' @export
pfim_resolve_model_class = function( pfimproject ) {
  info = .pfimResolveModelClassInfo( pfimproject )
  structure( info$class, source = info$source )
}

#' Resolve class name and provenance (explicit / registry / legacy).
#' @noRd
#' @keywords internal
.pfimResolveModelClassInfo = function( pfimproject ) {
  explicit = projectProp( pfimproject, "modelClass" )
  if ( length( explicit ) == 1L && nzchar( explicit ) ) {
    if ( !exists( explicit, envir = .pfimModelClassRegistry, inherits = FALSE ) )
      stop( "Unknown model class: ", explicit, call. = FALSE )
    return( list( class = explicit, source = "explicit" ) )
  }

  equations = projectProp( pfimproject, "modelEquations" )
  ic        = .initialConditionsFromProject( pfimproject )

  # First matching detect() wins (most specific classes registered first).
  for ( nm in .pfimModelClassOrder() ) {
    entry = get( nm, envir = .pfimModelClassRegistry )
    if ( !is.null( entry$detect ) && isTRUE( entry$detect( equations, ic ) ) )
      return( list( class = nm, source = "registry" ) )
  }

  list(
    class  = .selectModelClass( .detectModelFeatures( equations, ic ) ),
    source = "legacy"
  )
}

#' Instantiate a registered model class via its factory.
#' @noRd
#' @keywords internal
.pfimInstantiateModelClass = function( className ) {
  if ( !exists( className, envir = .pfimModelClassRegistry, inherits = FALSE ) )
    stop( "Unknown model class: ", className, call. = FALSE )
  get( className, envir = .pfimModelClassRegistry )$factory()
}

#' Persist resolved class name onto the project when modelClass was empty.
#' @noRd
#' @keywords internal
.pfimSyncModelClass = function( pfimproject, className ) {
  current = projectProp( pfimproject, "modelClass" )
  if ( length( current ) != 1L || !nzchar( current ) )
    projectProp( pfimproject, "modelClass" ) <- className
  invisible( className )
}

#' Register built-in analytic and ODE model classes (most specific first).
#' @noRd
#' @keywords internal
.pfimInitBuiltinModelRegistry = function() {
  feats = function( equations, ic ) .detectModelFeatures( equations, ic )

  pfim_register_model_class(
    "ModelODEBolus",
    function() ModelODEBolus(),
    detect = function( eq, ic ) {
      f = feats( eq, ic ); f$isODE && f$doseInInitialConditions
    }
  )
  pfim_register_model_class(
    "ModelODEInfusionDoseInEquation",
    function() ModelODEInfusionDoseInEquation(),
    detect = function( eq, ic ) {
      f = feats( eq, ic ); f$isODE && f$hasInfusion && f$doseInEquation
    }
  )
  pfim_register_model_class(
    "ModelODEDoseInEquations",
    function() ModelODEDoseInEquations(),
    detect = function( eq, ic ) {
      f = feats( eq, ic ); f$isODE && f$doseInEquation
    }
  )
  # Catch-all for remaining ODE models (no dose-in-equation / bolus-IC specifics).
  pfim_register_model_class(
    "ModelODEDoseNotInEquations",
    function() ModelODEDoseNotInEquations(),
    detect = function( eq, ic ) feats( eq, ic )$isODE
  )
  pfim_register_model_class(
    "ModelAnalyticInfusionSteadyState",
    function() ModelAnalyticInfusionSteadyState(),
    detect = function( eq, ic ) {
      f = feats( eq, ic )
      !f$isODE && f$hasInfusion && f$doseInEquation && f$hasTau
    }
  )
  pfim_register_model_class(
    "ModelAnalyticInfusion",
    function() ModelAnalyticInfusion(),
    detect = function( eq, ic ) {
      f = feats( eq, ic )
      !f$isODE && f$hasInfusion && f$doseInEquation
    }
  )
  pfim_register_model_class(
    "ModelAnalyticSteadyState",
    function() ModelAnalyticSteadyState(),
    detect = function( eq, ic ) {
      f = feats( eq, ic ); !f$isODE && f$hasTau
    }
  )
  # Catch-all for remaining analytic models.
  pfim_register_model_class(
    "ModelAnalytic",
    function() ModelAnalytic(),
    detect = function( eq, ic ) !feats( eq, ic )$isODE
  )
}

.pfimInitBuiltinModelRegistry()
