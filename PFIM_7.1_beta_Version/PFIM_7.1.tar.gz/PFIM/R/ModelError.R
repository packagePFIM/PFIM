#' @noRd
#' @keywords internal
#' Validation message for residual-error sigma constraints (or \code{NULL} if OK).
.modelErrorValidationMsg = function( sigmaInter, sigmaSlope, cError = 1.0 ) {
  if ( ( length( sigmaInter ) && sigmaInter < 0 ) || ( length( sigmaSlope ) && sigmaSlope < 0 ) )
    return( "ModelError: sigmaInter and sigmaSlope must be non-negative." )
  if ( length( cError ) && cError <= 0 )
    return( "ModelError: cError must be positive." )
  NULL
}

#' Stop if residual-error sigma parameters violate constraints.
#' @param sigmaInter Additive residual SD.
#' @param sigmaSlope Proportional residual SD.
#' @param cError Power on the proportional term (must be positive).
#' @return Invisibly \code{NULL} when valid.
#' @noRd
#' @keywords internal
.checkModelErrorSigmas = function( sigmaInter, sigmaSlope, cError = 1.0 ) {
  msg = .modelErrorValidationMsg( sigmaInter, sigmaSlope, cError )
  if ( !is.null( msg ) ) stop( msg, call. = FALSE )
  invisible( NULL )
}

#' @title ModelError
#' @description
#' Base class for residual error models (\code{Constant}, \code{Combined1}, \code{Proportional}).
#' @param output Character string: outcome name.
#' @param equation Reserved (unused); variance is built from \code{sigmaInter}/\code{sigmaSlope}.
#' @param derivatives Reserved (unused).
#' @param sigmaInter Additive error standard deviation (inter-subject / residual).
#' @param sigmaSlope Proportional error standard deviation (slope).
#' @param sigmaInterFixed If TRUE, \code{sigmaInter} is fixed in the FIM.
#' @param sigmaSlopeFixed If TRUE, \code{sigmaSlope} is fixed in the FIM.
#' @param cError Power on the proportional term in \code{(sigmaInter + sigmaSlope * f^cError)^2}.
#' @return An S7 object of class \code{ModelError}.
#' @export
ModelError = new_class("ModelError", package = "PFIM",
                       properties = list(
                         output          = new_property(class_character,  default = "output"),
                         equation        = new_property(class_expression, default = expression()),
                         derivatives     = new_property(class_list,       default = list()),
                         sigmaInter      = new_property(class_double,     default = 0.0),
                         sigmaSlope      = new_property(class_double,     default = 0.0),
                         sigmaInterFixed = new_property(class_logical,    default = FALSE),
                         sigmaSlopeFixed = new_property(class_logical,    default = FALSE),
                         cError          = new_property(class_double,     default = 1.0)
                       ),
                       validator = function( self ) {
                         .modelErrorValidationMsg(
                           prop( self, "sigmaInter" ),
                           prop( self, "sigmaSlope" ),
                           prop( self, "cError" )
                         )
                       },
                       constructor = function(output          = "output",
                                              equation        = expression(),
                                              derivatives     = list(),
                                              sigmaInter      = 0.0,
                                              sigmaSlope      = 0.0,
                                              sigmaInterFixed = FALSE,
                                              sigmaSlopeFixed = FALSE,
                                              cError          = 1.0) {
                         new_object(.parent         = ModelError,
                                    output          = output,
                                    equation        = equation,
                                    derivatives     = derivatives,
                                    sigmaInter      = sigmaInter,
                                    sigmaSlope      = sigmaSlope,
                                    sigmaInterFixed = sigmaInterFixed,
                                    sigmaSlopeFixed = sigmaSlopeFixed,
                                    cError          = cError)
                       })

#' Evaluate derivatives for a residual error model
#' @param modelError A \code{ModelError} object.
#' @param ... Method arguments. For \code{ModelError}, \code{evaluationModel}
#'   (numeric predictions at sampling times).
#' @name evaluateErrorModelDerivatives
#' @return A matrix of error-model derivatives.
#' @export
evaluateErrorModelDerivatives = new_generic("evaluateErrorModelDerivatives", c("modelError"))

#' Extract residual error model settings
#' @param modelError A \code{ModelError} object.
#' @param ... Optional method arguments.
#' @name getModelErrorData
#' @return A data frame of model error parameter values.
#' @export
getModelErrorData              = new_generic("getModelErrorData",              c("modelError"))

#' Residual variance and sigma derivatives from predictions.
#'
#' Delegates to \code{.pfimErrorModelDerivatives} using the object's sigma
#' settings and the prediction column for this outcome.
#' @return List with \code{errorVariance} and \code{sigmaDerivatives}.
#' @name evaluateErrorModelDerivatives
#' @usage NULL
#' @keywords internal
method( evaluateErrorModelDerivatives, ModelError ) = function( modelError, evaluationModel ) {
  .pfimErrorModelDerivatives(
    prop( modelError, "sigmaInter" ),
    prop( modelError, "sigmaSlope" ),
    prop( modelError, "sigmaInterFixed" ),
    prop( modelError, "sigmaSlopeFixed" ),
    prop( modelError, "cError" ),
    evaluationModel
  )
}

#' Residual error settings for reports (type, sigmas, cError).
#' @param modelError A \code{ModelError} object.
#' @return One-row data frame of residual-error settings.
#' @name getModelErrorData
#' @keywords internal
method( getModelErrorData, ModelError ) = function( modelError ) {
  data.frame(
    output     = prop( modelError, "output"     ),
    type       = str_remove( class( modelError )[[1L]], "^PFIM::" ),
    sigmaSlope = as.character( prop( modelError, "sigmaSlope" ) ),
    sigmaInter = as.character( prop( modelError, "sigmaInter" ) ),
    cError     = as.character( prop( modelError, "cError" ) ),
    stringsAsFactors = FALSE
  )
}
