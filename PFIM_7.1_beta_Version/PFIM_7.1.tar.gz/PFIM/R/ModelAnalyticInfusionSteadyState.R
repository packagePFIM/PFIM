#' @title ModelAnalyticInfusionSteadyState
#' @description Analytic infusion model at steady state.
#' @inheritParams ModelInfusion
#' @param wrapperModelAnalyticInfusion                   Wrapper for the analytic solver.
#' @param functionArgumentsModelAnalyticInfusion         A list with the function arguments.
#' @param functionArgumentsSymbolModelAnalyticInfusion   A list with the function argument symbols.
#' @param solverInputs                                   A list with the solver inputs.
#' @inheritParams Model
#' @include ModelInfusion.R
#' @include ModelAnalytic.R
#' @return An S7 object of class \code{ModelAnalyticInfusionSteadyState}.
#' @export

ModelAnalyticInfusionSteadyState = new_class( "ModelAnalyticInfusionSteadyState",
                                              package = "PFIM",
                                              parent  = ModelInfusion,
                                              properties = list(
                                                wrapperModelAnalyticInfusion                 = new_property(class_list, default = list()),
                                                functionArgumentsModelAnalyticInfusion       = new_property(class_list, default = list()),
                                                functionArgumentsSymbolModelAnalyticInfusion = new_property(class_list, default = list()),
                                                solverInputs                                 = new_property(class_list, default = list())
                                              ))


#' Compile analytic wrappers for during/after infusion (with and without admin).
#'
#' Splits library equations into administered vs non-administered outcomes, then
#' builds four R functions via \code{.buildAnalyticWrapper}. Steady state adds
#' \code{tau} to the shared formal argument list.
#' @return Updated model with compiled infusion steady-state wrappers.
#' @name defineModelWrapper
#' @keywords internal
method( defineModelWrapper, ModelAnalyticInfusionSteadyState ) = function( model, evaluation ) {

  # Outcomes that receive dosing vs library names used in equation keys.
  outcomesWithAdministration = .getOutcomesFromEvaluation( evaluation )
  libraryOutcomesWithAdmin   = .administeredLibraryOutcomeNames( evaluation )

  # Formal names injected into each analytic wrapper: dose_*, Tinf_*, t_*, params, tau.
  parameters     = prop( evaluation, "modelParameters" )
  parameterNames = map_chr( parameters, "name" )
  doseNames      = paste0( "dose_", outcomesWithAdministration )
  timeNames      = paste0( "t_",    outcomesWithAdministration )
  TinfNames      = paste0( "Tinf_", outcomesWithAdministration )

  # Split during/after equations into administered vs passive outcomes.
  equations                  = prop( evaluation, "modelEquations" )
  equationsDuringWithAdmin   = equations$duringInfusion[  names( equations$duringInfusion ) %in% libraryOutcomesWithAdmin ]
  equationsAfterWithAdmin    = equations$afterInfusion[   names( equations$afterInfusion  ) %in% libraryOutcomesWithAdmin ]
  equationsDuringWithNoAdmin = equations$duringInfusion[ !names( equations$duringInfusion ) %in% libraryOutcomesWithAdmin ]
  equationsAfterWithNoAdmin  = equations$afterInfusion[  !names( equations$afterInfusion  ) %in% libraryOutcomesWithAdmin ]

  outputDuringAdmin   = names( equationsDuringWithAdmin )
  outputDuringNoAdmin = names( equationsDuringWithNoAdmin )
  outputAfterAdmin    = names( equationsAfterWithAdmin )
  outputAfterNoAdmin  = names( equationsAfterWithNoAdmin )

  # Steady-state dosing interval "tau" is required by the closed-form expressions.
  functionArguments = unique( c( doseNames, TinfNames, outcomesWithAdministration,
                                 parameterNames, timeNames, "tau" ) )

  # Four evaluators: (during|after) × (administered|passive) outcomes.
  prop( model, "wrapperModelAnalyticInfusion" ) = list(
    functionDefinitionDuringInfusionWithAdmin   = .buildAnalyticWrapper(
      equationsDuringWithAdmin, functionArguments,
      .libraryEquationTimeNames( evaluation, names( equationsDuringWithAdmin ) ), outputDuringAdmin ),
    functionDefinitionDuringInfusionWithNoAdmin = .buildAnalyticWrapper(
      equationsDuringWithNoAdmin, functionArguments,
      .libraryEquationTimeNames( evaluation, names( equationsDuringWithNoAdmin ) ), outputDuringNoAdmin ),
    functionDefinitionAfterInfusionWithAdmin    = .buildAnalyticWrapper(
      equationsAfterWithAdmin, functionArguments,
      .libraryEquationTimeNames( evaluation, names( equationsAfterWithAdmin ) ), outputAfterAdmin ),
    functionDefinitionAfterInfusionWithNoAdmin  = .buildAnalyticWrapper(
      equationsAfterWithNoAdmin, functionArguments,
      .libraryEquationTimeNames( evaluation, names( equationsAfterWithNoAdmin ) ), outputAfterNoAdmin )
  )
  prop( model, "functionArgumentsModelAnalyticInfusion" ) = list( functionArguments = functionArguments )
  prop( model, "functionArgumentsSymbolModelAnalyticInfusion" ) = list(
    functionArgumentsSymbol = map( functionArguments, as.symbol )
  )
  prop( model, "outputNames" ) = unlist( names( equations$duringInfusion ) )
  prop( model, "outcomesWithAdministration" ) = outcomesWithAdministration

  return( model )
}


#' Build per-outcome dose / infusion / sampling tables for the analytic solver.
#'
#' For \code{tau != 0}, expands a single steady-state dose into a regular grid
#' \code{0, tau, 2*tau, ...} up to the last sampling time. Labels each sampling
#' as \code{duringInfusion} or \code{afterInfusion}, and records which dose index
#' is active at that time (for superposition of past infusions).
#' @return Updated model with \code{samplings} and \code{solverInputs}.
#' @name defineModelAdministration
#' @keywords internal
method( defineModelAdministration, ModelAnalyticInfusionSteadyState ) = function( model, arm ) {

  administrations            = prop( arm,   "administrations" )
  outcomesWithAdministration = prop( model, "outcomesWithAdministration" )
  samplingTimes              = prop( arm,   "samplingTimes" )

  # Global sorted unique observation grid (all outcomes).
  samplings = map( samplingTimes, ~ prop( .x, "samplings" ) ) |>
    unlist() |> sort() |> unique()
  maxSampling = max( samplings )

  solverInputs = map( administrations, function( adm ) {
    tau      = prop( adm, "tau" )
    dosing   = .alignAdministrationDosing( adm )
    timeDose = dosing$timeDose
    dose     = dosing$dose
    Tinf     = dosing$Tinf

    # Steady state: replicate the unit dose every tau until maxSampling.
    if ( tau != 0 ) {
      timeDose = seq( 0, maxSampling, tau )
      dose     = rep( dose, length( timeDose ) )
      Tinf     = rep( Tinf, length( timeDose ) )
    }

    # Default all observations to "after"; flip to "during" inside [t_dose, t_dose+Tinf).
    duringAndAfter = rep( "afterInfusion", length( samplings ) )
    Tinfs = map2( timeDose, timeDose + Tinf, c )
    samplingsDuringInfusion = map( Tinfs, function( iv ) {
      samplings |> keep( ~ .x >= min(iv) & .x < max(iv) )
    }) |> unlist() |> unique()
    duringAndAfter[ samplings %in% samplingsDuringInfusion ] = "duringInfusion"

    # Relative times since each past dose (0 if sampling is before that dose).
    samplingTimeDoses = timeDose |> map( ~ ifelse( samplings - .x > 0, samplings - .x, 0 ) )

    # Active dose index at each sampling (= last dose with timeDose <= sampling).
    indicesDoses = map_int( samplings, function( s ) {
      idx = which( s >= timeDose ); idx[ length(idx) ]
    })

    data = data.frame( duringAndAfter, indicesDoses, samplings, samplingTimeDoses )
    colnames( data ) = c( "duringAndAfter", "indicesDoses", "samplings",
                          paste0( "samplingTimeDoses", seq_along( dose ) ) )
    list( data = data, dose = dose, Tinf = Tinf, tau = tau )
  }) |> set_names( outcomesWithAdministration )

  prop( model, "samplings" ) = samplings
  prop( model, "solverInputs" ) = solverInputs

  return( model )
}


#' Evaluate analytic infusion steady-state concentrations at all sampling times.
#'
#' For each observation time and administered outcome:
#' \enumerate{
#'   \item If inside an infusion window: evaluate the during-infusion formula for
#'     the current dose; if earlier doses exist, add their after-infusion remnants.
#'   \item If after an infusion: evaluate the after-infusion formula for the
#'     current dose, again superposing remnants of previous doses.
#' }
#' Passive (non-admin) equations are evaluated once the administered outcome value
#' is assigned into the shared evaluation environment.
#' @param model A \code{ModelAnalyticInfusionSteadyState} object.
#' @param arm   An \code{Arm} object.
#' @return Named list of output data frames at requested sampling times.
#' @keywords internal
evaluateAnalyticInfusionSteadyStateCore = function( model, arm ) {

  administrations            = prop( arm,   "administrations" )
  outcomesWithAdministration = map_chr( administrations, ~ prop( .x, "outcome" ) )
  outputNames                = prop( model, "outputNames" ) |> unlist()
  solverInputs               = prop( model, "solverInputs" )
  samplings                  = prop( model, "samplings" )

  # Compiled wrappers from defineModelWrapper().
  wrappers        = prop( model, "wrapperModelAnalyticInfusion" )
  fnDuringAdmin   = wrappers$functionDefinitionDuringInfusionWithAdmin
  fnDuringNoAdmin = wrappers$functionDefinitionDuringInfusionWithNoAdmin
  fnAfterAdmin    = wrappers$functionDefinitionAfterInfusionWithAdmin
  fnAfterNoAdmin  = wrappers$functionDefinitionAfterInfusionWithNoAdmin

  # Argument template: symbols resolved from the local environment via do.call.
  functionArguments = prop( model, "functionArgumentsModelAnalyticInfusion" )$functionArguments
  functionArgumentsSymbol = prop( model, "functionArgumentsSymbolModelAnalyticInfusion" )$functionArgumentsSymbol
  argsTemplate = stats::setNames( functionArgumentsSymbol, functionArguments )

  # Typical values (mu) become local variables (ka, V, Cl, …) for the wrappers.
  mu = .extractMu( prop( model, "modelParameters" ) )
  list2env( as.list( mu ), envir = environment() )

  # One row per global sampling time; columns = all outputs.
  evaluationModelTmpList = map( seq_along( samplings ), function( iterTime ) {

    outcomesResults = map( outcomesWithAdministration, function( outcome ) {
      data         = solverInputs[[ outcome ]]$data
      tau          = solverInputs[[ outcome ]]$tau
      duringAfter  = data$duringAndAfter[ iterTime ]
      indicesDoses = data$indicesDoses[ iterTime ]
      sampCols     = colnames( data )[ str_detect( colnames( data ), "samplingTimeDoses" ) ]
      sampTimes    = as.numeric( data[ iterTime, sampCols ] ) |> unlist() |> unname()

      # --- Administered outcome at this time ---------------------------------
      evalAdmin = if ( duringAfter == "duringInfusion" ) {

        if ( indicesDoses == 1L ) {
          # First (or only) dose, still infusing: during-formula alone.
          assign( paste0( "t_", outcome ), sampTimes[ indicesDoses ], envir = environment() )
          assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ indicesDoses ], envir = environment() )
          assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ indicesDoses ], envir = environment() )
          do.call( fnDuringAdmin, argsTemplate ) |> unlist()

        } else {
          # Current dose still infusing + remnants of finished previous doses.
          sampTimesUsed  = sampTimes[ seq_len( indicesDoses ) ]
          samplingDuring = tail( sampTimesUsed, 1L )
          samplingAfter  = sampTimesUsed[ seq_len( indicesDoses - 1L ) ]

          assign( paste0( "t_", outcome ), samplingDuring, envir = environment() )
          assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ indicesDoses ], envir = environment() )
          assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ indicesDoses ], envir = environment() )
          evalDuring = do.call( fnDuringAdmin, argsTemplate ) |> unlist()

          evalDuring + sum( map_dbl( seq_len( indicesDoses - 1L ), function( idx ) {
            assign( paste0( "t_", outcome ), samplingAfter[ idx ], envir = environment() )
            assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ idx ], envir = environment() )
            assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ idx ], envir = environment() )
            do.call( fnAfterAdmin, argsTemplate ) |> unlist()
          } ) )
        }

      } else if ( indicesDoses == 1L ) {
        # After the first dose only: after-formula alone.
        assign( paste0( "t_", outcome ), sampTimes[ indicesDoses ], envir = environment() )
        assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ indicesDoses ], envir = environment() )
        assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ indicesDoses ], envir = environment() )
        do.call( fnAfterAdmin, argsTemplate ) |> unlist()

      } else {
        # After several doses: after-formula for current + sum of earlier after-formulas.
        sampTimesUsed  = sampTimes[ seq_len( indicesDoses ) ]
        samplingDuring = tail( sampTimesUsed, 1L )
        samplingAfter  = sampTimesUsed[ seq_len( indicesDoses - 1L ) ]

        assign( paste0( "t_", outcome ), samplingDuring, envir = environment() )
        assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ indicesDoses ], envir = environment() )
        assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ indicesDoses ], envir = environment() )
        evalAfter = do.call( fnAfterAdmin, argsTemplate ) |> unlist()

        evalAfter + sum( map_dbl( seq_len( indicesDoses - 1L ), function( idx ) {
          assign( paste0( "t_", outcome ), samplingAfter[ idx ], envir = environment() )
          assign( paste0( "dose_", outcome ), solverInputs[[ outcome ]]$dose[ idx ], envir = environment() )
          assign( paste0( "Tinf_", outcome ), solverInputs[[ outcome ]]$Tinf[ idx ], envir = environment() )
          do.call( fnAfterAdmin, argsTemplate ) |> unlist()
        } ) )
      }

      # Make administered prediction available to passive equations (e.g. PD).
      assign( outcome, evalAdmin, envir = environment() )
      evalNoAdmin = do.call( fnAfterNoAdmin, argsTemplate ) |> unlist()

      if ( is.null( evalNoAdmin ) || length( evalNoAdmin ) == 0L )
        data.frame( evalAdmin )
      else
        data.frame( evalAdmin, evalNoAdmin )
    })

    data.frame( time = samplings[[ iterTime ]], do.call( cbind, outcomesResults ) )
  })

  evaluationModelTmp = list_rbind( evaluationModelTmpList )
  colnames( evaluationModelTmp ) = c( "time", outputNames )

  # Restrict each output to its own sampling schedule (may differ by outcome).
  samplings_by_output = set_names(
    map( prop( arm, "samplingTimes" ), ~ prop( .x, "samplings" ) ),
    outputNames
  )
  set_names(
    map( outputNames, ~ evaluationModelTmp[ evaluationModelTmp$time %in% samplings_by_output[[ .x ]], c( "time", .x ) ] ),
    outputNames
  )
}


#' Dispatch: covariate/occasion structure → specialised path; else core evaluator.
#' @return Named list of output data frames at requested sampling times.
#' @name evaluateModel
#' @keywords internal
method( evaluateModel, ModelAnalyticInfusionSteadyState ) = function( model, arm ) {
  if ( usesCovariateOccasionStructure( model ) )
    evaluateModelWithCovariates( model, arm, evaluateAnalyticInfusionSteadyStateCore )
  else
    evaluateAnalyticInfusionSteadyStateCore( model, arm )
}


#' Return PK equations stored on the model (library / user analytic infusion SS).
#' @param pkModel First argument of generic.
#' @param pfimproject \code{PFIMProject} object (unused).
#' @return List of PK equations from \code{pkModel}.
#' @name definePKModel
#' @keywords internal
method( definePKModel, list( ModelAnalyticInfusionSteadyState, PFIMProject ) ) = function( pkModel, pfimproject ) {
  prop( pkModel, "modelEquations" )
}
