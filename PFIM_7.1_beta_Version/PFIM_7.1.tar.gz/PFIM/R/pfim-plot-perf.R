# Plot-time helpers for evaluation reports (response and sensitivity curves).
#
# Densifies sampling grids under a point cap, interpolates stored model/gradient
# curves onto that grid, and skips arms that lack enough distinct times.

#' Standard cap on dense time grids for evaluation report plots.
#' @noRd
#' @keywords internal
.pfimDefaultPlotMaxPoints = function() 400L

#' Time grid for report plots: keep design times, add intermediate points with a cap.
#' @noRd
#' @keywords internal
.pfimDensePlotTimes = function(
    times,
    maxPoints = .pfimDefaultPlotMaxPoints(),
    minStep   = 0.1 ) {
  times = sort( unique( as.numeric( times ) ) )
  if ( !length( times ) ) return( times )
  tmax = max( times, 0 )
  # Already dense enough — do not add more points.
  if ( length( times ) >= maxPoints ) return( times )
  by = max( minStep, tmax / max( maxPoints - 1L, 1L ) )
  sort( unique( c( times, seq( 0, tmax, by = by ) ) ) )
}

#' Resolve maxPlotPoints from plot options (fallback to default cap).
#' @noRd
#' @keywords internal
.pfimPlotMaxPoints = function( plotOptions ) {
  as.integer( plotOptions$maxPlotPoints %||% .pfimDefaultPlotMaxPoints() )
}

#' Sampling grids and dense plot times for one arm (response or SI plots).
#' @noRd
#' @keywords internal
.pfimArmPlotSampling = function( arm, model, outputNames, plotOptions ) {
  outNames     = unlist( outputNames, use.names = FALSE )
  samplingData = getSamplingData( arm )
  maxPts       = .pfimPlotMaxPoints( plotOptions )
  samplingsByResponse = .pfimSamplingsByResponse( samplingData, outNames, model )
  plotTimesByOutcome  = map(
    samplingsByResponse,
    ~ .pfimDensePlotTimes( .x, maxPoints = maxPts )
  )
  list(
    samplingData        = samplingData,
    maxPts              = maxPts,
    samplingsByResponse = samplingsByResponse,
    plotTimesByOutcome  = plotTimesByOutcome
  )
}

#' Looser ODE tolerances for report curves (FIM keeps evaluation-level settings).
#'
#' Plot defaults (\code{1e-6}) are relaxed relative to the FIM default
#' (\code{1e-8}) so report curves stay cheap while design evaluation stays
#' accurate.
#' @noRd
#' @keywords internal
.pfimPlotOdeSolverParameters = function( plotOptions ) {
  plotOptions$odeSolverParameters %||% list( atol = 1e-6, rtol = 1e-6 )
}

#' Clone model, bind arm administration, optionally loosen ODE tolerances for plots.
#' @noRd
#' @keywords internal
.pfimModelForPlotEvaluation = function( model, arm, plotOptions ) {
  model = .pfimPrepareModelForEvaluation( .pfimCloneS7( model ), arm )
  if ( .pfimUsesAdminCache( model ) )
    prop( model, "odeSolverParameters" ) = .pfimPlotOdeSolverParameters( plotOptions )
  model
}

#' Evaluated arms from \code{run()} when available (carry cached model/gradient results).
#' @noRd
#' @keywords internal
.pfimEvaluatedArmsForDesign = function( pfimproject, design ) {
  evaluated = prop( pfimproject, "evaluationDesign" )
  if ( length( evaluated ) ) {
    idx = match( prop( design, "name" ), map_chr( evaluated, ~ prop( .x, "name" ) ) )
    if ( !is.na( idx ) ) {
      arms = prop( evaluated[[ idx ]], "evaluationArms" )
      if ( length( arms ) ) return( arms )
    }
  }
  prop( design, "arms" )
}

#' Constant-extrapolation linear interpolation (ties ordered).
#' @noRd
#' @keywords internal
.pfimInterpolateSeries = function( x, y, xout ) {
  stats::approx( x, y, xout = xout, rule = 2, ties = "ordered" )$y
}

#' Interpolate every gradient column from sparse_t onto plot_t.
#' @noRd
#' @keywords internal
.pfimInterpolateGradientFrame = function( grad_cols, sparse_t, plot_t ) {
  out = data.frame( time = plot_t )
  for ( nm in colnames( grad_cols ) )
    out[[ nm ]] = .pfimInterpolateSeries( sparse_t, grad_cols[[ nm ]], plot_t )
  out
}

#' Minimum number of distinct sampling times required for response/SI plots.
#' @noRd
#' @keywords internal
.pfimMinSamplingTimesForPlots = function() 2L

#' Whether an arm has enough sampling times to build response/SI plots.
#' @noRd
#' @keywords internal
.pfimArmPlotsEnabled = function( arm, model, outputNames ) {
  outNames = unlist( outputNames, use.names = FALSE )
  if ( !length( outNames ) ) return( FALSE )
  samplings = .pfimSamplingsByResponse( getSamplingData( arm ), outNames, model )
  counts = map_int(
    samplings,
    ~ length( unique( stats::na.omit( as.numeric( .x ) ) ) )
  )
  all( counts >= .pfimMinSamplingTimesForPlots() )
}

#' Empty nested plot list for one arm (skip plotting).
#' @noRd
#' @keywords internal
.pfimEmptyArmPlotResult = function( designName, arm ) {
  stats::setNames(
    list( stats::setNames( list( list() ), prop( arm, "name" ) ) ),
    designName
  )
}

#' Sampling grids keyed by response names (RespPK) when outputs map to state names (Cc).
#' @noRd
#' @keywords internal
.pfimSamplingsByResponse = function( samplingData, responseNames, model = NULL ) {
  outputFormula = if ( !is.null( model ) ) .getModelOutputFormulas( model ) else list()
  .odeSamplingsByOutput( samplingData$samplingTimes, responseNames, outputFormula )
}

#' Interpolate stored model curves to the (capped) plot grid.
#'
#' Returns NULL for ODE admin-cache models (must re-simulate) or when no curves
#' are stored on the arm.
#' @noRd
#' @keywords internal
.pfimResponseCurvesForPlot = function( arm, model, outputNames, plotTimesByOutcome ) {
  if ( .pfimUsesAdminCache( model ) )
    return( NULL )
  stored = prop( arm, "evaluationModel" )
  if ( !length( stored ) ) return( NULL )
  em = if ( .isNestedEvaluationModel( stored ) )
    .aggregateEvaluationModelForPlot( stored ) else stored
  out = map( outputNames, function( out_name ) {
    df = em[[ out_name ]]
    plot_t = plotTimesByOutcome[[ out_name ]]
    if ( is.null( df ) || !nrow( df ) || is.null( plot_t ) || !length( plot_t ) )
      return( NULL )
    ycol = out_name
    if ( !ycol %in% names( df ) ) return( NULL )
    res = data.frame( time = plot_t )
    res[[ ycol ]] = .pfimInterpolateSeries( df$time, df[[ ycol ]], plot_t )
    res
  } )
  names( out ) = unlist( outputNames, use.names = FALSE )
  if ( !any( lengths( out ) ) ) NULL else out
}

#' Drop covariate beta columns from sensitivity-index parameter names.
#' @param names Character vector of gradient / SI parameter names.
#' @return Character vector without \code{beta_*} / \code{\u03b2_*} entries.
#' @noRd
#' @keywords internal
.pfimSiParamNamesNoBeta = function( names ) {
  if ( !length( names ) ) return( names )
  names[
    !startsWith( names, "beta_" ) &
      !startsWith( names, "\u03b2_" )
  ]
}

#' Proportion-weighted gradient matrix for one model output (covariate structure).
#'
#' Averages gradients across occasions within each covariate combination, then
#' mixes combinations by their design proportion.
#' @noRd
#' @keywords internal
.pfimAggregateGradientForOutput = function( model, arm, outName ) {
  allGradientsData = prop( arm, "evaluationGradients" )
  zeroGrad = allGradientsData[[ 1L ]]$gradients[[ 1L ]]$gradient[[ outName ]] * 0
  matList = map( allGradientsData, function( combinationData ) {
    nOcc     = length( combinationData$gradients )
    meanGrad = reduce(
      map( combinationData$gradients, ~ .x$gradient[[ outName ]] ),
      `+`
    ) / nOcc
    combinationData$proportion * meanGrad
  } )
  reduce( matList, `+`, .init = zeroGrad )
}

#' Interpolate stored gradients to the (capped) plot grid.
#'
#' Handles both nested (covariate × occasion) and flat gradient storage.
#' @noRd
#' @keywords internal
.pfimSiCurvesForPlot = function( arm, model, outputNames, plotTimesByOutcome ) {
  raw = prop( arm, "evaluationGradients" )
  if ( !length( raw ) ) return( NULL )
  outNames = unlist( outputNames, use.names = FALSE )
  em = prop( arm, "evaluationModel" )
  emAgg = if ( length( em ) && .isNestedEvaluationModel( em ) )
    .aggregateEvaluationModelForPlot( em ) else em

  if ( .isNestedArmEvaluation( raw ) ) {
    frames = map( outNames, function( out ) {
      plot_t = plotTimesByOutcome[[ out ]]
      sparse_t = emAgg[[ out ]]$time
      grad_cols = as.data.frame(
        .pfimAggregateGradientForOutput( model, arm, out ),
        stringsAsFactors = FALSE
      )
      colNames = colnames( grad_cols )
      if ( is.null( colNames ) || !ncol( grad_cols ) || is.null( sparse_t ) ||
           is.null( plot_t ) || !length( plot_t ) ||
           nrow( grad_cols ) != length( sparse_t ) )
        return( NULL )
      .pfimInterpolateGradientFrame( grad_cols, sparse_t, plot_t )
    } )
    names( frames ) = outNames
    if ( !any( lengths( frames ) ) ) NULL else frames
  } else {
    frames = map2( outNames, raw, function( out, grad ) {
      plot_t = plotTimesByOutcome[[ out ]]
      sparse_t = emAgg[[ out ]]$time
      if ( is.null( plot_t ) || !length( plot_t ) || is.null( sparse_t ) )
        return( NULL )
      grad_cols = as.data.frame( grad, stringsAsFactors = FALSE )
      if ( is.null( colnames( grad_cols ) ) || !ncol( grad_cols ) ) return( NULL )
      .pfimInterpolateGradientFrame( grad_cols, sparse_t, plot_t )
    } )
    names( frames ) = outNames
    if ( !any( lengths( frames ) ) ) NULL else frames
  }
}

#' Convert freshly computed dense gradients to per-output data frames with time.
#' @noRd
#' @keywords internal
.pfimSiFramesFromDenseGradients = function(
    evaluationModelGradient, model, armPlot, outputNames, parametersNames ) {
  outNames = unlist( outputNames, use.names = FALSE )
  stList = .pfimSamplingsByResponse( getSamplingData( armPlot ), outNames, model )
  if ( .isNestedArmEvaluation( evaluationModelGradient ) ) {
    armForGrad = armPlot
    prop( armForGrad, "evaluationGradients" ) = evaluationModelGradient
    colNames = colnames( .pfimAggregateGradientForOutput( model, armForGrad, outNames[[ 1L ]] ) )
    if ( is.null( colNames ) || !length( colNames ) )
      colNames = parametersNames
    frames = map( outNames, function( out ) {
      st = stList[[ out ]][ seq_len( nrow( .pfimAggregateGradientForOutput( model, armForGrad, out ) ) ) ]
      df = as.data.frame( .pfimAggregateGradientForOutput( model, armForGrad, out ), stringsAsFactors = FALSE )
      colnames( df ) = colNames
      df$time = st
      df
    } )
    set_names( frames, outNames )
  } else {
    map( outNames, function( out ) {
      grad = evaluationModelGradient[[ out ]]
      df   = as.data.frame( grad, stringsAsFactors = FALSE )
      df$time = stList[[ out ]][ seq_len( nrow( df ) ) ]
      df
    } ) |> set_names( outNames )
  }
}
