#' @title ModelODE
#' @description Base class for models integrated with \code{deSolve}.
#' @inheritParams Model
#' @include Model.R
#' @return An S7 object of class \code{ModelODE}.
#' @export

ModelODE = new_class( "ModelODE", package = "PFIM", parent = Model )

#' Check whether a value is a finite scalar.
#' @param x Object to validate.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.scalar_finite = function( x ) {
  length( x ) == 1L && !is.na( x ) && is.finite( x )
}

#' Extract representative mu values from model parameters.
#'
#' Preference order: distribution mu when omega is present; else mu when value
#' is missing; else the reserved \code{value} slot; else mu again. Used to seed
#' ODE/analytic evaluation environments.
#' @param parameters List of \code{ModelParameter} objects.
#' @return Named numeric vector of parameter values used by ODE solvers.
#' @noRd
#' @keywords internal
.extractMu = function( parameters ) {
  set_names(
    map_dbl( parameters, function( parameter ) {
      distribution = prop( parameter, "distribution" )
      value        = prop( parameter, "value" )

      if ( !is.null( distribution ) ) {
        omega = prop( distribution, "omega" )
        mu    = prop( distribution, "mu" )
        # Random-effect parameter: evaluate at typical value mu.
        if ( .scalar_finite( omega ) && omega != 0 )
          return( mu )
        if ( .scalar_finite( mu ) && mu != 0 && !.scalar_finite( value ) )
          return( mu )
      }
      if ( .scalar_finite( value ) )
        return( value )
      if ( !is.null( distribution ) && .scalar_finite( prop( distribution, "mu" ) ) )
        return( prop( distribution, "mu" ) )
      NA_real_
    }),
    map_chr( parameters, ~ prop( .x, "name" ) )
  )
}

#' Build sorted unique sampling grid including time zero.
#' @param samplingTimes List of \code{SamplingTimes} objects.
#' @return Numeric vector of sampling times.
#' @noRd
#' @keywords internal
.buildSamplings = function( samplingTimes ) {
  s = map( samplingTimes, ~ prop( .x, "samplings" ) ) |> unlist() |> sort() |> unique()
  c( 0.0, s[ s != 0 ] )
}

#' Extract administered outcomes from project design arms.
#' @param evaluation \code{PFIMProject} or \code{Evaluation} object.
#' @return Character vector of outcome names with administrations.
#' @noRd
#' @keywords internal
.getOutcomesFromEvaluation = function( evaluation ) {
  prop( evaluation, "designs" ) |>
    map( \(d) prop( d, "arms" ) ) |>
    list_flatten() |>
    map( \(arm) prop( arm, "administrations" ) ) |>
    list_flatten() |>
    map_chr( \(adm) prop( adm, "outcome" ) ) |>
    unique()
}

#' Resolve library output names that are administered.
#' @param evaluation \code{PFIMProject} or \code{Evaluation} object.
#' @return Character vector of output names to treat as administered.
#' @noRd
#' @keywords internal
.administeredLibraryOutcomeNames = function( evaluation ) {
  adminOutcomes = .getOutcomesFromEvaluation( evaluation )
  outputs       = prop( evaluation, "outputs" )
  if ( length( outputs ) == 0L ) return( adminOutcomes )
  outputValues = unlist( outputs, use.names = TRUE )
  outputNames  = names( outputValues )
  if ( is.null( outputNames ) ) outputNames = as.character( outputValues )
  kept = outputValues %in% adminOutcomes
  if ( any( kept ) ) outputNames[ kept ] else adminOutcomes
}

#' Build time-variable name for one library outcome.
#' @param evaluation \code{PFIMProject} carrying output mapping.
#' @param libraryOutcomeName Character outcome name from library equations.
#' @return Character scalar time-variable name.
#' @noRd
#' @keywords internal
.libraryEquationTimeName = function( evaluation, libraryOutcomeName ) {
  outputs = prop( evaluation, "outputs" )
  admin   = outputs[[ libraryOutcomeName ]]
  paste0( "t_", if ( !is.null( admin ) && nzchar( admin ) ) admin else libraryOutcomeName )
}

#' Build time-variable names for multiple library outcomes.
#' @param evaluation \code{PFIMProject} carrying output mapping.
#' @param libraryOutcomeNames Character vector of library outcome names.
#' @return Character vector of time-variable names.
#' @noRd
#' @keywords internal
.libraryEquationTimeNames = function( evaluation, libraryOutcomeNames ) {
  map_chr( libraryOutcomeNames, ~ .libraryEquationTimeName( evaluation, .x ) )
}

#' Build an executable ODE wrapper from equation strings.
#' @param equations Named character vector of equation definitions.
#' @param functionArguments Character vector of wrapper argument names.
#' @return Function returning derivative vectors for ODE integration.
#' @noRd
#' @keywords internal
.buildODEWrapper = function( equations, functionArguments ) {
  body = paste(
    paste( map_chr( names( equations ),
                    ~ sprintf( "%s = %s", .x, equations[[.x]] ) ),
           collapse = "\n" ),
    sprintf( "return(list(c(%s)))", paste( names( equations ), collapse = ", " ) ),
    sep = "\n"
  )
  fn = eval( parse( text = sprintf( "function(%s) { %s }",
                                    paste( functionArguments, collapse = ", " ), body ) ) )
  # Free symbols (global covariates) resolve in knit/global env, not the package ns.
  environment( fn ) = .pfimUserSymbolEnv()
  fn
}

.pfimOutputFormulaCache = new.env( parent = emptyenv() )
.pfimParsedOutputFormulaCache = new.env( parent = emptyenv() )

#' Parse one output-formula entry when needed.
#' @param x Character formula expression or already parsed object.
#' @return Parsed expression or original object.
#' @noRd
#' @keywords internal
.parseOutputFormulaEntry = function( x ) {
  if ( is.character( x ) ) parse( text = x ) else x
}

#' Resolve output column name in ODE simulation data.
#' @param out_name Character requested output name.
#' @param evaluationModelTmp Data frame returned by ODE simulation.
#' @param outputFormula Optional output formula mapping.
#' @return Character column name present in \code{evaluationModelTmp}.
#' @noRd
#' @keywords internal
.odeColumnForOutput = function( out_name, evaluationModelTmp, outputFormula ) {
  cols = names( evaluationModelTmp )
  if ( out_name %in% cols ) return( out_name )
  if ( length( outputFormula ) && out_name %in% names( outputFormula ) ) {
    target = outputFormula[[ out_name ]]
    if ( is.character( target ) && length( target ) == 1L ) {
      dotted = paste0( out_name, ".", target )
      if ( dotted %in% cols ) return( dotted )
      if ( target %in% cols ) return( target )
    }
  }
  out_name
}

#' Build cache lookup key for model output formulas.
#' @param model \code{Model} object containing output names.
#' @return Character scalar lookup key.
#' @noRd
#' @keywords internal
.pfimOutputFormulaLookupKey = function( model ) {
  outputs = prop( model, "outputFormula" ) %||% list()
  formula_sig = if ( length( outputs ) )
    paste( names( outputs ), as.character( outputs ), sep = "=", collapse = "|" )
  else ""
  paste(
    class( model )[[ 1L ]],
    paste( prop( model, "outputNames" ), collapse = "," ),
    formula_sig,
    sep = "::"
  )
}

#' Store output formula mapping in cache.
#' @param model \code{Model} object serving as cache key source.
#' @param outputs Named list of output formulas.
#' @return Invisibly returns updated \code{model}.
#' @noRd
#' @keywords internal
.setModelOutputFormulas = function( model, outputs ) {
  lookupKey = .pfimOutputFormulaLookupKey( model )
  .pfimCacheStore( .pfimOutputFormulaCache, lookupKey, outputs )
  .pfimParsedOutputFormulaCache[[ lookupKey ]] = NULL
  prop( model, "outputFormula" ) = outputs
  invisible( model )
}

#' Retrieve output formulas from cache or model slot.
#' @param model \code{Model} object serving as cache key source.
#' @return Named list of output formulas.
#' @noRd
#' @keywords internal
.getModelOutputFormulas = function( model ) {
  cached = .pfimOutputFormulaCache[[ .pfimOutputFormulaLookupKey( model ) ]]
  if ( !is.null( cached ) ) return( cached )
  prop( model, "outputFormula" )
}

#' Retrieve parsed output formulas with memoization.
#' @param model \code{Model} object serving as cache key source.
#' @return Named list of parsed output expressions.
#' @noRd
#' @keywords internal
.getOutputFormulaParsed = function( model ) {
  key = .pfimOutputFormulaLookupKey( model )
  cached = .pfimParsedOutputFormulaCache[[ key ]]
  if ( !is.null( cached ) ) return( cached )
  outputs = .getModelOutputFormulas( model )
  if ( !length( outputs ) ) return( outputs )
  parsed = map( outputs, .parseOutputFormulaEntry )
  .pfimCacheStore( .pfimParsedOutputFormulaCache, key, parsed )
  parsed
}

#' Evaluate initial-condition expressions against parameter environment.
#' @param model \code{ModelODE} object providing parameter values.
#' @param arm \code{Arm} object containing initial-condition definitions.
#' @return Named numeric vector of initial conditions.
#' @noRd
#' @keywords internal
.evalInitialConditionsImpl = function( model, arm ) {
  mu = .extractMu( prop( model, "modelParameters" ) )
  list2env( as.list( mu ), envir = environment() )
  imap( prop( arm, "initialConditions" ), function( ic, compartment ) {
    if ( is.numeric( ic ) )
      return( ic )
    eval( parse( text = ic ) )
  }) |> unlist()
}

#' Evaluate initial conditions for ODE models (numeric or expression IC).
#' @return Named numeric vector of evaluated initial conditions.
#' @name evaluateInitialConditions
#' @keywords internal
method( evaluateInitialConditions, ModelODE ) = function( model, arm ) {
  .evalInitialConditionsImpl( model, arm )
}
