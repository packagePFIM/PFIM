#' @title ModelParameter
#' @description
#' One population model parameter: distribution (mu, omega), optional IOV (gamma), and fix flags.
#' @param name          Character string: name of the parameter.
#' @param gamma         Numeric: the SD for inter-occasion variability (IOV).
#'                      \code{gamma^2} is the IOV variance component; \code{0} means no IOV.
#' @param distribution  An object of class \code{Distribution} for this parameter.
#' @param fixedMu       Logical: TRUE if \code{mu} is fixed (not estimated).
#' @param fixedOmega    Logical: TRUE if \code{omega} is fixed (not estimated).
#' @param value         Reserved (unused); use \code{distribution@mu} for reports and FIM.
#' @include Distribution.R
#' @return An S7 object of class \code{ModelParameter}.
#' @export

ModelParameter = new_class( "ModelParameter",
                            package = "PFIM",
                            properties = list(
                              name         = new_property(class_character, default = character(0)),
                              gamma        = new_property(class_double,    default = 0),
                              distribution = new_property(Distribution,    default = NULL),
                              fixedMu      = new_property(class_logical,   default = FALSE),
                              fixedOmega   = new_property(class_logical,   default = FALSE),
                              value        = new_property(class_double,    default = numeric(0))
                            ),
                            validator = function( self ) {
                              g = prop( self, "gamma" )
                              if ( length( g ) && g < 0 )
                                return( "ModelParameter: gamma must be non-negative." )
                              d = prop( self, "distribution" )
                              if ( !is.null( d ) ) {
                                om = prop( d, "omega" )
                                if ( length( om ) && om < 0 )
                                  return( "ModelParameter: omega must be non-negative." )
                              }
                              NULL
                            })

#' Read one field from a parameter's distribution slot.
#' @param parameter A \code{ModelParameter} object.
#' @param field Character field name (\code{"mu"} or \code{"omega"}).
#' @return Value of the requested distribution field.
#' @noRd
#' @keywords internal
.paramDist = function( parameter, field ) {
  prop( prop( parameter, "distribution" ), field )
}

#' Whether \code{mu} is estimable (not fixed and non-zero).
#' @param parameter A \code{ModelParameter} object.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.paramMuEstimable = function( parameter ) {
  !isTRUE( prop( parameter, "fixedMu" ) ) && .paramDist( parameter, "mu" ) != 0
}

#' Whether \code{mu} is treated as fixed in the FIM.
#' @param parameter A \code{ModelParameter} object.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.paramMuFixed = function( parameter ) {
  !.paramMuEstimable( parameter )
}

#' Whether \code{omega} is estimable (requires estimable mu, unfixed, non-zero).
#' @param parameter A \code{ModelParameter} object.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.paramOmegaEstimable = function( parameter ) {
  .paramMuEstimable( parameter ) &&
    !isTRUE( prop( parameter, "fixedOmega" ) ) &&
    .paramDist( parameter, "omega" ) != 0
}

#' Whether \code{omega} is treated as fixed in the FIM.
#' @param parameter A \code{ModelParameter} object.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.paramOmegaFixed = function( parameter ) {
  !.paramOmegaEstimable( parameter )
}

#' Whether \code{gamma} (IOV SD) is estimable.
#'
#' Requires \code{gamma > 0} and unfixed omega (IOV shares the omega fix flag).
#' @param parameter A \code{ModelParameter} object.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.paramGammaEstimable = function( parameter ) {
  pluck( parameter, "gamma", .default = 0 ) > 0 &&
    !isTRUE( prop( parameter, "fixedOmega" ) )
}

#' Whether any parameter carries positive IOV (\code{gamma > 0}).
#' @param parameters List of \code{ModelParameter} objects.
#' @return Logical scalar.
#' @noRd
#' @keywords internal
.hasIovParameters = function( parameters ) {
  any( map_dbl( parameters, ~ pluck( .x, "gamma", .default = 0 ) ) > 0 )
}

#' Names of parameters matching \code{predicate}, with optional prefix.
#' @param parameters List of \code{ModelParameter} objects.
#' @param predicate Function returning logical for one parameter.
#' @param prefix Character prefix (e.g. \code{"mu_"}).
#' @return Character vector of labelled names.
#' @noRd
#' @keywords internal
.paramLabelNames = function( parameters, predicate, prefix = "" ) {
  parameters |>
    keep( predicate ) |>
    map_chr( ~ paste0( prefix, prop( .x, "name" ) ) )
}

#' Names of estimable \code{mu} parameters (\code{prefix} optional: \code{"mu_"}, greek, etc.).
#' @param parameters List of \code{ModelParameter} objects.
#' @param prefix Character prefix prepended to each name.
#' @return Character vector of estimable mu labels.
#' @noRd
#' @keywords internal
.estimableMuNames = function( parameters, prefix = "" ) {
  .paramLabelNames( parameters, .paramMuEstimable, prefix )
}

#' Typical values (\code{mu}) for estimable fixed effects.
#' @param parameters List of \code{ModelParameter} objects.
#' @return Numeric vector of mu values.
#' @noRd
#' @keywords internal
.paramMuValues = function( parameters ) {
  parameters |>
    keep( .paramMuEstimable ) |>
    map_dbl( ~ .paramDist( .x, "mu" ) )
}

#' IIV variances (\code{omega^2}) for estimable random effects.
#' @param parameters List of \code{ModelParameter} objects.
#' @return Numeric vector of omega-squared values.
#' @noRd
#' @keywords internal
.paramOmegaSqValues = function( parameters ) {
  parameters |>
    keep( .paramOmegaEstimable ) |>
    map_dbl( ~ .paramDist( .x, "omega" )^2 )
}

#' IOV variances (\code{gamma^2}) for estimable occasion effects.
#' @param parameters List of \code{ModelParameter} objects.
#' @return Numeric vector of gamma-squared values.
#' @noRd
#' @keywords internal
.paramGammaSqValues = function( parameters ) {
  parameters |>
    keep( .paramGammaEstimable ) |>
    map_dbl( ~ pluck( .x, "gamma" )^2 )
}

getModelParametersData = new_generic( "getModelParametersData", c( "modelParameter" ) )

#' Parameter table for reports (mu, omega2, gamma2, fix flags, distribution).
#' @param modelParameter A \code{ModelParameter} object.
#' @return A data frame of model parameter values.
#' @name getModelParametersData
#' @export
method( getModelParametersData, ModelParameter ) = function( modelParameter ) {

  list( modelParameter ) |>
    map( function( parameter ) {
      dist = prop( parameter, "distribution" )
      list(
        Parameters   = prop( parameter, "name"      ),
        mu           = as.character( prop( dist, "mu"    ) ),
        omega2       = as.character( prop( dist, "omega" )^2 ),
        gamma2       = as.character( prop( parameter, "gamma" )^2 ),
        Distribution = str_remove( class( dist )[1], "PFIM::" ),
        mu_fixed     = as.character( .paramMuFixed( parameter ) ),
        omega2_fixed = as.character( .paramOmegaFixed( parameter ) )
      )
    }) |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
}
