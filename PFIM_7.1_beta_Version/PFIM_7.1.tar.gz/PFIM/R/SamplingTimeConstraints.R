#' @title SamplingTimeConstraints
#' @description
#' Constraints on sampling times for design optimization (windows, fixed times,
#' number of points to optimize, minimum spacing).
#'
#' Metaheuristics (Simplex / PSO / PGBO) draw candidates with
#' \code{generateSamplingsFromSamplingConstraints()} and reject infeasible ones
#' via \code{checkSamplingTimeConstraintsForMetaheuristic()}. Discrete algorithms
#' instead enumerate combinations with \code{generateSamplingTimesCombination()}.
#' @param outcome Character string: outcome name.
#' @param initialSamplings Initial sampling-time vector.
#' @param fixedTimes Times that must remain fixed during optimization.
#' @param numberOfsamplingsOptimisable Number of sampling times to optimize
#'   (historical property name; \code{s} is lowercase).
#' @param samplingsWindows List of time windows for each optimizable sample.
#' @param numberOfTimesByWindows Number of samples per window.
#' @param minSampling Minimum spacing between consecutive samples.
#' @return An S7 object of class \code{SamplingTimeConstraints}.
#' @export

SamplingTimeConstraints = new_class( "SamplingTimeConstraints", package = "PFIM",

                                     properties = list( outcome = new_property(class_character, default = character(0)),
                                                        initialSamplings = new_property(class_vector, default = numeric(0)),
                                                        fixedTimes = new_property(class_vector, default = numeric(0)),
                                                        numberOfsamplingsOptimisable = new_property(class_double, default = 0.0),
                                                        samplingsWindows = new_property(class_list, default = list()),
                                                        numberOfTimesByWindows = new_property(class_vector, default = numeric(0)),
                                                        minSampling = new_property(class_vector, default = numeric(0))),
                                     validator = function( self ) {
                                       if ( any( prop( self, "minSampling" ) < 0, na.rm = TRUE ) )
                                         return( "SamplingTimeConstraints: minSampling must be non-negative." )
                                       n = prop( self, "numberOfsamplingsOptimisable" )
                                       if ( length( n ) && n < 0 )
                                         return( "SamplingTimeConstraints: numberOfsamplingsOptimisable must be non-negative." )
                                       init = prop( self, "initialSamplings" )
                                       if ( length( n ) && length( init ) && n > length( init ) )
                                         return( paste0(
                                           "SamplingTimeConstraints: numberOfsamplingsOptimisable (",
                                           n, ") cannot exceed length(initialSamplings) (", length( init ), ")."
                                         ) )
                                       nw = length( prop( self, "samplingsWindows" ) )
                                       nt = length( prop( self, "numberOfTimesByWindows" ) )
                                       ms = length( prop( self, "minSampling" ) )
                                       if ( nw && nt > 1L && nt != nw )
                                         return( "SamplingTimeConstraints: numberOfTimesByWindows length must be 1 or match samplingsWindows." )
                                       if ( nw && ms > 1L && ms != nw )
                                         return( "SamplingTimeConstraints: minSampling length must be 1 or match samplingsWindows." )
                                       NULL
                                     },
                                     constructor = function( outcome = character(0),
                                                             initialSamplings = numeric(0),
                                                             fixedTimes = numeric(0),
                                                             numberOfsamplingsOptimisable = 0.0,
                                                             samplingsWindows = list(),
                                                             numberOfTimesByWindows = numeric(0),
                                                             minSampling = numeric(0) ) {
                                       new_object(
                                         SamplingTimeConstraints,
                                         outcome                      = outcome,
                                         initialSamplings             = initialSamplings,
                                         fixedTimes                   = fixedTimes,
                                         numberOfsamplingsOptimisable = numberOfsamplingsOptimisable,
                                         samplingsWindows             = samplingsWindows,
                                         numberOfTimesByWindows       = numberOfTimesByWindows,
                                         minSampling                  = minSampling
                                       )
                                     } )

#' Draw random sampling times inside each window (respecting min spacing).
#' @param samplingTimeConstraints A \code{SamplingTimeConstraints} object.
#' @param ... Optional method arguments (unused by current methods).
#' @name generateSamplingsFromSamplingConstraints
#' @export
generateSamplingsFromSamplingConstraints = new_generic( "generateSamplingsFromSamplingConstraints", c( "samplingTimeConstraints" ) )

#' Check that proposed times meet window counts and min spacing.
#' @param samplingTimesConstraints A \code{SamplingTimeConstraints} object.
#' @param arm An \code{Arm} providing the candidate sampling schedule.
#' @param ... Method arguments: \code{newSamplings} (numeric times) and
#'   \code{outcome} (outcome name) for the metaheuristic check method.
#' @name checkSamplingTimeConstraintsForMetaheuristic
#' @export
checkSamplingTimeConstraintsForMetaheuristic = new_generic( "checkSamplingTimeConstraintsForMetaheuristic", c( "samplingTimesConstraints", "arm"  ) )

#' Draw feasible sampling times under window and spacing constraints.
#'
#' For each window \code{[min, max]} with \code{n} points and minimum gap
#' \code{delta}, places ordered uniforms so consecutive samples are at least
#' \code{delta} apart: remaining slack is \code{max - min - (n-1)*delta}.
#' @name generateSamplingsFromSamplingConstraints
#' @return Numeric vector of generated sampling times (all windows concatenated).
#' @usage NULL
#' @export

method( generateSamplingsFromSamplingConstraints, SamplingTimeConstraints ) = function( samplingTimeConstraints ) {

  minSampling = prop( samplingTimeConstraints, "minSampling" )
  samplingsWindow = prop( samplingTimeConstraints, "samplingsWindows" )
  numberOfTimesByWindows = prop( samplingTimeConstraints, "numberOfTimesByWindows" )
  intervalsConstraints = list()

  # Columns: window min/max, delta (= minSampling), n (= times per window).
  minSamplingAndNumberOfTimesByWindows = as.data.frame( list( minSampling, numberOfTimesByWindows ) )
  data = t( as.data.frame( samplingsWindow ) )
  inputRandomSpaced = as.data.frame( do.call( "cbind", list( data, minSamplingAndNumberOfTimesByWindows ) ) )

  colnames( inputRandomSpaced ) = c("min","max","delta","n")
  rownames( inputRandomSpaced ) = NULL

  for( iter in seq_len( length( inputRandomSpaced$n ) ) )
  {
    min = inputRandomSpaced$min[iter]
    max = inputRandomSpaced$max[iter]
    delta = inputRandomSpaced$delta[iter]
    n = inputRandomSpaced$n[iter]

    # Slack after reserving (n-1) minimum gaps; spread uniforms into that slack.
    distance = max-min-(n-1)*delta

    ind = runif(n,0,1)
    tmp = distance*sort( ind )
    interval = min + tmp + delta * seq(0,n-1,1)

    intervalsConstraints[[iter]] = interval
  }

  return( unlist( intervalsConstraints ) )
}

#' Check sampling feasibility for PSO, PGBO or simplex.
#'
#' Returns two logicals: whether each window contains exactly
#' \code{numberOfTimesByWindows} points, and whether consecutive points inside
#' each window respect \code{minSampling}.
#' @name checkSamplingTimeConstraintsForMetaheuristic
#' @return List with \code{constraintWindowsLength} and \code{constraintMinimalSampling}.
#' @usage NULL
#' @export

method( checkSamplingTimeConstraintsForMetaheuristic, list( SamplingTimeConstraints, Arm ) ) = function( samplingTimesConstraints, arm, newSamplings, outcome ) {

  armName = prop(arm, 'name')

  minSampling = prop( samplingTimesConstraints, "minSampling")
  samplingsWindow =  prop( samplingTimesConstraints, "samplingsWindows")
  numberOfTimesByWindows =  prop( samplingTimesConstraints, "numberOfTimesByWindows")

  minSamplingAndNumberOfTimesByWindows = as.data.frame( list( minSampling, numberOfTimesByWindows ) )
  data = t( as.data.frame(samplingsWindow ) )
  inputRandomSpaced = as.data.frame( do.call( "cbind", list( data, minSamplingAndNumberOfTimesByWindows ) ) )
  colnames( inputRandomSpaced ) = c("min","max","delta","n")
  rownames( inputRandomSpaced ) = NULL

  testForConstraintsWindowsLength = list()
  testForConstraintsMinimalSampling = list()

  for( iter in seq_len( length( inputRandomSpaced$n ) ) )
  {
    min = inputRandomSpaced$min[iter]
    max = inputRandomSpaced$max[iter]

    # Points falling in this window (order preserved from newSamplings).
    testForConstraintsWindowsLength[[ armName ]][[ outcome ]][[iter]] = newSamplings[ newSamplings >= min & newSamplings <= max ]

    testForConstraintsMinimalSampling[[ armName ]][[ outcome ]][[iter]] = diff( testForConstraintsWindowsLength[[ armName ]][[ outcome ]][[ iter ]] )

    # Single-point windows have empty diff(); treat as spacing OK.
    if ( length( testForConstraintsMinimalSampling[[ armName ]][[ outcome ]][[iter]] ) == 0 )
    {
      testForConstraintsMinimalSampling[[ armName ]][[ outcome ]][[iter]] = 0
    }
  }

  testForConstraintsWindowsLengthtmp = map_int( testForConstraintsWindowsLength[[armName]][[outcome]], ~ length(.x) )

  if ( all( testForConstraintsWindowsLengthtmp == numberOfTimesByWindows ) )
  {
    constraintWindowsLength = TRUE
  }else{
    constraintWindowsLength = FALSE
  }

  testForConstraintsMinimalSamplingTmp = map_dbl(testForConstraintsMinimalSampling[[armName]][[outcome]], ~ min(.x) )

  if ( all( testForConstraintsMinimalSamplingTmp >= minSampling ) )
  {
    constraintMinimalSampling = TRUE
  }else{
    constraintMinimalSampling = FALSE
  }
  return( list( constraintWindowsLength = constraintWindowsLength, constraintMinimalSampling = constraintMinimalSampling ) )
}
