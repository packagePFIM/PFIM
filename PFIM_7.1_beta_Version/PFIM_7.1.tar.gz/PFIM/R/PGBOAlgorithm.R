#' @title PGBOAlgorithm
#' @description
#' Population-based global optimization for sampling times (Rcpp kernel).
#' Pass \code{N}, \code{muteEffect}, \code{maxIteration}, \code{purgeIteration}, and
#' \code{seed} via \code{optimizerParameters} on \code{\link{Optimization}}.
#' Optional \code{fitBase} (default \code{0.03}) and \code{cauchyProb} (default \code{0.8},
#' probability of a Cauchy jump vs Gaussian group mutation).
#' Optional \code{tolerance} (default \code{0}, disabled) and \code{stallIterations}
#' (default \code{5}) enable early stopping.
#' @param optimizerOutputs List filled by \code{optimizeDesign()} (optimal arms, etc.).
#' @return A \code{PGBOAlgorithm} specification object.
#' @examples
#' \dontrun{
#' vignette("Example02")
#' }
#' @include Optimization.R
#' @export

PGBOAlgorithm = new_class( "PGBOAlgorithm", package = "PFIM",
                           properties = list(
                             optimizerOutputs = new_property( class_list, default = list() )
                           ) )
S4_register( PGBOAlgorithm )

#' Population Genetics Based Optimization kernel (Rcpp).
#'
#' Compiled implementation in \code{src/PGBOAlgorithm.cpp}. FIM evaluation and
#' per-group constraint checks are R callbacks.
#'
#' @name pgbo_optimize_Rcpp
#' @return A list of optimization results.
#' @keywords internal
NULL

#' PGBO continuous D-optimal design (delegates to multi-design driver).
#'
#' @param optimizationObject An \code{\link{Optimization}} project.
#' @param optimizationAlgorithm A \code{PGBOAlgorithm} instance.
#' @return Updated \code{Optimization} after optimizing each design in turn.
#' @name optimizeDesign
#' @export

method( optimizeDesign, list( Optimization, PGBOAlgorithm ) ) = function( optimizationObject, optimizationAlgorithm ) {
  .pfimContinuousOptimizeDesigns(
    optimizationObject,
    optimizationAlgorithm,
    .optimizePGBOOneDesign
  )
}

#' Run PGBO on a single design: flat sampling vector, C++ population genetics loop.
#'
#' Sets the RNG from \code{optimizerParameters$seed} and restores
#' \code{.Random.seed} on exit (\code{NULL} seed leaves the stream unchanged).
#' \code{eval_d} returns the D-criterion (invalid designs map to a tiny sentinel
#' inside the flat-design helper); the C++ kernel minimises \code{1/D}.
#' @param optimizationObject Parent \code{Optimization}.
#' @param optimizationAlgorithm \code{PGBOAlgorithm} instance.
#' @return List with optimal arms / design pieces for the continuous driver.
#' @noRd
#' @keywords internal
.optimizePGBOOneDesign = function( optimizationObject, optimizationAlgorithm ) {

  optimizerParameters = projectProp( optimizationObject, "optimizerParameters" )
  restore_seed = .pfimLocalSeed( optimizerParameters$seed )
  on.exit( restore_seed(), add = TRUE )

  prep = .pfimPrepareContinuousDesign( optimizationObject )
  design = prep$design
  arms   = prep$arms

  prop( design, "arms" ) = .pfimSeedArmsFromConstraints( arms )
  initialDesign = .pfimCloneS7( design )

  layout       = .buildFlatSamplingLayout( design )
  evalTemplate = .evaluationFromOptimization( optimizationObject, initialDesign, name = "" )

  eval_d = function( flat_pos ) {
    .pfimFlatDesignDcriterion( evalTemplate, initialDesign, arms, flat_pos )
  }

  cauchyProb = optimizerParameters$cauchyProb %||% 0.8
  if ( !is.numeric( cauchyProb ) || length( cauchyProb ) != 1L ||
       cauchyProb <= 0 || cauchyProb >= 1 )
    stop( "PGBOAlgorithm: cauchyProb must be in (0, 1). Default: 0.8", call. = FALSE )

  res_cpp = pgbo_optimize_Rcpp(
    initial_pos       = layout$initial_flat,
    sorting_groups    = layout$sorting_groups,
    max_iteration     = as.integer( optimizerParameters$maxIteration ),
    N                 = as.integer( optimizerParameters$N ),
    mute_effect       = optimizerParameters$muteEffect,
    purge_iteration   = as.integer( optimizerParameters$purgeIteration ),
    fit_base          = optimizerParameters$fitBase %||% 0.03,
    max_attempts      = 10000L,
    cauchy_prob       = cauchyProb,
    show_process      = optimizerParameters$showProcess,
    eval_d            = eval_d,
    check_valid_group = function( flat_pos, group_id ) {
      .checkFlatValidGroup( layout, flat_pos, group_id )
    },
    ftol             = optimizerParameters$tolerance %||% 0,
    stall_iterations = as.integer( optimizerParameters$stallIterations %||% 5L )
  )

  finalArms     = .applyFlatToArms( res_cpp$bestDesign, arms )
  optimalDesign = .pfimOptimalDesignFrom( initialDesign, finalArms )

  .pfimStoreContinuousOptimization(
    optimizationObject, optimizationAlgorithm,
    initialDesign, optimalDesign,
    optimizerOutputs = list(
      optimalArms         = finalArms,
      pgboAlgorithmOutput = res_cpp[ c( "bestD", "initialD", "converged", "iterations", "improved" ) ]
    ),
    finalArms = finalArms
  )
}

#' Constraint tables for optimization reports
#' @name constraintsTableForReport
#' @export

method( constraintsTableForReport, PGBOAlgorithm ) = function( optimizationAlgorithm, arms ) {
  .pfimConstraintsTableContinuous( optimizationAlgorithm, arms )
}
