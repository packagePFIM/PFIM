#' Buffer lengths for the Fedorov-Wynn C++ interface.
#'
#' \code{nMaxPop} is the classical Carathéodory bound on support size
#' (\eqn{p(p+1)/2 + 1}). \code{nBuf} is large enough for the active protocol
#' vectors passed to / from Rcpp.
#' @param ndimFim FIM dimension \eqn{p}.
#' @param nProtocols Number of candidate protocols on the discrete grid.
#' @return List with \code{nMaxPop}, \code{nFisher}, \code{nBuf}.
#' @noRd
#' @keywords internal
.fedorovWynnBufferSizes = function( ndimFim, nProtocols ) {
  ndimFim    = as.integer( ndimFim )
  nProtocols = as.integer( nProtocols )
  nMaxPop    = ndimFim * ( ndimFim + 1L ) / 2L + 1L
  nFisher    = ndimFim * ( ndimFim + 1L ) / 2L
  nBuf       = max( nProtocols * 2L, nMaxPop )
  list( nMaxPop = nMaxPop, nFisher = nFisher, nBuf = nBuf )
}

#' Fedorov-Wynn algorithm in Rcpp.
#' @param protocols List of elementary protocols.
#' @param ndimen    Integer vector of dimensions.
#' @param nbprot    Integer vector of protocol counts.
#' @param numprot   Integer vector of protocol indices.
#' @param freq      Numeric vector of frequencies.
#' @param nbdata    Integer vector of data counts.
#' @param vectps    Numeric vector of sampling times.
#' @param fisher    Numeric vector of Fisher information values.
#' @param error     Integer error/status code.
#' @param protdep   Integer protocol-dependence flags.
#' @param freqdep   Numeric frequency-dependence values.
#' @return A list with the results of the Fedorov-Wynn algorithm.
#' @name FedorovWynnAlgorithm_Rcpp
#' @keywords internal
NULL

#' Bar chart for algorithm weights / frequencies.
#' @noRd
#' @keywords internal
.algoBars = function( data, x, y, xlab = x, ylab = y, ylim = NULL, breaks = NULL ) {
  y_max = if ( is.null( ylim ) ) max( data[[ y ]], 1 ) else ylim[2]
  y_min = if ( is.null( ylim ) ) 0 else ylim[1]
  scale_y = if ( is.null( breaks ) ) {
    scale_y_continuous( limits = c( y_min, y_max ), expand = expansion( mult = c( 0, 0.06 ) ) )
  } else {
    scale_y_continuous( limits = c( y_min, y_max ), breaks = breaks, expand = expansion( mult = c( 0, 0.06 ) ) )
  }
  ggplot( data, aes( x = stats::reorder( .data[[ x ]], .data[[ y ]] ), y = .data[[ y ]] ) ) +
    geom_bar( stat = "identity", fill = "gray50" ) +
    scale_y +
    scale_x_discrete( expand = c( 0, 0 ) ) +
    labs( x = xlab, y = ylab ) +
    coord_flip( clip = "off" ) +
    theme_minimal( base_size = 14 ) +
    theme(
      plot.title   = element_text( hjust = 0.5, face = "bold" ),
      axis.title   = element_text( color = "black" ),
      axis.text    = element_text( color = "black" ),
      panel.grid.major.x = element_line( color = "gray90", linewidth = 0.5 ),
      panel.grid.major.y = element_blank(),
      panel.border = element_rect( color = "gray80", fill = NA, linewidth = 0.5 ),
      plot.margin  = margin( 5.5, 12, 5.5, 5.5, "pt" )
    )
}

#' FedorovWynnAlgorithm: S7 class
#' @title FedorovWynnAlgorithm
#' @description
#' Fedorov-Wynn exchange algorithm for D-optimal sampling-time design (Rcpp kernel).
#' Pass \code{elementaryProtocols}, \code{numberOfSubjects}, and
#' \code{proportionsOfSubjects} via \code{optimizerParameters} on \code{\link{Optimization}}.
#' @param FedorovWynnAlgorithmOutputs Output list from the Rcpp routine.
#' @return A \code{FedorovWynnAlgorithm} specification object for \code{run(Optimization)}.
#' @examples
#' \dontrun{
#' vignette("Example01")
#' }
#' @include Optimization.R
#' @export

FedorovWynnAlgorithm = new_class( "FedorovWynnAlgorithm",
                                  package    = "PFIM",
                                  properties = list(
                                    FedorovWynnAlgorithmOutputs = new_property( class_list, default = list() )
                                  )
)
S4_register( FedorovWynnAlgorithm )

plotFrequenciesFedorovWynnAlgorithm = new_generic(
  "plotFrequenciesFedorovWynnAlgorithm",
  c( "optimization", "optimizationAlgorithm" )
)

#' Fedorov-Wynn discrete D-optimal design (Rcpp kernel).
#'
#' Pipeline: enumerate constraint-grid FIMs → match each
#' \code{elementaryProtocols} seed to a full grid row → call C++ exchange →
#' map frequencies to arms → re-evaluate initial vs optimal designs.
#'
#' @param optimizationObject An \code{\link{Optimization}} project.
#' @param optimizationAlgorithm A \code{FedorovWynnAlgorithm} instance.
#' @return The same \code{Optimization} with \code{optimisationDesign} and
#'   \code{optimisationAlgorithmOutputs} filled.
#' @name optimizeDesign
#' @export

method( optimizeDesign, list( Optimization, FedorovWynnAlgorithm ) ) =
  function( optimizationObject, optimizationAlgorithm ) {

    p                          = projectProp( optimizationObject, "optimizerParameters" )
    showProcess                = isTRUE( p$showProcess )
    initialSamplings           = p$elementaryProtocols
    totalNumberOfIndividuals   = p$numberOfSubjects
    proportionsOfSubjects      = p$proportionsOfSubjects
    totalCost                  = as.numeric( totalNumberOfIndividuals )

    design          = projectProp( optimizationObject, "designs" )[[ 1L ]]
    initialDesign   = .pfimCloneS7( design )
    optimalDesign   = .pfimCloneS7( design )
    designName      = prop( design, "name" )

    # One FIM (+ sampling row) per dose × sampling combination under constraints.
    fimsFromConstraints = generateFimsFromConstraints( optimizationObject )

    # Stack list-of-rows into matrices expected by FedorovWynnAlgorithm_Rcpp.
    samplingsForFedorovWynn = reduce( fimsFromConstraints$samplingsForFedorovWynnAlgo[[ designName ]], rbind )
    fisherMatrices          = reduce( fimsFromConstraints$listFimsAlgoFW[[            designName ]], rbind )
    listArms                = fimsFromConstraints$listArms[[ designName ]]

    nProtocols = nrow( samplingsForFedorovWynn )
    nTimes     = ncol( samplingsForFedorovWynn )
    ndimFim    = fimsFromConstraints$dimFim

    elementaryProtocolsFW = list(
      numberOfprotocols = nProtocols,
      numberOfTimes     = nTimes,
      nbOfDimensions    = ndimFim,
      totalCost         = totalCost,
      samplingTimes     = samplingsForFedorovWynn,
      fisherMatrices    = fisherMatrices
    )

    ndimen  = c( nProtocols, ndimFim, totalCost )
    npInit  = nProtocols
    buf     = .fedorovWynnBufferSizes( ndimFim, nProtocols )
    nMaxPop = buf$nMaxPop
    nFisher = buf$nFisher
    nBuf    = buf$nBuf

    # Pre-allocate C++ output buffers (filled in place by the kernel).
    numprot = rep( 0, nBuf )
    freq    = rep( 0, nBuf )
    nbdata  = rep( 0, nBuf )
    vectps  = rep( 0, nBuf )
    fisher  = rep( 0, nFisher )
    nok     = 0L

    # Match each user-supplied elementary protocol to one full row of the
    # sampling grid. Do NOT unlist() all protocols into a single vector: that
    # only compares every grid row against the first seed (broken multi-start).
    # Order of indexElemProt must match proportionsOfSubjects for the C++ init.
    if ( !is.list( initialSamplings ) || !length( initialSamplings ) )
      stop( "Fedorov-Wynn: elementaryProtocols must be a non-empty list.", call. = FALSE )
    if ( length( proportionsOfSubjects ) != length( initialSamplings ) )
      stop(
        "Fedorov-Wynn: proportionsOfSubjects length (", length( proportionsOfSubjects ),
        ") must match elementaryProtocols length (", length( initialSamplings ), ").",
        call. = FALSE
      )

    indexElemProt = vapply( seq_along( initialSamplings ), function( i ) {
      protocol = as.numeric( unlist( initialSamplings[[ i ]], use.names = FALSE ) )
      if ( length( protocol ) != nTimes )
        stop(
          "Fedorov-Wynn: elementary protocol ", i, " has length ", length( protocol ),
          " but the sampling grid has ", nTimes, " times.",
          call. = FALSE
        )
      # Exact row match: all nTimes columns equal the protocol vector.
      hits = which(
        rowSums(
          samplingsForFedorovWynn ==
            matrix( protocol, nProtocols, nTimes, byrow = TRUE )
        ) == nTimes
      )
      if ( !length( hits ) )
        stop(
          "Fedorov-Wynn: elementary protocol ", i,
          " was not found in the sampling grid: (",
          paste( protocol, collapse = ", " ), ").",
          call. = FALSE
        )
      as.integer( hits[[ 1L ]] )
    }, integer( 1L ) )
    nElemProt = length( indexElemProt )

    # C++ layout: zeprot[0] = support size, then 1-based-ready grid indices;
    # zefreq[0..(n-1)] = initial simplex weights (proportionsOfSubjects).
    zeprot = c( nElemProt, indexElemProt )
    zefreq = rep( 0, nBuf )
    zefreq[ seq_len( length( proportionsOfSubjects ) ) ] = proportionsOfSubjects

    if ( showProcess )
      message( "Fedorov-Wynn exchange algorithm started" )

    output = FedorovWynnAlgorithm_Rcpp(
      elementaryProtocolsFW, ndimen, npInit,
      numprot, freq, nbdata, vectps, fisher, nok,
      zeprot, zefreq, showProcess
    )

    # Parse outputs
    if ( !identical( output$status, "success" ) )
      stop( "Fedorov-Wynn algorithm failed: ", output$status, ".", call. = FALSE )

    if ( showProcess )
      message( "Fedorov-Wynn exchange algorithm finished" )

    activeFreq       = output$freq[ output$freq > 0 ]
    indexOptimalArms = output$numprot[ output$numprot > 0 ]
    freq_sum         = sum( activeFreq )

    if ( length( activeFreq ) == 0L || abs( freq_sum - 1 ) > 1e-4 )
      stop(
        "Fedorov-Wynn algorithm did not converge (sum(freq) = ", round( freq_sum, 6 ), ").",
        call. = FALSE
      )

    optimalFrequencies = activeFreq
    listArms           = listArms[ indexOptimalArms ]
    # Convert simplex frequencies to subject counts (may be non-integer before setOptimalArms).
    numberOfIndividuals      = as.double( p$numberOfSubjects * optimalFrequencies )

    prop( optimizationAlgorithm, "FedorovWynnAlgorithmOutputs" ) = list(
      listArms            = listArms,
      optimalFrequencies  = optimalFrequencies,
      numberOfIndividuals = numberOfIndividuals
    )

    # Population FIM allocates sizes from numberOfIndividuals; individual keeps size 1.
    fim         = projectProp( optimizationObject, "fim" )
    optimalArms = setOptimalArms( fim, optimizationAlgorithm )
    prop( optimalDesign, "arms" ) = map( optimalArms, ~ .x$arm )

    .pfimOptimizationCacheFlush()

    # Re-evaluate full FIM pipeline on initial vs optimal designs for reports / D-criterion.
    evaluationsToRun = list(
      .evaluationFromOptimization( optimizationObject, optimalDesign ),
      .evaluationFromOptimization( optimizationObject, initialDesign )
    )
    evaluationResults = .pfimRunEvaluations( evaluationsToRun )

    prop( optimizationObject, "optimisationDesign" ) = list(
      evaluationInitialDesign = evaluationResults[[ 2L ]],
      evaluationOptimalDesign = evaluationResults[[ 1L ]]
    )
    prop( optimizationObject, "optimisationAlgorithmOutputs" ) = list(
      optimizationAlgorithm = optimizationAlgorithm,
      optimalArms           = optimalArms,
      frequencies           = optimalFrequencies
    )

    optimizationObject
  }

#' Frequency trajectories of the Fedorov-Wynn algorithm
#' @name plotFrequenciesFedorovWynnAlgorithm
#' @return A \code{ggplot2} plot object.
#' @examples
#' \dontrun{
#' # help(plotFrequenciesFedorovWynnAlgorithm); vignette("Example01")
#' }
#' @export

method( plotFrequenciesFedorovWynnAlgorithm,
        list( Optimization, FedorovWynnAlgorithm ) ) =
  function( optimization, optimizationAlgorithm ) {

    out  = prop( optimization, "optimisationAlgorithmOutputs" )
    data = data.frame(
      arm       = map_chr( out$optimalArms, ~ prop( .x$arm, "name" ) ),
      frequency = out$frequencies
    )
    .algoBars( data, x = "arm", y = "frequency", xlab = "Arm", ylab = "Frequency" )
  }

#' Constraint tables for optimization reports
#' @name constraintsTableForReport
#' @export

method( constraintsTableForReport, FedorovWynnAlgorithm ) =
  function( optimizationAlgorithm, arms ) {
    .pfimConstraintsTableDiscrete( optimizationAlgorithm, arms )
  }
