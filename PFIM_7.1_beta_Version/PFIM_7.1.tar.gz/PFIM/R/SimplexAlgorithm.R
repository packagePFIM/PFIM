#' @title SimplexAlgorithm
#' @description
#' Nelder-Mead (amoeba) optimization for sampling times (Rcpp kernel).
#' Pass \code{pctInitialSimplexBuilding}, \code{tolerance}, and \code{maxIteration}
#' via \code{optimizerParameters} on \code{\link{Optimization}}.
#' @param optimizerOutputs List filled by \code{optimizeDesign()} (optimal arms, etc.).
#' @return A \code{SimplexAlgorithm} specification object.
#' @examples
#' \dontrun{
#' vignette("Example02")
#' }
#' @include Optimization.R
#' @export

SimplexAlgorithm = new_class( "SimplexAlgorithm", package = "PFIM",
                              properties = list(
                                optimizerOutputs = new_property( class_list, default = list() )
                              ) )
S4_register( SimplexAlgorithm )

fisherSimplex = new_generic( "fisherSimplex", c( "optimizationObject" ) )

#' Nelder-Mead simplex minimiser (Rcpp).
#'
#' Compiled implementation in \code{src/SimplexAlgorithm.cpp}.
#' The objective \code{funk} remains an R callback
#' (\code{fisherSimplex}) because FIM evaluation stays in R.
#'
#' @param p Numeric matrix of simplex vertices (rows).
#' @param y Numeric vector of objective values at vertices.
#' @param ftol Relative tolerance on the spread of \code{y}.
#' @param itmax Maximum number of iterations.
#' @param funk R function \code{funk(data, pr, outcomes)}.
#' @param outcomes Outcome structure passed to \code{funk}.
#' @param data Optimization object passed to \code{funk}.
#' @param show_process Logical; print progress.
#' @return List with \code{p}, \code{y}, \code{iter}, \code{converge}, \code{results}.
#' @name fun_amoeba_Rcpp
#' @keywords internal
NULL

#' Simplex objective: map a flat vertex to \code{1/D} (invalid → large penalty).
#'
#' Called from C++ \code{fun_amoeba_Rcpp} for each Nelder-Mead reflection/expansion.
#' Multi-design projects evaluate every design but return only the first design's
#' cost (multi-design continuous path runs one design per outer call).
#' @name fisherSimplex
#' @return Numeric cost vector (length 1 in the usual single-design path).
#' @export

method( fisherSimplex, Optimization ) = function( optimizationObject, simplex, outcomes )
{
  designs = projectProp( optimizationObject, "designs" )
  simplex_hash = split( unname( simplex ), names( simplex ) )

  dCrit_list = map_dbl( designs, function( design ) {
    design = .pfimCloneS7( design )
    designName = prop( design, "name" )

    arms_processed = map( prop( design, "arms" ), function( arm ) {
      arm = .pfimCloneS7( arm )
      armName = prop( arm, "name" )
      constraints = prop( arm, "samplingTimesConstraints" )
      times = prop( arm, "samplingTimes" )

      valid = map_lgl( outcomes[[ armName ]], function( outcome ) {
        key = .pfimSimplexColumnKey( designName, armName, outcome )
        samplings = simplex_hash[[ key ]]
        samplings = samplings[ !is.na( samplings ) ]
        constraint = keep( constraints, ~ prop( .x, "outcome" ) == outcome ) |> pluck( 1L )
        if ( is.null( constraint ) )
          return( TRUE )
        checks = checkSamplingTimeConstraintsForMetaheuristic(
          constraint, arm, samplings, outcome
        )
        all( unlist( checks, use.names = FALSE ) )
      } )

      updated = map( times, function( st ) {
        st = .pfimCloneS7( st )
        outcome = prop( st, "outcome" )
        if ( outcome %in% outcomes[[ armName ]] ) {
          key = .pfimSimplexColumnKey( designName, armName, outcome )
          prop( st, "samplings" ) = simplex_hash[[ key ]]
        }
        st
      } )

      prop( arm, "samplingTimes" ) = updated
      list( arm = arm, valid = all( valid ) )
    } )

    prop( design, "arms" ) = map( arms_processed, "arm" )
    if ( !all( map_lgl( arms_processed, "valid" ) ) )
      return( .metaheuristicFitnessPenalty )

    fim = prop( .pfimRunOptimizationEvaluation( optimizationObject, design, name = "" ), "fim" )
    d = as.numeric( Dcriterion( fim ) )
    if ( !is.finite( d ) || d <= 0 ) .metaheuristicFitnessPenalty else 1 / d
  } )

  dCrit = dCrit_list[ 1L ]
  bad = !is.finite( dCrit ) | dCrit <= 0
  dCrit[ bad ] = .metaheuristicFitnessPenalty
  dCrit
}

#' Nelder-Mead continuous D-optimal design (delegates to multi-design driver).
#'
#' @param optimizationObject An \code{\link{Optimization}} project.
#' @param optimizationAlgorithm A \code{SimplexAlgorithm} instance.
#' @return Updated \code{Optimization} after optimizing each design in turn.
#' @name optimizeDesign
#' @export

method( optimizeDesign, list( Optimization, SimplexAlgorithm ) ) = function( optimizationObject, optimizationAlgorithm )
{
  .pfimContinuousOptimizeDesigns(
    optimizationObject,
    optimizationAlgorithm,
    .optimizeSimplexOneDesign
  )
}

#' @noRd
#' @keywords internal
.optimizeSimplexOneDesign = function( optimizationObject, optimizationAlgorithm )
{
  optimizerParameters = projectProp( optimizationObject, "optimizerParameters" )
  showProcess = optimizerParameters$showProcess
  pctInitialSimplexBuilding = optimizerParameters$pctInitialSimplexBuilding
  tolerance = optimizerParameters$tolerance
  maxIteration = optimizerParameters$maxIteration

  prep = .pfimPrepareContinuousDesign( optimizationObject )
  design        = prep$design
  initialDesign = .pfimCloneS7( design )
  arms          = prep$arms
  designName    = prop( design, "name" )
  outcomes      = .pfimArmOutcomesMap( arms )

  simplex_data = map( arms, function( arm ) {
    armName = prop( arm, "name" )
    constraints = prop( arm, "samplingTimesConstraints" )
    map( outcomes[[ armName ]], function( outcome ) {
      constraint = keep( constraints, ~ prop( .x, "outcome" ) == outcome ) |> pluck( 1L )
      samplings = prop( constraint, "initialSamplings" )
      data.frame(
        name  = rep( .pfimSimplexColumnKey( designName, armName, outcome ), length( samplings ) ),
        value = samplings,
        stringsAsFactors = FALSE
      )
    } ) |> list_rbind()
  } ) |> list_rbind()

  vectorizedSamplings = simplex_data$value
  namesSamplingsSimplex = simplex_data$name
  n_vars = length( vectorizedSamplings )

  samplingsSimplex = matrix( rep( vectorizedSamplings, n_vars + 1L ), ncol = n_vars, byrow = TRUE )
  colnames( samplingsSimplex ) = namesSamplingsSimplex
  samplingsSimplex = t( apply(
    samplingsSimplex, 1L, .sortSimplexRowByGroup, col_names = namesSamplingsSimplex
  ) )

  diag_indices = matrix( c( 2:( n_vars + 1L ), seq_len( n_vars ) ), ncol = 2L )
  samplingsSimplex[ diag_indices ] = samplingsSimplex[ diag_indices ] * ( 1 - pctInitialSimplexBuilding / 100 )

  # Resolve the S7 method once; the C++ loop calls this function many times.
  pure_fisher_func = method( fisherSimplex, Optimization )
  y = map_dbl(
    seq_len( nrow( samplingsSimplex ) ),
    ~ pure_fisher_func( optimizationObject, samplingsSimplex[ .x, ], outcomes )
  )

  opti = fun_amoeba_Rcpp(
    samplingsSimplex, y, tolerance, maxIteration,
    pure_fisher_func, optimizationObject, outcomes, showProcess
  )

  best_row = which( opti$y == min( opti$y ) )[ 1L ]
  flat_best = split( unname( opti$p[ best_row, ] ), names( opti$p[ best_row, ] ) )

  finalArms = map( prop( initialDesign, "arms" ), function( arm ) {
    arm = .pfimCloneS7( arm )
    armName = prop( arm, "name" )
    times = map( outcomes[[ armName ]], function( outcome ) {
      key = .pfimSimplexColumnKey( designName, armName, outcome )
      samplings = flat_best[[ key ]]
      samplings = samplings[ !is.na( samplings ) ]
      SamplingTimes( outcome, samplings = samplings )
    } )
    prop( arm, "samplingTimes" ) = times
    arm
  } )

  optimalDesign = .pfimOptimalDesignFrom( initialDesign, finalArms )

  .pfimStoreContinuousOptimization(
    optimizationObject, optimizationAlgorithm,
    initialDesign, optimalDesign,
    optimizerOutputs = list( optimalArms = finalArms ),
    finalArms = finalArms
  )
}

#' Constraint tables for optimization reports
#' @name constraintsTableForReport
#' @export

method( constraintsTableForReport, SimplexAlgorithm ) = function( optimizationAlgorithm, arms ) {
  .pfimConstraintsTableContinuous( optimizationAlgorithm, arms )
}

#' Sort each simplex row within arm/outcome groups (not across the full row).
#' @noRd
#' @keywords internal
.sortSimplexRowByGroup = function( row, col_names ) {
  for ( grp in unique( col_names ) ) {
    idx = which( col_names == grp )
    row[ idx ] = sort( row[ idx ] )
  }
  row
}

#' Stable column name for one outcome's sampling vector in the simplex matrix.
#' @noRd
#' @keywords internal
.pfimSimplexColumnKey = function( designName, armName, outcome ) {
  toString( c( designName, armName, outcome ) )
}
