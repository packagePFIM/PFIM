#' @title Fim
#' @description
#' Base class for Fisher information matrices (\code{PopulationFim},
#' \code{IndividualFim}, \code{BayesianFim}).
#' @param fisherMatrix Labelled FIM matrix.
#' @param fixedEffects Fixed-effects sub-block.
#' @param varianceEffects Variance-effects sub-block.
#' @param SEAndRSE List with \code{SE}, \code{RSE}, and combined tables.
#' @param condNumberFixedEffects Condition number of the fixed-effects block.
#' @param condNumberVarianceEffects Condition number of the variance-effects block.
#' @param shrinkage Named shrinkage (percent) per parameter (Bayesian FIM).
#' @param singularFim \code{TRUE} when SE/RSE used a pseudo-inverse (singular FIM).
#' @return An S7 object holding FIM matrices, SE/RSE tables, and condition numbers.
#' @export

Fim = new_class( "Fim", package = "PFIM",
                 properties = list(
                   fisherMatrix              = new_property( class_double,  default = numeric( 0 ) ),
                   fixedEffects              = new_property( class_double,  default = numeric( 0 ) ),
                   varianceEffects           = new_property( class_double,  default = numeric( 0 ) ),
                   SEAndRSE                  = new_property( class_list,    default = list()        ),
                   condNumberFixedEffects    = new_property( class_double,  default = 0.0           ),
                   condNumberVarianceEffects = new_property( class_double,  default = 0.0           ),
                   shrinkage                 = new_property( class_double,  default = numeric( 0 )  ),
                   singularFim               = new_property( class_logical, default = FALSE         )
                 )
)

# S7 generics
#' @name evaluateFim
#' @return The updated \code{Fim} object after evaluation.
#' @keywords internal
evaluateFim                = new_generic( "evaluateFim",                c( "fim", "model", "arm" ) )

#' @name evaluateVarianceFIM
#' @return A variance contribution matrix for the FIM.
#' @keywords internal
evaluateVarianceFIM        = new_generic( "evaluateVarianceFIM",        c( "fim", "model", "arm" ) )

#' Attach evaluated FIM results to a project
#' @param fim A \code{Fim} object.
#' @param ... Method arguments (see methods).
#' @usage setEvaluationFim(fim, ...)
#' @name setEvaluationFim
#' @return The modified \code{Fim} object.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' setEvaluationFim(prop(ev, "fim"), ev)
#' }
#' @export
setEvaluationFim           = new_generic( "setEvaluationFim",           "fim"                      )

#' Optimal arms from design optimization
#' @param fim A \code{Fim} object.
#' @param optimizationAlgorithm Optimizer object from \code{run(Optimization)}.
#' @param ... Not used by current methods.
#' @usage setOptimalArms(fim, optimizationAlgorithm, ...)
#' @name setOptimalArms
#' @return The modified \code{Fim} object.
#' @export
setOptimalArms             = new_generic( "setOptimalArms",             c( "fim", "optimizationAlgorithm" ) )
Dcriterion                 = new_generic( "Dcriterion",                 "fim"                      )

#' Print FIM summaries to the console
#' @param fim A \code{Fim} object.
#' @param ... Not used by current methods.
#' @usage showFIM(fim, ...)
#' @name showFIM
#' @return Invisibly, the input \code{Fim} object.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' showFIM(prop(ev, "fim"))
#' }
#' @export
showFIM                    = new_generic( "showFIM",                    "fim"                      )

#' Plot standard errors from a FIM
#' @param fim A \code{Fim} object.
#' @param evaluation A \code{PFIMProject} evaluation object.
#' @param ... Graphics parameters passed to \code{ggplot2}.
#' @usage plotSEFIM(fim, evaluation, ...)
#' @name plotSEFIM
#' @return A \code{ggplot2} plot object.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' plotSEFIM(prop(ev, "fim"), ev)
#' }
#' @export
plotSEFIM                  = new_generic( "plotSEFIM",                  c( "fim", "evaluation" )   )

#' Plot relative standard errors from a FIM
#' @param fim A \code{Fim} object.
#' @param evaluation A \code{PFIMProject} evaluation object.
#' @param ... Graphics parameters passed to \code{ggplot2}.
#' @usage plotRSEFIM(fim, evaluation, ...)
#' @name plotRSEFIM
#' @return A \code{ggplot2} plot object.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' plotRSEFIM(prop(ev, "fim"), ev)
#' }
#' @export
plotRSEFIM                 = new_generic( "plotRSEFIM",                 c( "fim", "evaluation" )   )

#' Plot Bayesian shrinkage from a FIM
#' @param fim A \code{BayesianFim} object.
#' @param evaluation A \code{PFIMProject} evaluation object.
#' @param ... Graphics parameters passed to \code{ggplot2}.
#' @usage plotShrinkage(fim, evaluation, ...)
#' @name plotShrinkage
#' @export
plotShrinkage              = new_generic( "plotShrinkage",              c( "fim", "evaluation" )   )

#' FIM tables for HTML reports
#' @param fim A \code{Fim} object.
#' @param evaluation A \code{PFIMProject} evaluation object.
#' @param ... Not used by current methods.
#' @usage tablesForReport(fim, evaluation, ...)
#' @name tablesForReport
#' @return Report tables as a list or data frame.
#' @export
tablesForReport            = new_generic( "tablesForReport",            c( "fim", "evaluation" )   )

#' Generate an evaluation report from FIM results
#' @param fim A \code{Fim} object.
#' @param ... Report paths and options (see methods).
#' @usage generateReportEvaluation(fim, ...)
#' @name generateReportEvaluation
#' @return Invisibly, the generated report path or render result.
#' @export
generateReportEvaluation   = new_generic( "generateReportEvaluation",   "fim"                      )

#' Generate an optimization report from FIM results
#' @param fim A \code{Fim} object.
#' @param optimizationAlgorithm Optimizer object with optimal design outputs.
#' @param ... Report paths and options (see methods).
#' @usage generateReportOptimization(fim, optimizationAlgorithm, ...)
#' @name generateReportOptimization
#' @return Invisibly, the generated report path or render result.
#' @export
generateReportOptimization = new_generic( "generateReportOptimization", c( "fim", "optimizationAlgorithm" ) )

# Greek labels (mu, beta, omega, gamma, sigma) for all FIM subclasses.

.greekConsole = c(
  mu    = "\u03bc_",
  beta  = "\u03b2_",
  omega = "\u03c9\u00B2_",
  gamma = "\u03b3\u00B2_",
  sigma = "\u03c3\u00B2_"
)

.greekPlotmath = c(
  mu    = "mu",
  beta  = "beta",
  omega = "omega^2",
  gamma = "gamma^2",
  sigma = "sigma^2"
)

#' Plotmath facet labels for SE/RSE bar charts (device-independent Greek).
#' @noRd
#' @keywords internal
.pfimSeRseFacetLabel = function( metric, key ) {
  g <- .greekPlotmath[[ key ]]
  if ( is.null( g ) || !nzchar( g ) )
    stop( "Unknown Greek key for facet label: ", key, call. = FALSE )
  # plotmath: literal metric text, then Greek symbol (parsed by label_parsed).
  paste0( "'", metric, "'~'  '~", g )
}

#' Plotmath subscript for a parameter suffix (handles underscores).
#' @noRd
#' @keywords internal
.pfimPlotmathSubscript = function( suffix ) {
  # Underscores break bare plotmath tokens; quote the whole subscript.
  if ( grepl( "_", suffix, fixed = TRUE ) )
    paste0( "['", suffix, "']" )
  else
    paste0( "[", suffix, "]" )
}

#' Normalize internal/console parameter names to ASCII tokens for plotmath.
#' @noRd
#' @keywords internal
.pfimParamNameAscii = function( parameterName ) {
  # Map console Greek prefixes to ASCII tokens that plotmath can parse.
  name <- as.character( parameterName )
  name <- gsub( "\u03bc_",    "mu_",      name, fixed = TRUE )
  name <- gsub( "\u03b2_",    "beta_",    name, fixed = TRUE )
  name <- gsub( "\u03c9\u00b2_", "omega^2_", name, fixed = TRUE )
  name <- gsub( "\u03b3\u00b2_", "gamma^2_", name, fixed = TRUE )
  name <- gsub( "\u03c3\u00b2_", "sigma^2_", name, fixed = TRUE )
  name
}

#' Plotmath label for a FIM parameter name (mu, beta, omega^2, ...).
#' @noRd
#' @keywords internal
.pfimParamPlotmathLabel = function( parameterName ) {
  name <- .pfimParamNameAscii( parameterName )
  # Longer prefixes first so "omega^2_" is not matched as a bare "omega".
  prefixes <- c( "omega^2_", "gamma^2_", "sigma^2_", "mu_", "beta_" )
  greek    <- c( "omega^2",  "gamma^2",  "sigma^2",  "mu",  "beta" )
  for ( i in seq_along( prefixes ) ) {
    p <- prefixes[[ i ]]
    if ( startsWith( name, p ) ) {
      suffix <- substring( name, nchar( p ) + 1L )
      return( paste0( greek[[ i ]], .pfimPlotmathSubscript( suffix ) ) )
    }
  }
  name
}

#' Plotmath y-axis label for sensitivity plots: df/d parameter.
#' @noRd
#' @keywords internal
.pfimSensitivityYLab = function( parameterName ) {
  # plotmath fraction df / d(parameter) for sensitivity figure y-axis.
  paste0( "frac(df, d*", .pfimParamPlotmathLabel( parameterName ), ")" )
}

#' Parsed plotmath expression from a label string.
#' @noRd
#' @keywords internal
.pfimParsePlotmath = function( label ) {
  # First (only) expression from parse(); keep.source=FALSE for speed.
  parse( text = label, keep.source = FALSE )[[ 1L ]]
}

#' Caption for sensitivity plots with Greek parameter names.
#' @noRd
#' @keywords internal
.pfimSensitivityCaption = function( designName, armName, outputName, parameterName ) {
  # Build a plotmath paste(...) string; escape quotes and keep Greek param as expression.
  paste0(
    "paste('Design: ", gsub( "'", "\\\\'", gsub( "_", " ", designName ) ),
    "   Arm: ", gsub( "'", "\\\\'", armName ),
    "   Output: ", gsub( "'", "\\\\'", outputName ),
    "   Parameter: ', ", .pfimParamPlotmathLabel( parameterName ), ")"
  )
}

.greekLatex = c(
  mu    = "$\\mu_{",
  beta  = "$\\beta_{",
  omega = "$\\omega^2_{",
  gamma = "$\\gamma^2_{",
  sigma = "$\\sigma^2_{"
)

#' Strip a Greek name prefix from FIM column labels.
#' @noRd
#' @keywords internal
.stripGreekPrefix = function( names, prefix )
  sub( paste0( "^", prefix ), "", names )

#' Residual-error parameter labels (\code{inter_}/\code{slope_} blocks).
#' @noRd
#' @keywords internal
.sigmaNames = function( modelError, greekSigma ) {
  # Only non-fixed, non-zero residual terms become estimable FIM columns.
  modelError |>
    map( function( err ) {
      out = prop( err, "output" )
      c(
        if ( prop( err, "sigmaInter" ) != 0 && !prop( err, "sigmaInterFixed" ) )
          paste0( greekSigma, "inter_", out ),
        if ( prop( err, "sigmaSlope"  ) != 0 && !prop( err, "sigmaSlopeFixed"  ) )
          paste0( greekSigma, "slope_", out )
      )
    }) |> unlist( use.names = FALSE )
}

#' Estimable residual-error values in \code{inter}/\code{slope} column order.
#' @noRd
#' @keywords internal
.sigmaValues = function( modelError ) {
  # Same inter/slope filter as .sigmaNames so values align with column labels.
  modelError |>
    map( function( err ) {
      c(
        if ( prop( err, "sigmaInter" ) != 0 && !prop( err, "sigmaInterFixed" ) )
          prop( err, "sigmaInter" ),
        if ( prop( err, "sigmaSlope"  ) != 0 && !prop( err, "sigmaSlopeFixed"  ) )
          prop( err, "sigmaSlope" )
      )
    }) |> unlist( use.names = FALSE )
}

#' Proportional subject counts per arm.
#'
#' Converts simplex weights to arm sizes via \code{round(total * w / sum(w), digits)}.
#' The rounded sizes are \emph{not} forced to sum exactly to \code{total}; residual
#' discrepancy can slightly change the realised D-criterion versus the continuous
#' weight mixture (typical population discrete-design trade-off).
#' @noRd
#' @keywords internal
.allocProportionalSubjects = function( total, weights, digits = 2L ) {
  # Round independently per arm; sum(n) may differ slightly from total.
  round( total * weights / sum( weights ), digits )
}

#' Total N for population multiplicative allocation (CRAN: \code{design$numberOfArms}).
#' @noRd
#' @keywords internal
.multiplicativePopulationNTotal = function( optimizationAlgorithm, cells, weightsIndex ) {
  outputs   = prop( optimizationAlgorithm, "multiplicativeAlgorithmOutputs" )
  nSubjects = outputs$numberOfArms
  # Prefer explicit total N from the optimizer; else fall back to first cell arm size.
  if ( length( nSubjects ) == 1L && is.finite( nSubjects ) && nSubjects > 0 )
    return( as.double( nSubjects ) )
  prop( .constraintCellArms( cells[[ weightsIndex[ 1L ] ]])[[ 1L ]], "size" )
}

#' Shared ggplot2 theme for PFIM figures.
#' @noRd
#' @keywords internal
.pfimBaseTheme = function( base_size = 16 ) {
  # Shared look for non-faceted PFIM figures (rotated x labels, no legend).
  theme_bw( base_size = base_size ) +
    theme(
      legend.position = "none",
      plot.title   = element_text( size = base_size, hjust = 0.5 ),
      axis.title   = element_text( size = base_size ),
      axis.text.x  = element_text( size = base_size, angle = 90, vjust = 0.5 ),
      axis.text.y  = element_text( size = base_size ),
      strip.text.x = element_text( size = base_size )
    )
}

#' Compact ggplot2 theme for faceted SE/RSE bar charts in reports.
#' @noRd
#' @keywords internal
.pfimSeRseTheme = function( n_facets = 5L, max_label_len = 12L ) {
  base_size  <- 10
  strip_size <- 9
  # Shrink tick text when many facets share the plot width.
  axis_size  <- max( 6L, min( 8L, as.integer( 60 / max( n_facets, 1L ) ) ) )
  # Long parameter names: angled labels instead of vertical 90°.
  axis_angle <- if ( max_label_len > 10L ) 45L else 90L
  theme_bw( base_size = base_size ) +
    theme(
      legend.position = "none",
      plot.title   = element_text( size = base_size, hjust = 0.5 ),
      axis.title   = element_text( size = base_size ),
      axis.text.x  = element_text(
        size  = axis_size,
        angle = axis_angle,
        hjust = if ( axis_angle == 45L ) 1 else 0.5,
        vjust = if ( axis_angle == 45L ) 1 else 0.5
      ),
      axis.text.y  = element_text( size = axis_size ),
      strip.text.x = element_text( size = strip_size ),
      strip.text   = element_text( margin = margin( 2, 2, 2, 2 ) ),
      panel.spacing.x = unit( 0.5, "lines" )
    )
}

#' Faceted SE/RSE bar chart shared by FIM plot methods.
#' @noRd
#' @keywords internal
.fimSeRseBarPlot = function( df, metric, facet_levels ) {
  # Longest x-label drives axis angle/size in .pfimSeRseTheme.
  max_lab <- max( nchar( as.character( df$Parameter ) ), na.rm = TRUE )
  ggplot( df, aes( x = .data[["Parameter"]], y = .data[[ metric ]] ) ) +
    geom_bar( stat = "identity", width = 0.65, show.legend = FALSE ) +
    facet_wrap(
      # free_x / free_x: each Greek category gets its own scale and bar widths.
      ~ factor( cat, levels = facet_levels ),
      scales = "free_x",
      space  = "free_x",
      labeller = ggplot2::label_parsed
    ) +
    labs( x = "Parameter", y = metric ) +
    .pfimSeRseTheme( n_facets = length( facet_levels ), max_label_len = max_lab )
}

#' @noRd
#' @keywords internal
.gradientMatrix = function( arm, cols, model = NULL ) {
  # Covariate/occasion models store gradients on the model, not the arm.
  mat = if ( !is.null( model ) && usesCovariateOccasionStructure( model ) ) {
    getArmEvaluationGradientsMatrix( model, arm )
  } else {
    raw = prop( arm, "evaluationGradients" )
    # May be one data.frame or a list of per-output frames to stack.
    df  = if ( is.data.frame( raw ) ) raw else do.call( rbind, raw )
    as.matrix( df )
  }
  mat[ , cols, drop = FALSE ]
}

#' Variance-parameter FIM block: \eqn{\frac12 \mathrm{Tr}(V^{-1} \mathrm{d}V_i V^{-1} \mathrm{d}V_j)}.
#' @noRd
#' @keywords internal
.computeMFVar_R = function( V_inv, dV_list ) {
  n <- length( dV_list )
  if ( !n ) return( matrix( numeric( 0 ), 0L, 0L ) )
  # Precompute V^{-1} dV_i V^{-1}; Frobenius product with dV_j yields the (i,j) entry.
  T_mats <- map( dV_list, ~ V_inv %*% .x %*% V_inv )
  outer(
    seq_len( n ), seq_len( n ),
    Vectorize( function( i, j ) 0.5 * sum( T_mats[[ i ]] * dV_list[[ j ]] ) )
  )
}

#' @rdname dot-computeMFVar_R
#' @noRd
#' @keywords internal
.computeMFVar = function( V_inv, dV_list ) {
  n <- length( dV_list )
  if ( !n ) return( matrix( numeric( 0 ), 0L, 0L ) )
  # Fast path: same formula as .computeMFVar_R, implemented in C++.
  computeMFVar_Rcpp( V_inv, dV_list )
}

#' @noRd
#' @keywords internal
.setOptimalArmsMultiplicative = function( optimizationAlgorithm ) {
  out          = prop( optimizationAlgorithm, "multiplicativeAlgorithmOutputs" )
  weights      = out$multiplicativeAlgorithmOutput[[ "weights" ]]
  # Drop protocols whose continuous weight is below the optimizer threshold.
  weightsIndex = which( weights > out$weightThreshold )
  cells        = out$armFims

  # Joint multi-outcome cell: keep only the single best-weighted protocol.
  if ( .constraintCellJoint( cells ) ) {
    best = weightsIndex[ which.max( weights[ weightsIndex ] ) ]
    return( .cloneConstraintCellArms( cells[[ best ]] ) )
  }

  # Individual FIM: one subject per retained protocol; size is a placeholder.
  armList = map( weightsIndex, function( idx ) {
    arm = .cloneConstraintArm( cells[[ idx ]] )
    prop( arm, "size" ) = 1.0
    prop( arm, "name" ) = paste0( "Arm", idx )
    arm
  })
  # Stable presentation order (largest size first; here all sizes are 1).
  armList[ rev( order( map_dbl( armList, ~ prop( .x, "size" ) ) ) ) ]
}

#' Build population arms from Multiplicative weights.
#'
#' Keeps candidates with weight \code{> weightThreshold}, then allocates subjects
#' with \code{.allocProportionalSubjects()}. Joint (multi-outcome) cells keep only
#' the single best-weighted protocol.
#' @noRd
#' @keywords internal
.setOptimalArmsMultiplicativePopulation = function( optimizationAlgorithm ) {
  outputs      = prop( optimizationAlgorithm, "multiplicativeAlgorithmOutputs" )
  weightsIndex = outputs$weightsIndex
  weights      = outputs$optimalWeights
  cells        = outputs$armFims

  # Joint multi-outcome cell: one protocol only (max weight among retained).
  if ( .constraintCellJoint( cells ) ) {
    best = weightsIndex[ which.max( weights ) ]
    return( .cloneConstraintCellArms( cells[[ best ]] ) )
  }

  # Convert continuous weights to integer-ish group sizes (may not sum to N_total).
  N_total   = .multiplicativePopulationNTotal( optimizationAlgorithm, cells, weightsIndex )
  nPerGroup = .allocProportionalSubjects( N_total, weights )
  armList   = map2( weightsIndex, nPerGroup, function( idx, size ) {
    arm = .cloneConstraintArm( cells[[ idx ]] )
    prop( arm, "size" ) = size
    prop( arm, "name" ) = paste0( "Arm", idx )
    arm
  })
  armList[ order( map_dbl( armList, ~ prop( .x, "size" ) ), decreasing = TRUE ) ]
}

#' @noRd
#' @keywords internal
.setOptimalArmsFedorovWynn = function( optimizationAlgorithm ) {
  out = prop( optimizationAlgorithm, "FedorovWynnAlgorithmOutputs" )
  unlist( imap( out$listArms, function( cell, i ) {
    # Multi-outcome cells store several arm entries; single-outcome wraps one.
    entries = if ( !is.null( cell$entries ) ) cell$entries else list( cell )
    if ( length( entries ) == 1L ) {
      arm = .pfimCloneS7( entries[[ 1L ]]$arm )
      prop( arm, "name" ) = paste0( "Arm", i )
      prop( arm, "size" ) = 1.0
      # Keep FW sampling metadata alongside the cloned arm.
      return( list( list( arm = arm, samplingsForFW = cell$samplingsForFW ) ) )
    }
    map( entries, function( entry ) {
      arm = .pfimCloneS7( entry$arm )
      prop( arm, "size" ) = 1.0
      list( arm = arm, samplingsForFW = entry$samplingsForFW )
    })
  } ), recursive = FALSE )
}

#' Build population arms from Fedorov-Wynn frequencies.
#'
#' Each optimal protocol gets \code{N = numberOfIndividuals[[i]]}. When a cell
#' holds several arm entries, sizes are split by relative entry sizes and
#' rounded (same caveat as \code{.allocProportionalSubjects}: sum may differ from N).
#' @noRd
#' @keywords internal
.setOptimalArmsFedorovWynnPopulation = function( optimizationAlgorithm ) {
  outputs             = prop( optimizationAlgorithm, "FedorovWynnAlgorithmOutputs" )
  numberOfIndividuals = outputs$numberOfIndividuals
  unlist( imap( outputs$listArms, function( cell, i ) {
    entries = if ( !is.null( cell$entries ) ) cell$entries else list( cell )
    arms    = map( entries, ~ .pfimCloneS7( .x$arm ) )
    N       = as.double( numberOfIndividuals[[ i ]] )
    if ( length( arms ) == 1L ) {
      prop( arms[[ 1L ]], "size" ) = N
      prop( arms[[ 1L ]], "name" ) = paste0( "Arm", i )
      return( list( list( arm = arms[[ 1L ]], samplingsForFW = cell$samplingsForFW ) ) )
    }
    # Split N across joint entries by their relative original sizes, then round.
    fracs = map_dbl( entries, ~ prop( .x$arm, "size" ) )
    fracs = fracs / sum( fracs )
    map( seq_along( arms ), function( j ) {
      prop( arms[[ j ]], "size" ) = round( N * fracs[[ j ]], 2 )
      list( arm = arms[[ j ]], samplingsForFW = entries[[ j ]]$samplingsForFW )
    })
  } ), recursive = FALSE )
}

#' @noRd
#' @keywords internal
.reportTemplatePath = function( filename ) {
  dir = file.path( system.file( package = "PFIM" ),
                    "rmarkdown", "templates", "skeleton" )
  path = file.path( dir, filename )
  if ( file.exists( path ) ) return( path )
  # Case-insensitive fallback (.Rmd vs .rmd) for installed package layouts.
  stem = sub( "\\.[rR]md$", "", filename )
  hits = list.files( dir,
                      pattern = paste0( "^", stem, "\\.[rR]md$" ),
                      full.names = TRUE, ignore.case = TRUE )
  if ( length( hits ) >= 1L ) return( hits[[ 1L ]] )
  path
}

#' @noRd
#' @keywords internal
.pfimCloseGraphicsDevices = function() {
  # Close every open device except the null device (dev.cur() == 1).
  while ( grDevices::dev.cur() > 1L )
    try( grDevices::dev.off(), silent = TRUE )
  invisible( NULL )
}

#' @noRd
#' @keywords internal
.pfimIsKnitting = function() {
  if ( !requireNamespace( "knitr", quietly = TRUE ) ) return( FALSE )
  # knitr::is_knitting exists only in recent knitr; look it up without attaching.
  fn = get0( "is_knitting", envir = asNamespace( "knitr" ), inherits = FALSE )
  is.function( fn ) && isTRUE( fn() )
}

#' Environment where user symbols (global covariates) are resolved.
#'
#' Analytic/ODE wrappers look up free variables such as \code{logtWT} or
#' \code{SEX} here. Prefers \code{knitr::knit_global()} when knitr is available
#' (chunk objects during R Markdown), otherwise \code{globalenv()}.
#' Does not rely on \code{knitr::is_knitting()} (absent in older knitr).
#' @noRd
#' @keywords internal
.pfimUserSymbolEnv = function() {
  if ( requireNamespace( "knitr", quietly = TRUE ) ) {
    kg = get0( "knit_global", envir = asNamespace( "knitr" ), inherits = FALSE )
    if ( is.function( kg ) ) {
      env = tryCatch( kg(), error = function( e ) NULL )
      if ( is.environment( env ) ) return( env )
    }
  }
  globalenv()
}

#' @noRd
#' @keywords internal
.pfimPrepareReportInputForRender = function( template_path, render_dir ) {
  lines = readLines( template_path, warn = FALSE, encoding = "UTF-8" )
  # Nested knit: rename the template's setup chunk to avoid knitr name clash.
  if ( .pfimIsKnitting() && any( grepl( "`\\{r setup([,}])", lines, perl = TRUE ) ) )
    lines = gsub( "`\\{r setup([,}])", "`{r pfim_report_setup\\1", lines, perl = TRUE )
  dest = file.path( render_dir, basename( template_path ) )
  writeLines( lines, dest, useBytes = TRUE )
  dest
}

#' Remove knitr/rmarkdown sidecars for one report only.
#'
#' Deletes \code{\{stem\}_files/} (media folder for this HTML) and optional
#' \code{.knit.md} leftovers. Intentionally does \emph{not} delete every
#' \code{.png} under \code{outputPath}: that would wipe unrelated plots when
#' several reports share a directory.
#' @noRd
#' @keywords internal
.pfimCleanupReportSidecars = function( outputPath, outputFile, template = NULL ) {
  stem  = tools::file_path_sans_ext( basename( outputFile ) )
  # Only this report's media folder — not every PNG under outputPath.
  media = file.path( outputPath, paste0( stem, "_files" ) )
  if ( dir.exists( media ) )
    unlink( media, recursive = TRUE )
  if ( !is.null( template ) ) {
    knit_md = paste0( tools::file_path_sans_ext( basename( template ) ), ".knit.md" )
    for ( p in unique( c(
      file.path( dirname( .reportTemplatePath( template ) ), knit_md ),
      file.path( outputPath, knit_md )
    ) ) ) {
      if ( file.exists( p ) ) unlink( p )
    }
  }
  invisible( NULL )
}

#' @noRd
#' @keywords internal
.pfimRenderReport = function( template, outputFile, outputPath, reportTables ) {
  # Leftover plot devices can make rmarkdown::render fail or hang.
  .pfimCloseGraphicsDevices()
  reportTables = .pfimPrepareReportAsisTables( reportTables )
  if ( is.null( reportTables$projectName ) || !nzchar( reportTables$projectName ) )
    reportTables$projectName = "PFIM Report"
  # Isolate knit side-effects in a temp dir, then copy the HTML out.
  render_dir = tempfile( pattern = "pfim_report" )
  dir.create( render_dir, showWarnings = FALSE )
  on.exit( {
    unlink( render_dir, recursive = TRUE )
    .pfimCloseGraphicsDevices()
  }, add = TRUE )
  template_path = .reportTemplatePath( template )
  input = .pfimPrepareReportInputForRender( template_path, render_dir )
  # When already knitting, pin the knit root so relative paths stay inside render_dir.
  knit_root_dir = if ( .pfimIsKnitting() ) render_dir else NULL
  out = rmarkdown::render(
    input          = input,
    output_file    = outputFile,
    output_dir     = render_dir,
    knit_root_dir  = knit_root_dir,
    params         = list( reportTables = reportTables ),
    # Self-contained HTML embeds figures; no external _files/ dependency for users.
    output_options = list( html_document = list( self_contained = TRUE ) ),
    envir          = new.env( parent = globalenv() ),
    quiet          = TRUE
  )
  dir.create( outputPath, recursive = TRUE, showWarnings = FALSE )
  file.copy(
    file.path( render_dir, outputFile ),
    file.path( outputPath, outputFile ),
    overwrite = TRUE
  )
  .pfimCleanupReportSidecars( render_dir, outputFile, template )
  .pfimCleanupReportSidecars( outputPath, outputFile )
  invisible( out )
}

#' @noRd
#' @keywords internal
.renderReport = function( template ) {
  # Capture template name; return an S7 method body for generateReportOptimization.
  force( template )
  function( fim, optimizationAlgorithm, tablesForReport, outputFile, outputPath )
    .pfimRenderReport( template, outputFile, outputPath, tablesForReport )
}

#' @noRd
#' @keywords internal
.renderEvalReport = function( template ) {
  # Same factory as .renderReport, but for generateReportEvaluation (no optimizer arg).
  force( template )
  function( fim, tablesForReport, outputFile, outputPath )
    .pfimRenderReport( template, outputFile, outputPath, tablesForReport )
}

#' @noRd
#' @keywords internal
.pfimRegisterOptimizationReports = function( fimClass, fimSuffix ) {
  # Wire each optimizer class to its matching Rmd template for this FIM type.
  algos = list(
    MultiplicativeAlgorithm, FedorovWynnAlgorithm, SimplexAlgorithm,
    PSOAlgorithm, PGBOAlgorithm
  )
  stems = c(
    "OptimizationMultiplicativeAlgorithm",
    "OptimizationFedorovWynnAlgorithm",
    "OptimizationSimplexAlgorithm",
    "OptimizationPSOAlgorithm",
    "OptimizationPGBOAlgorithm"
  )
  for ( i in seq_along( algos ) ) {
    tpl = paste0( stems[[ i ]], fimSuffix, "FIM.Rmd" )
    method( generateReportOptimization, list( fimClass, algos[[ i ]] ) ) =
      .renderReport( tpl )
  }
}

#' @noRd
#' @keywords internal
.pfimCloneS7 = function( object, reset = list() ) {
  # Deep-copy via serialize round-trip (S7 objects are not simple lists).
  clone = unserialize( serialize( object, NULL ) )
  for ( nm in names( reset ) )
    prop( clone, nm ) <- reset[[ nm ]]
  clone
}

#' Log-determinant of a symmetric FIM (0 or negative sign -> -Inf).
#' @noRd
#' @keywords internal
.fimLogDeterminant = function( M ) {
  p = nrow( M )
  if ( p == 0L ) return( -Inf )
  ld = determinant( M, logarithm = TRUE )
  # Negative sign means det(M) <= 0 (singular or indefinite for our purposes).
  if ( ld$sign < 0 ) return( -Inf )
  as.numeric( ld$modulus )
}

#' Determinant of a Fisher matrix (0 when indefinite/singular; may be Inf if overflow).
#'
#' Prefer \code{.fimLogDeterminant()} for display when \eqn{|\log\det|} is large.
#' @noRd
#' @keywords internal
.fimDeterminant = function( M ) {
  ld = .fimLogDeterminant( M )
  # Map non-positive / singular FIMs to 0 rather than NaN from exp(-Inf).
  if ( !is.finite( ld ) ) return( 0 )
  if ( ld > log( .Machine$double.xmax ) ) return( Inf )
  if ( ld < log( .Machine$double.xmin ) ) return( 0 )
  exp( ld )
}

#' D-criterion from a Fisher matrix (\eqn{\det(M)^{1/p}}).
#' @noRd
#' @keywords internal
.fimDcriterionFromMatrix = function( M ) {
  p = nrow( M )
  if ( p == 0L ) return( 0 )
  ld = .fimLogDeterminant( M )
  if ( !is.finite( ld ) ) return( 0 )
  # Geometric mean of eigenvalues: det(M)^{1/p} = exp(logdet / p).
  as.numeric( exp( ld / p ) )
}

#' D-criterion
#' @name Dcriterion
#' @return Numeric D-optimality criterion value.
#' @examples
#' \donttest{
#' source(system.file("examples", "evaluation-minimal.R", package = "PFIM"))
#' Dcriterion(prop(ev, "fim"))
#' }
#' @export

method( Dcriterion, Fim ) = function( fim ) {
  # D-opt = det(F)^{1/p} from the labelled fisherMatrix property.
  .fimDcriterionFromMatrix( prop( fim, "fisherMatrix" ) )
}

#' @noRd
#' @keywords internal
.conditionNumber = function( M ) {
  if ( nrow( M ) == 0L ) return( Inf )
  ev = eigen( M, symmetric = TRUE, only.values = TRUE )$values
  scale = max( abs( ev ), 0 )
  tol   = max( scale * .Machine$double.eps * max( length( ev ), 1L ), 0 )
  # Tiny negative eigenvalues from roundoff are ignored; clear negatives => Inf.
  if ( any( ev < -tol ) ) return( Inf )
  pos = ev[ ev > tol ]
  if ( !length( pos ) ) return( Inf )
  max( pos ) / min( pos )
}

#' @noRd
#' @keywords internal
.printFimSeAndRse = function( fim, evaluation = NULL ) {
  # Optionally refresh SE/RSE from a project evaluation before printing.
  if ( !is.null( evaluation ) )
    fim = setEvaluationFim( fim, evaluation )

  se_list = as.list( prop( fim, "SEAndRSE" ) )
  # Older objects used key "SEAndRSE"; current code stores "table".
  se_tbl  = se_list[[ "table" ]] %||% se_list[[ "SEAndRSE" ]]

  if ( !is.data.frame( se_tbl ) || nrow( se_tbl ) == 0L ) {
    cat( "  (SE/RSE table unavailable)\n\n" )
    flush.console()
    return( invisible( NULL ) )
  }

  rn = rownames( se_tbl )
  if ( is.null( rn ) ) rn = paste0( "p", seq_len( nrow( se_tbl ) ) )

  fmt = function( x, w ) format( x, width = w, justify = "right", trim = TRUE )
  # Column width for names: at least 12, or widest parameter label.
  wn  = max( 12L, max( nchar( rn, type = "width" ), na.rm = TRUE ) )

  cat(
    sprintf( paste0( "%-", wn, "s %14s %12s %10s\n" ),
             "Parameter", "Value", "SE", "RSE(%)" )
  )
  for ( i in seq_len( nrow( se_tbl ) ) ) {
    cat(
      sprintf(
        paste0( "%-", wn, "s %14s %12s %10s\n" ),
        rn[i],
        fmt( se_tbl$parametersValues[i], 14 ),
        fmt( se_tbl$SE[i], 12 ),
        fmt( se_tbl$RSE[i], 10 )
      )
    )
  }
  cat( "\n" )
  flush.console()
  invisible( se_tbl )
}

#' @noRd
#' @keywords internal
.duplicateFim = function( fim ) {
  cls = S7::S7_class( fim )@name
  # Subclass-specific copy factories are registered via pfim_register_fim_type.
  if ( !exists( cls, envir = .pfimFimDuplicatorRegistry, inherits = FALSE ) )
    stop(
      sprintf(
        "Cannot duplicate FIM object of class '%s' (register with pfim_register_fim_type).",
        cls
      ),
      call. = FALSE
    )
  get( cls, envir = .pfimFimDuplicatorRegistry )( fim )
}
